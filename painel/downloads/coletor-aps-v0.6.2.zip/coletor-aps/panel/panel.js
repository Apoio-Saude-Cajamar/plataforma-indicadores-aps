// Painel lateral: orquestra a coleta, guarda o histórico e calcula os indicadores.
const $ = id => document.getElementById(id);
const estado = { aba: null, cancelar: false, coletaAtual: null, filtros: null };

// ---------------------------------------------------------------- inicialização
document.addEventListener('DOMContentLoaded', async () => {
  $('versao').textContent = 'v' + CONFIG.versao;
  $('competencia').value = UTIL.competenciaAnterior();
  montarUnidades();
  estado.filtros = filtrosPadrao();
  $('btnVerificar').onclick = verificarPEC;
  $('btnColetar').onclick = coletar;
  $('btnCancelar').onclick = () => { estado.cancelar = true; log('Cancelamento solicitado; a coleta para ao fim da etapa atual.'); };
  $('nivel').onchange = renderizar;
  // As opções do grupo "Por unidade" só valem com os indicadores por unidade ligados.
  const sincronizarSub = () => { const on = $('optUnidades').checked; $('subUnidades').classList.toggle('desligado', !on); $('subUnidades').querySelectorAll('input').forEach(i => { i.disabled = !on; }); };
  $('optUnidades').onchange = sincronizarSub; sincronizarSub();
  $('btnJSON').onclick = () => exportarJSON(estado.coletaAtual);
  $('btnCSV').onclick = () => exportarCSV(estado.coletaAtual);
  chrome.runtime.onMessage.addListener(msg => { if (msg && msg.tipo === 'progresso') log(msg.texto, msg.classe); });
  await verificarPEC();
  await renderizarHistorico();
});

function montarUnidades() {
  const div = $('listaUnidades');
  div.innerHTML = '';
  CONFIG.unidadesAPS.forEach((u, i) => {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" checked data-unidade="${i}"> ${u}`;
    div.appendChild(l);
  });
  div.onchange = () => { $('qtdUnidades').textContent = unidadesSelecionadas().length; };
}
const unidadesSelecionadas = () => [...document.querySelectorAll('[data-unidade]')].filter(c => c.checked).map(c => CONFIG.unidadesAPS[+c.dataset.unidade]);

function filtrosPadrao() {
  return {
    grupos: Object.fromEntries(Object.entries(CONFIG.gruposCBO).map(([k, g]) => [k, g.padrao])),
    faltas: Object.fromEntries(CONFIG.tiposFalta.map(t => [t, true]))
  };
}

function log(texto, classe) {
  const li = document.createElement('li');
  li.textContent = `${new Date().toLocaleTimeString('pt-BR')} · ${texto}`;
  if (classe) li.className = classe;
  $('log').appendChild(li);
  $('log').scrollTop = $('log').scrollHeight;
}

// ---------------------------------------------------------------- comunicação com a aba do PEC
async function acharAbaPEC() {
  const abas = await chrome.tabs.query({ url: CONFIG.host + '/*' });
  if (!abas.length) return null;
  return abas.find(a => a.active) || abas[0];
}

function enviarUmaVez(tabId, msg) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, msg, resp => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (resp && resp.erro) return reject(new Error(resp.erro));
      resolve(resp);
    });
  });
}

// A página do PEC recarrega ao trocar de acesso ou abrir relatórios; nesse instante o canal com a extensão cai.
// Nesses casos espera a página voltar (reabrindo o início do PEC se preciso) e tenta de novo, uma vez.
const ERRO_CANAL = /Receiving end does not exist|Could not establish connection|message channel closed|No tab with id/i;
async function enviar(tabId, msg) {
  try { return await enviarUmaVez(tabId, msg); }
  catch (e) {
    if (!ERRO_CANAL.test(e.message) || msg.acao === 'ping') throw e;
    try { await aguardarPronto(tabId, 25000); }
    catch (_) { await voltarAoInicio(tabId); }
    return enviarUmaVez(tabId, msg);
  }
}

// Leva a aba de volta à página inicial do PEC (onde a extensão sempre está ativa) e espera ela ficar pronta.
async function voltarAoInicio(tabId) {
  await chrome.tabs.update(tabId, { url: CONFIG.host + '/' });
  await aguardarPronto(tabId, 90000);
}

async function aguardarPronto(tabId, limiteMs = 90000, caminho) {
  const ini = Date.now();
  await UTIL.dormir(2500);
  while (Date.now() - ini < limiteMs) {
    try {
      const r = await enviar(tabId, { acao: 'ping' });
      if (r && r.pronto && (!caminho || (r.caminho || '').startsWith(caminho))) return r;
    } catch (_) { /* página recarregando */ }
    await UTIL.dormir(1500);
  }
  throw new Error('A página do PEC não respondeu a tempo.');
}

async function verificarPEC() {
  const st = $('status');
  st.className = 'status';
  estado.aba = await acharAbaPEC();
  if (!estado.aba) { st.textContent = 'Abra o PEC (esus.cajamar.sp.gov.br) numa aba e faça login.'; st.classList.add('aviso'); return false; }
  try {
    const r = await enviar(estado.aba.id, { acao: 'ping' });
    if (!r.logado) { st.textContent = 'PEC aberto, mas sem login. Faça login e escolha um acesso.'; st.classList.add('aviso'); return false; }
    st.textContent = `Conectado. Acesso atual: ${r.acesso || 'não identificado'}.`;
    st.classList.add('ok');
    return true;
  } catch (e) {
    st.textContent = 'A aba do PEC precisa ser recarregada (F5) para a extensão funcionar nela.';
    st.classList.add('aviso');
    return false;
  }
}

// ---------------------------------------------------------------- coleta
async function coletar() {
  if (!(await verificarPEC())) return;
  const comp = $('competencia').value;
  if (!comp) { log('Escolha a competência.', 'erro'); return; }
  const tabId = estado.aba.id;
  estado.cancelar = false;
  $('btnColetar').disabled = true; $('btnCancelar').disabled = false;
  $('log').innerHTML = '';

  const coleta = {
    id: `${comp}-${Date.now()}`, competencia: comp, versao: CONFIG.versao,
    iniciadoEm: new Date().toISOString(), concluidoEm: null,
    config: { unidadesAPS: CONFIG.unidadesAPS, gruposCBO: CONFIG.gruposCBO, tiposFalta: CONFIG.tiposFalta },
    cubos: { atendimentos: [], absenteismo: [], escuta: [], coletivas: [], odonto: [], equipes: [] }, linhas: [], avisos: [], observacoes: []
  };
  const comEscuta = $('optEscuta').checked && $('optUnidades').checked;
  const comBucal = $('optBucal').checked && $('optUnidades').checked;
  log(`Coleta da competência ${comp} iniciada.`);

  try {
    if ($('optMunicipal').checked) {
      const r = await enviar(tabId, { acao: 'municipal', comp });
      coleta.cubos.atendimentos = r.atendimentos || [];
      coleta.cubos.absenteismo = r.absenteismo || [];
      (r.avisos || []).forEach(a => coleta.avisos.push(a));
      log('Indicadores municipais coletados.', 'ok');
    }

    if ($('optColetivas').checked && !estado.cancelar) {
      try {
        log('Atividades coletivas (B4, M1, M2): lendo as atividades do mês; leva alguns minutos…');
        const r = await enviar(tabId, { acao: 'coletivas', comp });
        coleta.cubos.coletivas = r.linhas || [];
        (r.avisos || []).forEach(a => coleta.avisos.push(a));
        log(`Atividades coletivas: ${r.lidas || 0} de ${r.total || 0} lidas.`, 'ok');
      } catch (e) {
        coleta.avisos.push('Atividades coletivas: ' + e.message);
        log('Atividades coletivas: ' + e.message, 'erro');
      }
    }

    // eMulti (M1 do quadrimestre e M2 completa). Os resumos ficam só na memória desta coleta.
    let m1 = null;
    if ($('optEmulti').checked && !estado.cancelar) {
      try {
        log('eMulti (M1 e M2): atendimentos compartilhados e atividades coletivas do quadrimestre; alguns minutos…');
        const sal = [...crypto.getRandomValues(new Uint8Array(16))].map(x => x.toString(16)).join('');
        const r = await enviar(tabId, { acao: 'emultiMunicipal', comp, sal });
        if (r.erro) throw new Error(r.erro);
        coleta.cubos.compartilhado = r.compartilhado || [];
        m1 = { sal, quad: UTIL.quadrimestreAte(comp).quad, equipes: r.equipes || [], atendQuad: r.atendQuad || {}, coletivasQuad: r.coletivasQuad || {}, ind: {} };
        if (r.coletivasQuad && r.coletivasQuad.falhas) coleta.avisos.push(`M1: ${r.coletivasQuad.falhas} atividades coletivas do quadrimestre não puderam ser lidas.`);
        log(`eMulti: ${(r.coletivasQuad && r.coletivasQuad.total) || 0} atividades coletivas no quadrimestre.`, 'ok');
      } catch (e) {
        coleta.avisos.push('eMulti (M1/M2): ' + e.message);
        log('eMulti (M1/M2): ' + e.message, 'erro');
      }
    }

    if ($('optUnidades').checked) {
      const original = await enviar(tabId, { acao: 'ping' });
      const unidades = unidadesSelecionadas();
      for (const [i, unidade] of unidades.entries()) {
        if (estado.cancelar) { log('Coleta cancelada.', 'erro'); break; }
        log(`(${i + 1}/${unidades.length}) ${unidade}: trocando de acesso…`);
        try {
          if (i > 0) await voltarAoInicio(tabId); // sai do relatório clássico da unidade anterior
          const t = await enviar(tabId, { acao: 'trocarAcesso', unidade });
          if (t && t.recarregando) await aguardarPronto(tabId);
          const r = await enviar(tabId, { acao: 'unidade', comp, unidade, opcoes: { c7ItemC: $('optC7C').checked, territorio: $('optTerritorio').checked, cvat: $('optCvat').checked } });
          coleta.linhas.push(...(r.linhas || []));
          coleta.observacoes.push(...(r.observacoes || []));
          if (m1 && m1.equipes.length) {
            try {
              const p = await enviar(tabId, { acao: 'emultiUnidade', comp, sal: m1.sal, equipes: m1.equipes });
              if (p.erro) throw new Error(p.erro);
              for (const [ine, v] of Object.entries(p)) {
                const o = m1.ind[ine] = m1.ind[ine] || { atendimentos: 0, resumos: new Set() };
                o.atendimentos += v.atendimentos; v.resumos.forEach(x => o.resumos.add(x));
              }
            } catch (err) { coleta.avisos.push(`${unidade}: pessoas atendidas pela eMulti não lidas (${err.message}).`); }
          }
          (r.avisos || []).forEach(a => coleta.avisos.push(`${unidade}: ${a}`));
          (r.equipes || []).forEach(e => coleta.cubos.equipes.push(Object.assign({ unidade }, e)));

          // Composição: quadro de lotação da unidade (lista de profissionais do relatório clássico).
          if ($('optComposicao').checked && !estado.cancelar) {
            try {
              await enviar(tabId, { acao: 'abrirRelatorioClassico' });
              await aguardarPronto(tabId, 120000, '/relatorios/producao/atendimento-individual');
              const lt = await enviar(tabId, { acao: 'lotacoes' });
              if (lt.erro) throw new Error(lt.erro);
              (coleta.cubos.lotacoes = coleta.cubos.lotacoes || []).push(...(lt.lotacoes || []).map(l => Object.assign({ unidade }, l)));
              log(`${unidade}: ${(lt.lotacoes || []).length} lotações lidas.`);
            } catch (err) { coleta.avisos.push(`${unidade}: composição não lida (${err.message}).`); }
          }
          // CR4 (eCR): itens A, B e C pelo relatório de atendimento individual filtrado por tuberculose.
          const ecr = (r.equipes || []).find(e => String(e.tipo).toUpperCase() === 'ECR' && e.ine);
          const lcr4 = ecr && coleta.linhas.find(l => l.codigo === 'CR4' && l.ine === ecr.ine);
          if (lcr4 && lcr4.denominador > 0 && !estado.cancelar) {
            try {
              await enviar(tabId, { acao: 'abrirRelatorioClassico' });
              await aguardarPronto(tabId, 120000, '/relatorios/producao/atendimento-individual');
              const tb = await enviar(tabId, { acao: 'tuberculose', comp, unidade, equipe: { ine: ecr.ine, nome: ecr.nome } });
              if (tb.erro) throw new Error(tb.erro);
              Object.assign(lcr4, CALCULO.cr4(lcr4, tb));
            } catch (err) { coleta.avisos.push(`${unidade}: CR4, itens A a C não lidos (${err.message}).`); }
          }
          // Escuta inicial (C1): relatório de atendimento individual por equipe eSF/eAP e categoria.
          if (comEscuta && !estado.cancelar) {
            const equipes = (r.linhas || []).filter(l => l.codigo === 'Q12.2' && CONFIG.c1.tiposEquipe.includes(String(l.tipoEquipe).toUpperCase()) && l.ine)
              .map(l => ({ ine: l.ine, nome: l.equipe }));
            if (equipes.length) {
              try {
                await enviar(tabId, { acao: 'abrirRelatorioClassico' });
                await aguardarPronto(tabId, 120000, '/relatorios/producao/atendimento-individual');
                const e = await enviar(tabId, { acao: 'escutaInicial', comp, unidade, equipes });
                coleta.cubos.escuta.push(...(e.linhas || []));
                (e.avisos || []).forEach(a => coleta.avisos.push(`${unidade}: ${a}`));
              } catch (err) {
                coleta.avisos.push(`${unidade}: escuta inicial não coletada (${err.message}).`);
                log(`${unidade}: escuta inicial não coletada (${err.message}).`, 'erro');
              }
            }
          }
          // Saúde bucal (B1, B2, B3, B5, B6): relatório de atendimento odontológico por equipe eSB.
          const esb = (r.equipes || []).filter(e => String(e.tipo).toUpperCase() === 'ESB' && e.ine);
          if (comBucal && esb.length && !estado.cancelar) {
            try {
              await enviar(tabId, { acao: 'abrirRelatorioOdonto' });
              await aguardarPronto(tabId, 120000, '/relatorios/producao/atendimento-odontologico');
              const o = await enviar(tabId, { acao: 'odontologico', comp, unidade, equipes: esb });
              coleta.cubos.odonto.push(...(o.linhas || []));
              (o.avisos || []).forEach(a => coleta.avisos.push(`${unidade}: ${a}`));
            } catch (err) {
              coleta.avisos.push(`${unidade}: saúde bucal não coletada (${err.message}).`);
              log(`${unidade}: saúde bucal não coletada (${err.message}).`, 'erro');
            }
          }
          log(`${unidade}: concluída.`, 'ok');
        } catch (e) {
          coleta.avisos.push(`${unidade}: ${e.message}`);
          log(`${unidade}: ${e.message}`, 'erro');
        }
      }
      if (original && original.acessoId) {
        try {
          await enviar(tabId, { acao: 'restaurarAcesso', acessoId: original.acessoId });
          log(`Acesso original restaurado (${original.acesso || original.acessoId}). Recarregue a página do PEC para o cabeçalho refletir isso.`);
        } catch (e) { log('Não foi possível restaurar o acesso original: ' + e.message, 'erro'); }
      }
    }

    if (m1) {
      try { coleta.linhas.push(...CALCULO.m1(m1, coleta)); } catch (e) { coleta.avisos.push('M1: ' + e.message); }
      m1 = null; // descarta os resumos
    }
    try { coleta.observacoes.push(...CALCULO.observacoesBucal(coleta)); } catch (_) { /* sem atividades */ }
    if ((coleta.cubos.lotacoes || []).length) {
      try {
        coleta.composicao = CALCULO.composicao(coleta);
        coleta.composicao.alertas.forEach(a => coleta.avisos.push('Composição: ' + a));
        for (const u of coleta.composicao.unidades) {
          u.alertas.forEach(a => coleta.avisos.push(`Composição · ${u.nome}: ${a}`));
          u.equipes.forEach(e => e.alertas.forEach(a => coleta.avisos.push(`Composição · ${u.nome} · ${e.nome}: ${a}`)));
        }
        delete coleta.cubos.lotacoes; // a árvore já tem tudo
        await enviarComposicao(coleta);
      } catch (e) { coleta.avisos.push('Composição: ' + e.message); }
    }
    // Conferência dos vínculos eSB → eSF (regra de 40 h de eSB por eSF).
    try { CALCULO.conferirSaudeBucal(coleta).forEach(a => coleta.avisos.push('Saúde bucal: ' + a)); } catch (_) { /* sem dados de equipes */ }
    coleta.concluidoEm = new Date().toISOString();
    await enviarColeta(coleta);
    await salvarColeta(coleta);
    estado.coletaAtual = coleta;
    log('Coleta salva no histórico.', 'ok');
    renderizar();
    await renderizarHistorico();
  } catch (e) {
    log('Erro: ' + e.message, 'erro');
  } finally {
    $('btnColetar').disabled = false; $('btnCancelar').disabled = true;
  }
}

// ---------------------------------------------------------------- cálculo
// Gera linhas no nível equipe para todos os indicadores; o nível escolhido é obtido por agregação.
function linhasCalculadas(coleta, filtros) {
  const out = coleta.linhas.map(l => Object.assign({}, l));
  const chaveEq = l => `${l.unidade}|${l.equipe}`;
  const grupoOk = (l, grupos) => !!grupos[l.grupoCBO];

  // Q14.2.1 — faltas ÷ (atendimentos + faltas), com filtros de CBO e tipo de falta
  const acc = new Map();
  for (const a of coleta.cubos.absenteismo) {
    if (!grupoOk(a, filtros.grupos) || !filtros.faltas[a.tipoFalta]) continue;
    const k = chaveEq(a); const o = acc.get(k) || { unidade: a.unidade, equipe: a.equipe, faltas: 0, atend: 0 };
    o.faltas += a.n; acc.set(k, o);
  }
  for (const a of coleta.cubos.atendimentos) {
    if (!grupoOk(a, filtros.grupos)) continue;
    const k = chaveEq(a); const o = acc.get(k) || { unidade: a.unidade, equipe: a.equipe, faltas: 0, atend: 0 };
    o.atend += a.n; acc.set(k, o);
  }
  for (const o of acc.values()) out.push({ codigo: 'Q14.2.1', unidade: o.unidade, equipe: o.equipe, numerador: o.faltas, denominador: o.atend + o.faltas });

  // C1 — demanda programada ÷ total, só com os CBOs e tipos de equipe da Nota C1.
  // O tipo de cada equipe vem da coleta por unidade; sem ela, todas as equipes entram.
  const cbosC1 = new Set(CONFIG.c1.cbos);
  const tiposEq = new Map(coleta.linhas.filter(l => l.tipoEquipe).map(l => [UTIL.normalizar(`${l.unidade}|${l.equipe}`), String(l.tipoEquipe).toUpperCase()]));
  // Fica de fora: atendimento sem equipe e equipe cujo tipo conhecido não é eSF/eAP.
  // Equipe de tipo desconhecido entra (os CBOs da nota já excluem ESB e eMulti).
  const equipeOkC1 = a => {
    if (/^sem equipe$/i.test(String(a.equipe || '').trim())) return false;
    const t = tiposEq.get(UTIL.normalizar(`${a.unidade}|${a.equipe}`));
    return !t || CONFIG.c1.tiposEquipe.includes(t);
  };
  const c1 = new Map();
  for (const a of coleta.cubos.atendimentos) {
    if (!cbosC1.has(a.cboCodigo) || !equipeOkC1(a)) continue;
    const k = chaveEq(a); const o = c1.get(k) || { unidade: a.unidade, equipe: a.equipe, prog: 0, total: 0 };
    o.total += a.n;
    const t = UTIL.normalizar(a.tipoAtendimento);
    if (t === 'consulta agendada' || t.startsWith('consulta agendada programada')) o.prog += a.n;
    c1.set(k, o);
  }
  // Escuta inicial (demanda espontânea) lida do relatório de atendimento individual.
  const escuta = coleta.cubos.escuta || [];
  const porNome = new Map([...c1.values()].map(o => [UTIL.normalizar(`${o.unidade}|${o.equipe}`), o]));
  for (const e of escuta) {
    const k = UTIL.normalizar(`${e.unidade}|${e.equipe}`);
    let o = porNome.get(k);
    if (!o) { o = { unidade: e.unidade, equipe: e.equipe, prog: 0, total: 0 }; porNome.set(k, o); c1.set(`${e.unidade}|${e.equipe}`, o); }
    o.total += e.escuta || 0;
    o.escuta = (o.escuta || 0) + (e.escuta || 0);
  }
  for (const o of c1.values()) out.push({ codigo: 'C1', unidade: o.unidade, equipe: o.equipe, numerador: o.prog, denominador: o.total, escuta: o.escuta || 0 });
  out.push(...CALCULO.saudeBucal(coleta));
  out.push(...CALCULO.emulti(coleta));
  return out;
}

function agregarNivel(linhas, nivel) {
  const grupos = new Map();
  for (const l of linhas) {
    const k = [l.codigo, nivel === 'municipio' ? '' : l.unidade, nivel === 'equipe' ? l.equipe : ''].join('|');
    const g = grupos.get(k) || { codigo: l.codigo, unidade: nivel === 'municipio' ? 'Município' : l.unidade, equipe: nivel === 'equipe' ? l.equipe : '', numerador: 0, denominador: 0, somaPontos: 0, valor: 0 };
    g.numerador += l.numerador || 0;
    g.denominador += l.denominador || 0;
    g.somaPontos += l.somaPontos || 0;
    g.valor += l.valor || 0;
    g.fontes = (g.fontes || 0) + 1; if (l.faixa) g.faixa = l.faixa;
    grupos.set(k, g);
  }
  // C7: a nota sai dos itens já agregados no mesmo nível (Σ cumpridas ÷ faixa × peso).
  const itensC7 = new Map();
  for (const g of grupos.values()) {
    const m = /^C7-([ABCD])$/.exec(g.codigo);
    if (!m) continue;
    const k = `${g.unidade}|${g.equipe}`;
    const o = itensC7.get(k) || { unidade: g.unidade, equipe: g.equipe, itens: {} };
    o.itens[m[1]] = [g.numerador, g.denominador];
    itensC7.set(k, o);
  }
  for (const o of itensC7.values()) {
    const r = INDICADORES_C7.nota(o.itens);
    grupos.set(`C7|${o.unidade}|${o.equipe}`, { codigo: 'C7', unidade: o.unidade, equipe: o.equipe, numerador: 0, denominador: 0, somaPontos: 0, valor: r.nota, resultadoDireto: r.nota });
  }
  // CVAT: escore do cadastro (até 3) + escore do acompanhamento (até 7), pelas faixas da NT 30/2025.
  const cvat = new Map();
  for (const g of grupos.values()) {
    if (g.codigo !== 'CVAT-CAD' && g.codigo !== 'CVAT-ACO') continue;
    const k = `${g.unidade}|${g.equipe}`;
    const o = cvat.get(k) || { unidade: g.unidade, equipe: g.equipe };
    o[g.codigo] = g; cvat.set(k, o);
  }
  for (const o of cvat.values()) {
    if (!o['CVAT-CAD'] || !o['CVAT-ACO']) continue;
    const r = CALCULO.notaCvat(o['CVAT-CAD'], o['CVAT-ACO']);
    grupos.set(`CVAT|${o.unidade}|${o.equipe}`, { codigo: 'CVAT', unidade: o.unidade, equipe: o.equipe, numerador: 0, denominador: 0, somaPontos: 0, valor: r.nota, resultadoDireto: r.nota, escores: r });
  }
  return [...grupos.values()].map(g => {
    if (g.resultadoDireto !== undefined) { g.resultado = g.resultadoDireto; return g; }
    const tipo = (CATALOGO[g.codigo] || {}).tipo;
    if (tipo === 'pontos') g.resultado = g.denominador ? g.somaPontos / g.denominador : null;
    else if (tipo === 'percentual') g.resultado = g.denominador ? 100 * g.numerador / g.denominador : null;
    else if (tipo === 'razao') g.resultado = g.denominador ? g.numerador / g.denominador : null;
    else g.resultado = g.valor;
    return g;
  }).sort((a, b) => a.codigo.localeCompare(b.codigo, 'pt', { numeric: true }) || a.unidade.localeCompare(b.unidade) || a.equipe.localeCompare(b.equipe));
}

const fmt = (n, casas = 1) => n === null || n === undefined || isNaN(n) ? '—' : Number(n).toLocaleString('pt-BR', { maximumFractionDigits: casas, minimumFractionDigits: casas });

// ---------------------------------------------------------------- exibição
function renderizar() {
  const c = estado.coletaAtual;
  if (!c) return;
  $('secResultado').hidden = false;
  $('resComp').textContent = c.competencia;
  montarFiltrosQ14();
  const nivel = $('nivel').value;
  const linhas = agregarNivel(linhasCalculadas(c, estado.filtros), nivel);
  const t = $('tabela');
  const local = nivel === 'municipio' ? 'Abrangência' : nivel === 'equipe' ? 'Unidade · equipe' : 'Unidade';
  let html = `<thead><tr><th>${local}</th><th class="num">Num.</th><th class="num">Den.</th><th class="num">Result.</th></tr></thead><tbody>`;
  // excluídos por indicador (ex.: gestações acima de 42 semanas)
  const excl = {};
  for (const l of c.linhas) if (l.excluidos) excl[l.codigo] = (excl[l.codigo] || 0) + l.excluidos;
  let ultimo = '';
  for (const l of linhas) {
    const cat = CATALOGO[l.codigo] || { nome: l.codigo, tipo: '' };
    if (l.codigo !== ultimo) {
      const notaCat = l.codigo === 'C1' && !((c.cubos && c.cubos.escuta) || []).length ? 'sem escuta inicial no denominador (não coletada)' : (cat.nota || '');
      const nota = [cat.meta ? `meta ${cat.meta}` : '', notaCat,excl[l.codigo] ? `${excl[l.codigo]} registro(s) fora do período desconsiderado(s)` : ''].filter(Boolean).join(' · ');
      const esc = t => String(t).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
      const info = cat.margem ? ` <span class="info" title="${esc((cat.precisao === 'piso' ? 'Piso: o valor real é igual ou maior. ' : cat.precisao === 'aproximado' ? 'Aproximado. ' : '') + cat.margem)}">i</span>` : '';
      html += `<tr class="grupo"><td colspan="4">${l.codigo} · ${cat.nome}${info}${nota ? ` <small>(${nota})</small>` : ''}</td></tr>`;
      ultimo = l.codigo;
    }
    const semNumDen = cat.tipo === 'contagem' || cat.tipo === 'nota';
    const num = cat.tipo === 'pontos' ? fmt(l.somaPontos, 0) : semNumDen ? '' : fmt(l.numerador, 0);
    const res = cat.tipo === 'percentual' ? fmt(l.resultado) + '%' : cat.tipo === 'razao' ? fmt(l.resultado, 2) : (cat.tipo === 'pontos' || cat.tipo === 'nota') ? fmt(l.resultado) : fmt(l.resultado, 0);
    const faixa = l.faixa && l.fontes === 1 ? ` <small>(${fmt(l.faixa[0], cat.tipo === 'razao' ? 2 : 1)} a ${fmt(l.faixa[1], cat.tipo === 'razao' ? 2 : 1)})</small>` : '';
    const onde = nivel === 'municipio' ? 'Município' : nivel === 'equipe' ? `${l.unidade}<br><small>${l.equipe || ''}</small>` : l.unidade;
    html += `<tr><td>${onde}</td><td class="num">${num}</td><td class="num">${semNumDen ? '' : fmt(l.denominador, 0)}</td><td class="num"><strong>${res}</strong>${faixa}</td></tr>`;
  }
  t.innerHTML = html + '</tbody>';
  const av = $('avisos');
  av.innerHTML = (c.avisos || []).map(a => `<li>${a}</li>`).join('');
  av.hidden = !(c.avisos || []).length;
}

function montarFiltrosQ14() {
  const c = $('filtrosCBO'), f = $('filtrosFalta');
  if (c.childElementCount) return;
  c.innerHTML = '<strong>Grupos de CBO</strong>';
  for (const [k, g] of Object.entries(CONFIG.gruposCBO)) {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" ${estado.filtros.grupos[k] ? 'checked' : ''}> ${g.rotulo}`;
    l.querySelector('input').onchange = e => { estado.filtros.grupos[k] = e.target.checked; renderizar(); };
    c.appendChild(l);
  }
  f.innerHTML = '<strong>Tipo de falta</strong>';
  for (const t of CONFIG.tiposFalta) {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" ${estado.filtros.faltas[t] ? 'checked' : ''}> ${t.charAt(0) + t.slice(1).toLowerCase()}`;
    l.querySelector('input').onchange = e => { estado.filtros.faltas[t] = e.target.checked; renderizar(); };
    f.appendChild(l);
  }
}

// ---------------------------------------------------------------- histórico e exportação
// Envio da composição ao Painel APS (endereço e chave ficam só neste navegador, em chrome.storage).
async function enviarComposicao(coleta) {
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Composição guardada na coleta (Painel APS não configurado para envio).'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/composicao', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave }, body: JSON.stringify(coleta.composicao) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    log('Composição enviada ao Painel APS.', 'ok');
  } catch (e) { coleta.avisos.push('Composição não enviada ao Painel APS: ' + e.message); log('Composição não enviada ao Painel APS: ' + e.message, 'erro'); }
}

// Envio completo da coleta ao Painel APS: abre a coleta, grava as etapas (idempotente) e conclui.
// As linhas enviadas já incluem os indicadores calculados no nível equipe; os cubos vão em lotes.
async function painelFetch(caminho, metodo, corpo) {
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1' + caminho, { method: metodo,
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave }, body: JSON.stringify(corpo) });
  if (!r.ok) { let m = ''; try { m = (await r.json()).erro || ''; } catch (_) { /* sem corpo */ } throw new Error(`HTTP ${r.status}${m ? ' – ' + m : ''}`); }
  return r.json();
}

async function enviarColeta(coleta) {
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Indicadores guardados só neste computador (envio ao Painel APS não configurado).'); return; }
  const aviso = m => { coleta.avisos.push(m); log(m, 'erro'); };
  try {
    await painelFetch('/coletas', 'POST', { id: coleta.id, competencia: coleta.competencia, tipo: 'completa', versaoExtensao: coleta.versao,
      iniciadoEm: coleta.iniciadoEm, config: coleta.config });
  } catch (e) { aviso('Coleta não enviada ao Painel APS: ' + e.message); return; }

  const etapas = [];
  const porUnidade = new Map();
  const linhas = linhasCalculadas(coleta, filtrosPadrao()).map(l => Object.assign({}, l, { unidade: l.unidade || 'Município', equipe: l.equipe || 'Município' }));
  for (const l of linhas) { if (!porUnidade.has(l.unidade)) porUnidade.set(l.unidade, []); porUnidade.get(l.unidade).push(l); }
  for (const [unidade, ls] of porUnidade) etapas.push({ chave: 'unidade:' + unidade, bloco: 'unidade', unidade, linhas: ls });
  const lote = (lista, n = 10000) => { const o = []; for (let i = 0; i < lista.length; i += n) o.push(lista.slice(i, i + n)); return o; };
  lote(coleta.cubos.atendimentos || []).forEach((l, i) => etapas.push({ chave: 'cubo-atendimentos:' + (i + 1), bloco: 'cubos', cubos: { atendimentos: l } }));
  lote(coleta.cubos.absenteismo || []).forEach((l, i) => etapas.push({ chave: 'cubo-absenteismo:' + (i + 1), bloco: 'cubos', cubos: { absenteismo: l } }));
  lote(coleta.cubos.escuta || []).forEach((l, i) => etapas.push({ chave: 'cubo-escuta:' + (i + 1), bloco: 'cubos', cubos: { escuta: l } }));
  etapas.push({ chave: 'avisos', bloco: 'avisos', avisos: coleta.avisos.slice(0, 500) });

  let falhas = 0;
  for (const et of etapas) {
    let ok = false, erro = '';
    for (let t = 1; t <= 3 && !ok; t++) {
      try { await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/etapa`, 'PUT', Object.assign({ status: 'ok', coletadoEm: coleta.iniciadoEm, tentativas: t }, et)); ok = true; }
      catch (e) { erro = e.message; await UTIL.dormir(1500 * t); }
    }
    if (!ok) { falhas++; log(`Etapa "${et.chave}" não enviada: ${erro}`, 'erro'); coleta.avisos.push(`Painel APS: etapa "${et.chave}" não enviada (${erro}).`);
      try { await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/etapa`, 'PUT', { chave: et.chave, bloco: et.bloco, unidade: et.unidade, status: 'falhou', erro, coletadoEm: coleta.iniciadoEm }); } catch (_) { /* sem rede */ } }
  }
  try {
    const r = await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/concluir`, 'POST', { status: falhas || estado.cancelar ? 'parcial' : 'concluida', concluidoEm: new Date().toISOString() });
    coleta.enviadoEm = new Date().toISOString();
    log(`Coleta enviada ao Painel APS (${r.etapas.ok} etapas ok${r.etapas.falhas ? ', ' + r.etapas.falhas + ' com falha' : ''}).`, falhas ? 'erro' : 'ok');
  } catch (e) { aviso('Coleta não concluída no Painel APS: ' + e.message); }
}
document.addEventListener('DOMContentLoaded', async () => {
  const u = $('painelUrl'), k = $('painelChave'); if (!u || !k) return;
  const v = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  u.value = v.painelUrl || 'https://painelaps.pages.dev'; k.value = v.painelChave || '';
  const salvar = () => chrome.storage.local.set({ painelUrl: u.value.trim(), painelChave: k.value.trim() });
  u.addEventListener('change', salvar); k.addEventListener('change', salvar);
});

async function lerHistorico() { return (await chrome.storage.local.get('coletas')).coletas || []; }
async function salvarColeta(c) { const h = await lerHistorico(); h.unshift(c); await chrome.storage.local.set({ coletas: h }); }

async function renderizarHistorico() {
  const h = await lerHistorico();
  const ul = $('historico');
  ul.innerHTML = h.length ? '' : '<li><small>Nenhuma coleta ainda.</small></li>';
  for (const c of h) {
    const li = document.createElement('li');
    const quando = new Date(c.iniciadoEm).toLocaleString('pt-BR');
    li.innerHTML = `<span><strong>${c.competencia}</strong> <small>coletado em ${quando}${c.avisos.length ? ` · ${c.avisos.length} aviso(s)` : ''}</small></span>
      <span class="acoes"><button class="sec" data-a="ver">Ver</button><button class="sec" data-a="excluir">Excluir</button></span>`;
    li.querySelector('[data-a="ver"]').onclick = () => { estado.coletaAtual = c; renderizar(); $('secResultado').scrollIntoView(); };
    const bx = li.querySelector('[data-a="excluir"]');
    bx.onclick = async () => {
      if (bx.dataset.confirmar !== '1') { bx.dataset.confirmar = '1'; bx.textContent = 'Confirmar'; return; }
      await chrome.storage.local.set({ coletas: (await lerHistorico()).filter(x => x.id !== c.id) });
      renderizarHistorico();
    };
    ul.appendChild(li);
  }
}

function baixar(nome, conteudo, tipo) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([conteudo], { type: tipo }));
  a.download = nome; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

function exportarJSON(c) {
  if (!c) return;
  const pacote = Object.assign({}, c, {
    indicadores: ['municipio', 'unidade', 'equipe'].flatMap(n => agregarNivel(linhasCalculadas(c, filtrosPadrao()), n).map(l => Object.assign({ nivel: n }, l)))
  });
  baixar(`indicadores-aps-${c.competencia}.json`, JSON.stringify(pacote, null, 2), 'application/json');
}

function exportarCSV(c) {
  if (!c) return;
  const linhas = ['municipio', 'unidade', 'equipe'].flatMap(n => agregarNivel(linhasCalculadas(c, filtrosPadrao()), n).map(l => Object.assign({ nivel: n }, l)));
  const cab = ['competencia', 'nivel', 'codigo', 'indicador', 'unidade', 'equipe', 'numerador', 'denominador', 'soma_pontos', 'resultado'];
  const esc = v => `"${String(v === null || v === undefined ? '' : v).replace(/"/g, '""')}"`;
  const corpo = linhas.map(l => [c.competencia, l.nivel, l.codigo, (CATALOGO[l.codigo] || {}).nome || '', l.unidade, l.equipe, l.numerador, l.denominador, l.somaPontos,
    l.resultado === null ? '' : String(+l.resultado.toFixed(2)).replace('.', ',')].map(esc).join(';'));
  baixar(`indicadores-aps-${c.competencia}.csv`, '﻿' + [cab.join(';'), ...corpo].join('\n'), 'text/csv');
}
