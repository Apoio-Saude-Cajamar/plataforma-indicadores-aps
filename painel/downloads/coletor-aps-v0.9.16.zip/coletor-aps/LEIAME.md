# Coletor de Indicadores APS – Cajamar (v0.9.16)

Extensão do Chrome que coleta, uma vez por mês, os indicadores da Atenção Primária a partir do PEC e-SUS APS (esus.cajamar.sp.gov.br), usando a sessão já aberta no navegador.

**v0.9.16:** a **C1** também deixa de ser calculada quando a coleta leu a escuta inicial mas não os atendimentos (a C1 saía zerada). O quadro acima de "Iniciar coleta" avisa quando só um dos dois itens da C1 está marcado ("C1 · Atendimentos" e "Escuta inicial na C1").

**v0.9.15:** **atendimentos e absenteísmo viram dois itens.** "C1 · Atendimentos" fica no cofinanciamento federal; "Absenteísmo (Q14.2.1)" passa para o acompanhamento municipal (ele também lê os atendimentos, que entram no denominador). A **C1** só é calculada nas unidades em que a escuta inicial foi lida na mesma coleta: sem a escuta (demanda espontânea), o denominador ficava menor e a C1 saía acima do real, passando por cima da C1 correta no Painel. O **Q14.2.1** só é calculado quando o absenteísmo foi lido (antes, uma coleta só com atendimentos gerava Q14.2.1 com faltas zeradas). A **coleta retroativa** devolve no fim a competência que estava no campo (antes ficava no último mês coletado, e o "Iniciar coleta" seguinte ia para esse mês sem aviso). O **"Refazer falhas"** devolve, ao terminar, as unidades e os itens que estavam marcados (antes a seleção ficava gravada sem os itens do município).

**v0.9.14:** **uma coleta por vez.** O PEC tem um só acesso ativo por login; duas coletas ao mesmo tempo (clique duplo em "Iniciar coleta" ou o painel aberto em outra janela/área de trabalho) trocavam a unidade uma da outra e derrubavam as consultas ("Acesso não permitido", "Failed to fetch", "message channel closed"). Agora uma trava vale para todos os painéis da extensão: a segunda coleta não começa e o painel diz por quê. Se o painel dono fechar, a trava se solta na hora (ou em até 3 minutos). **Novas tentativas automáticas:** cada pedido ao PEC é repetido até 2 vezes em falha de rede ou erro HTTP do servidor (não em sessão caída nem em erro do próprio PEC); a equipe que falha inteira é lida de novo; cada etapa do município (atendimentos e absenteísmo, filas, vacinas, atividades coletivas, produção, eMulti) e de cada unidade (pessoas da eMulti, agendas, faltas por horário, composição, CR4, escuta inicial, saúde bucal) ganha mais uma tentativa depois de 5 s; e as unidades com ✗ são coletadas de novo, uma vez, no fim, antes do envio ao Painel. O que ainda falhar continua no botão "Refazer falhas". Uma falha no relatório de atendimentos e absenteísmo não interrompe mais a coleta. **Mais rápido:** as equipes da mesma unidade são lidas ao mesmo tempo (3 por vez, em `equipesParalelas` no config); as unidades continuam uma de cada vez.

**v0.9.13:** a **Coleta retroativa** no modo "Só dados com data no atendimento" passa a trazer tudo o que o PEC devolve pelo período pedido: C1 (atendimentos e escuta inicial), B1, B2, B3, B5 e B6 (relatório de atendimento odontológico), B4, M1 e M2, vacinas, produção por profissional, atendimentos, absenteísmo e faltas por horário. Antes eram só atendimentos, absenteísmo, produção e B4. Como C1, saúde bucal e eMulti são lidas por unidade, o modo pede ao menos uma unidade marcada e leva mais tempo (cerca de 37 min por mês com 11 unidades; a confirmação mostra a estimativa). As pessoas vinculadas (Q12.2 e VINC6A12, divisor de B1 e B4) vêm do cadastro de hoje: entram na conta, mas não são enviadas ao Painel nesse modo, para não trocar o número do mês pelo de hoje. O aviso de "Todos os itens" foi corrigido: M1 e B1 a B3 não são indicadores de situação; os de situação são C2 a C7, CR, território e CVAT, composição e filas. Com "Substituir todos os dados da competência", a confirmação avisa que esses itens saem do Painel nos meses coletados só com dados com data.

**v0.9.12:** **eSB ligada a eAP:** a B1 e a B4 passam a usar a população inteira da eAP. Pela nota, eSB de 20 h liga-se a eAP de 20 h, eSB de 30 h a eAP de 30 h e eSB de 40 h a duas eAP de 20 h, e o divisor é a população inteira da(s) eAP; a divisão por 2 vale só para eSB de 20 h ligada a eSF de 40 h. Antes, qualquer eSB de 20 h tinha o divisor pela metade, o que inflava B1 e B4 da eSB ligada à eAP (em Cajamar, a ESB 2 Jordanésia, ligada à EAP Jordanésia 2). A conferência de carga horária deixa de avisar "menos de 40 h" para eAP. Precisa refazer a coleta de B1 e B4 das unidades com eSB ligada a eAP para valer. Também: o texto abaixo sobre a B4 e os CBOs foi atualizado (a regra já era a da v0.9.7).

**v0.9.11:** a **Coleta retroativa** ganha a escolha do que levar a cada mês: só os dados com data no atendimento (como antes) ou **todos os itens e unidades marcados** na tela, como em uma coleta de um mês. Com todos os itens, os indicadores de situação (C2 a C7, CVAT, M1…) mostram o cadastro do PEC na data da coleta, não o do mês; o aviso aparece na confirmação e fica nas observações da coleta. A escolha "Se esta competência já foi enviada" vale para todos os meses do lote, com uma só confirmação. A confirmação mostra o tempo estimado.

**v0.9.10:** M1 e M2 conforme as notas (NT 43 e 44/2026). **M2:** a atividade coletiva compartilhada passa a exigir 2 ou mais profissionais de nível superior ou médio, pessoas diferentes (CPF/CNS), com pelo menos 1 CBO de eMulti; as reuniões de discussão de caso/PTS (códigos 01 a 03 com esse tema) entram; e o **compartilhamento do cuidado** respondido pela eMulti entra no numerador e no denominador (consulta nova ao PEC; só contagem por equipe, nada do cidadão). **M1:** só contam participantes de atividades coletivas com CPF ou CNS válido. CPF/CNS são lidos só na memória e descartados. Nas Inconsistências, o código COLET (totais de produção) deixa de aparecer como suspeito e a B4 acima de 100% passa a ser informação, porque a nota não exige que a criança seja vinculada à equipe. Precisa refazer a coleta da eMulti (M1 e M2) para valer.

**v0.9.9:** nova caixa **Coleta retroativa (vários meses de uma vez)**, em "Nova coleta". Escolha o período (de/até) e a extensão coleta um mês por vez, só com o que tem data no atendimento: atendimentos e absenteísmo do município, produção por profissional e B4. Cada mês vai ao Painel separado, no modo "atualizar só o marcado" (nada é apagado). Os indicadores de situação (C2 a C7, CVAT, M1…) ficam de fora de propósito: o PEC mostra o cadastro de hoje, então o valor de um mês antigo sairia errado. Se um mês falhar, o resumo final diz quais refazer.

**v0.9.8:** novo item **Produção por profissional (individual e coletiva)**, no grupo "Produção para as equipes": para cada profissional das unidades de APS, os atendimentos individuais do mês (por tipo e quantos foram compartilhados, pelo relatório gerencial de atendimentos) e as atividades coletivas em que foi o responsável ou participou, com o número de participações. Vai ao Painel com nome e cargo do profissional (como em Filas e faltas), só para administradores e gestores; nenhum dado de paciente. Não fica no histórico da extensão. Também na v0.9.8: a leitura das atividades coletivas (já feita para a B4 e a eMulti) passa a enviar ao Painel os totais de todas as equipes: atividades, atividades com mais de um profissional, participações e pessoas diferentes (código COLET, só números). Servem ao relatório "Produção e notas" do Painel. Para tê-los, marque B4 ou eMulti na coleta.

**v0.9.7:** nova escolha antes de "Iniciar coleta", para quando a competência já foi enviada: **atualizar só os itens e unidades marcados** (padrão, como antes) ou **substituir todos os dados da competência** no Painel, para receber as atualizações do PEC sem sobras da coleta anterior. Substituir pede confirmação e só vale se a coleta terminar completa (sem unidade com falha nem cancelamento); senão, os dados anteriores são mantidos. Nada é apagado no Painel: as etapas antigas ficam marcadas como substituídas. "Refazer só as que falharam" sempre usa a primeira opção.

Ainda na v0.9.7: B4 (escovação supervisionada) pela lista de CBOs da nota: cirurgiões-dentistas 2232-08, 2232-93 e 2232-72, TSB 3224-05 e 3224-25 e ASB 3224-15 e 3224-30. Antes só contavam as escovações com dentista 223293/223208; agora as feitas só por ASB ou TSB da equipe também contam. A criança de 6 a 12 anos só entra no numerador com CPF ou CNS válido (dígitos verificadores conferidos na memória; o número é descartado e não é enviado). Vão ao Painel, só como totais, os números da conferência: participações, crianças distintas, participações sem documento, maior atividade, crianças contadas em mais de uma equipe e escovações sem CBO aceito.

**v0.9.6:** novo botão **Inconsistências (PDF)** (no resultado e em cada coleta do histórico). Abre uma página com o que ficou faltando ou parece errado na coleta: unidades que falharam e o motivo, indicadores ausentes por unidade, valores suspeitos (numerador maior que o denominador, denominador zero), unidades sem filas, horários ou composição e os avisos da coleta; é só imprimir e escolher "Salvar como PDF". Só totais, nenhum dado de paciente ou de profissional. A extensão passa a guardar junto de cada coleta apenas contagens por unidade para isso.

**v0.9.5:** o botão "Refazer só as que falharam" agora marca as unidades com erro **e já inicia a recoleta**; antes só marcava e era preciso clicar de novo em "Iniciar coleta".

**v0.9.4:** "Mais acesso (C1)" e "Cuidado ao longo da vida (C2 a C7)" passam a um só grupo, "eSF e eAP (C1 a C7)", como no Caderno de ações do Componente Qualidade (a C1 é o indicador 1 do bloco das equipes de Saúde da Família). O mesmo agrupamento vale no Painel.

**v0.9.3:** a lista de itens passa a ser organizada por finalidade (cofinanciamento federal, estadual, acompanhamento municipal e gestão). Cada item ganha um selo com o modo (município, por unidade ou os dois) e o custo em minutos, e um ícone ⓘ com a fonte no PEC, como é lido, o que vai ao Painel e o que é dado pessoal. Acima do botão "Iniciar coleta" aparece um resumo do que vai acontecer. O mesmo texto está na página "Como coletamos" do Painel APS (`shared/extracao.js` aqui, `painel/js/extracao.js` lá).

**v0.9.2:** novo item "Vacinas" (doses aplicadas) para o cofinanciamento estadual. Uma chamada ao relatório gerencial de vacinação do PEC traz, para o município inteiro, as doses de pólio, penta, pneumocócica, tríplice viral e HPV por faixa etária e dose, só totais. O Painel APS usa isso como estimativa ao lado do valor oficial lançado. Vale para qualquer mês: escolha a competência desejada, inclusive meses passados.

**v0.9.1:** novo item "Faltas por horário" no grupo "Filas e faltas". A extensão lê a agenda do mês de cada médico e enfermeiro com agenda ativa (uma consulta por profissional) e monta a grade dia da semana × hora com consultas agendadas, atendidas e faltas (não compareceu e não aguardou). Reservas e bloqueios não entram. De cada agendamento são pedidos só o horário, a situação e o tipo; nenhum dado do cidadão. O Painel mostra o resultado na aba "Faltas por horário" de Filas e faltas.

**v0.9.0:** CVAT pela regra da NT 30/2025, pessoa a pessoa, sem abrir casa por casa. A extensão lê os imóveis de cada rua (Acompanhamento do território) e o histórico de visitas de cada imóvel visitado em 12 meses. Cadastro: conta 1,5 quem tem a ficha individual em dia e mora num imóvel atualizado em 24 meses (antes era uma estimativa por microárea, com o corte de 1 ano do PEC). Acompanhamento: além de dois tipos diferentes de contato, conta quem teve 2 ou mais visitas domiciliares realizadas em 12 meses. Privacidade: a consulta usa o nome da rua como filtro e os identificadores internos e a data de nascimento para ligar pessoa, casa e visita, tudo só na memória; continuam sem ser pedidos nome, CPF, CNS, telefone e número da casa, e só os totais são enviados. Desligar: `CONFIG.cvat.detalharTerritorio = false`.

**v0.8.9:** CVAT com o parâmetro por população do município (100.000 habitantes = porte "acima de 50 mil até 100 mil", NT 30/2025; campo `CONFIG.cvat.populacao`). M1 com aviso de equipe do relatório sem equipe eMulti correspondente, mais tentativas na leitura das atividades coletivas (aviso com a quantidade de falhas) e `numeradorMinimo` no detalhe. Ainda não incluído: conferir CPF/CNS válido e atendimentos como profissional secundário (precisam de teste no PEC).

**v0.8.8:** novo grupo "Filas e faltas": faltas e atendimentos por profissional e dias até a próxima vaga na agenda, só para médicos e enfermeiros da Atenção Primária.

**v0.8.7:** "Cancelar" para a etapa em curso em segundos (antes esperava a etapa terminar e parecia travado).

**v0.8.6:** quando a sessão do PEC cai no meio da coleta, a extensão avisa com clareza, para de tentar as unidades seguintes e deixa todas prontas para o "Refazer falhas".

**v0.8.5:** M1 e M2 passam a considerar só os CBOs da eMulti listados nas NT 43 e 44/2026; faixas de classificação nos balões (i).

**v0.8.4:** os relatórios do município (atendimentos, absenteísmo, atividades coletivas, eMulti) passam a rodar com o acesso de uma unidade de APS; com o acesso "Secretaria de Saude" o PEC devolvia 403.

**v0.8.3:** CR4 segue pelo relatório filtrado (sem consulta a prontuário), com o aviso no balão (i); o M1 registra o período dos 4 meses usado no cálculo.

**v0.8.2:** M1 passa a usar os últimos 4 meses (janela móvel da NT 43/2026); textos do Bolsa Família corrigidos (já é considerado).

## v0.8.8b — (i) com numerador e denominador de todas as notas

## Instalação (modo desenvolvedor)

1. Descompacte o arquivo `coletor-aps-v0.8.8.zip` numa pasta fixa (por exemplo, `Documentos\coletor-aps`). Não apague a pasta depois.
2. No Chrome, abra `chrome://extensions`.
3. Ligue **Modo do desenvolvedor** (canto superior direito).
4. Clique em **Carregar sem compactação** e escolha a pasta descompactada.
5. Fixe o ícone da extensão na barra (ícone de quebra-cabeça → alfinete).

## Uso mensal

1. Abra o PEC, faça login e escolha qualquer acesso. Se o PEC já estava aberto antes de instalar, recarregue a aba (F5).
2. Clique no ícone da extensão: o painel lateral abre.
3. Confira a competência (vem sugerido o mês anterior) e clique em **Iniciar coleta**.
4. Mantenha o painel aberto e a aba do PEC aberta até terminar. Leva cerca de 1 minuto por unidade, mais uns 20 segundos por equipe eSF/eAP para a escuta inicial (em torno de 20 minutos no total). Evite usar o PEC nessa aba durante a coleta.
5. Ao final, a coleta fica no **Histórico**. Use **Exportar CSV** ou **Exportar JSON**.

Durante a coleta a extensão troca o acesso entre as 11 unidades e, no fim, volta ao acesso que estava em uso. O cabeçalho do PEC só mostra a unidade correta depois de recarregar a página.

Para a escuta inicial, a extensão abre o relatório de produção *Atendimento individual* em cada unidade e exporta um CSV por equipe e categoria (médico e enfermeiro). Esses arquivos aparecem na fila "Relatórios em processamento/processados" do PEC, mas **não são baixados no computador**: a extensão lê o conteúdo direto do PEC e guarda só os totais.

## O que esta versão coleta

| Indicador | Fonte no PEC | Nível |
|---|---|---|
| C1 – Mais acesso | Gerencial de atendimentos (CBOs exatos) + relatório de produção Atendimento individual (escuta inicial) | município, unidade, equipe |
| Q14.2.1 – Absenteísmo de consultas: faltas ÷ (atendimentos + faltas) | Gerenciais de absenteísmo e de atendimentos | município, unidade, equipe; filtros por grupo de CBO e tipo de falta |
| Q12.2 – Pessoas vinculadas por equipe | Cidadãos vinculados | equipe |
| C2, C3, C4, C5, C6 | Condições de saúde (listas temáticas) | equipe |
| S3, S4, S20 | Condições de saúde – Gestação e puerpério | equipe |
| CR1 – Mais acesso à eCR | Condições de saúde – Geral (equipe eCR) | equipe |
| B1, B2, B3, B5, B6 – Saúde bucal | Relatório de produção *Atendimento odontológico*, exportado por equipe eSB | equipe eSB |
| B4 – Escovação supervisionada (6 a 12 anos) | Atividades coletivas (prática "Escovação dental supervisionada"), idade calculada na data da atividade | equipe eSB |
| M2 – Ações interprofissionais (parte coletiva) | Atividades coletivas com 2 ou mais profissionais, uma eMulti entre eles | equipe eMulti |
| M1 – numerador | Gerencial de atendimentos (equipes eMulti) + participações em atividades coletivas | equipe eMulti |

## Privacidade (LGPD)

- **Atividades coletivas:** para cada atividade a extensão pede só tipo, práticas, equipe e CBO dos profissionais e, dos participantes, o identificador interno do PEC, a data de nascimento, o CPF e o CNS. Com isso calcula a idade, evita contar a mesma criança duas vezes no mês e confere se ela está identificada por CPF ou CNS válido, como a nota B4 exige (só os dígitos verificadores; o número é descartado na hora). Depois descarta tudo e guarda apenas totais por equipe. O nome não é pedido.

- As consultas às listas pedem ao PEC **somente datas, contagens, marcadores e identificadores internos** (por exemplo, "consultas no pré-natal: 7"). Nome, CPF, CNS, telefone e número da casa **não são solicitados** (exceção: CPF e CNS dos participantes de atividades coletivas, só para conferir a validade na B4, sem guardar nem enviar).
- **CVAT (imóveis e visitas):** o PEC lista os imóveis rua a rua, então a extensão lê o nome das ruas da microárea e o usa só como filtro da consulta seguinte. De cada imóvel pede a data da última atualização, a data da última visita e o identificador interno dos moradores; de cada visita, a data, o desfecho e o identificador interno e a data de nascimento da pessoa visitada. Com isso liga pessoa, casa e visita na memória e guarda só os totais por equipe.
- A pontuação de cada pessoa é calculada na memória do navegador e descartada; ficam guardados apenas totais por equipe.
- Sem chave de coleta, nada é enviado para fora do computador; com ela, só os totais agregados vão ao Painel APS. O histórico fica no armazenamento local da extensão.
- A extensão não lê nem guarda usuário ou senha: usa a sessão aberta pelo próprio usuário.

## Decisões e pendências

- **Q14.2.1**: entram por padrão médicos (CBO 2251/2252/2253), enfermeiros (2235) e dentistas (2232); eMulti e técnicos podem ser ligados nos filtros. Os dois tipos de falta entram por padrão.
- **C1** (Nota C1): só os CBOs 225142, 225170, 225130, 225125, 225250, 223565 e 223505, em equipes eSF/eAP. A escuta inicial (demanda espontânea), que o relatório gerencial não apresenta, é lida do relatório de produção Atendimento individual por equipe e pelas categorias médico e enfermeiro, e somada ao denominador. Conferência em out/2026 (equipe Ponunduva): os atendimentos de médicos e enfermeiros sem a escuta bateram exatamente nas duas fontes (449). A opção pode ser desligada no painel.
- **C2 item E** (Nota C2): pentavalente 3 doses, VIP 3 doses (intervalo mínimo de 30 dias), tríplice/tetraviral 2 doses aplicadas a partir dos 12 meses e pneumocócica 2 doses. Usa o grupo do imunobiológico informado pelo PEC.
- **C3** (Nota C3): gestação sem desfecho é encerrada aos 294 dias e o puerpério vai até 42 dias depois (336 dias). Só sai do denominador quem passou de 336 dias na data de referência. **Isso difere da planilha**, que desconsiderava toda gestação acima de 42 semanas.
- **eAP**: nas práticas de visita domiciliar (C2-D, C3-E/J, C4-D, C5-D, C6-C), equipes eAP recebem pontuação integral, como determinam as notas.
- **Momento da coleta**: as listas do PEC mostram a situação no dia da coleta (não há data de referência). Por isso a coleta deve ser feita no início de cada mês.
- **Diabetes e hipertensão**: seguem o critério da própria tela (problema ativo na lista de problemas).

## Saúde bucal e eMulti (novos na v0.4.0)

- **B1 a B6** seguem as notas do MS de 02/10/2026; os códigos SIGTAP de cada nota estão em `shared/config.js` (`saudeBucal`).
- **B1 e B2** contam registros do relatório (primeiras consultas e tratamentos concluídos no mês). A nota do MS conta cada pessoa uma vez a cada 12 meses por dentista; a diferença tende a ser pequena.
- **eSF/eAP de referência** (divisor de B1 e B4): a coleta lê o vínculo oficial do PEC (Unidades de saúde → equipe → Equipes vinculadas). A carga horária de cada eSB é a soma das grades de agenda dos seus dentistas; cada eSB fica com horas ÷ máx(40, horas de todas as eSB da eSF) da população (uma eSB de 20 h sozinha conta metade, como manda a nota). Quando a eSB está ligada a uma **eAP**, usa a população inteira da eAP (eSB 20 h ↔ eAP 20 h, 30 h ↔ 30 h, 40 h ↔ 2 eAP de 20 h). Correções pontuais podem ir em `saudeBucal.referencia`. Ao final, a coleta avisa eSF sem eSB, com menos de 40 h ou com mais de 40 h de eSB.
- **B4** conta crianças de 6 a 12 anos diferentes no mês, por eSB responsável ou envolvida na escovação.
- **eMulti**: Complementar 1, 2 e 3 e Estratégica 1, reconhecidas pelo tipo de equipe no PEC (INEs em `emulti.ines`).
- **M2** ainda é parcial: só atividades coletivas. Falta o atendimento individual compartilhado.
- **M1** ainda sem divisor: o PEC não traz, em relatório agregado, o número de pessoas diferentes atendidas.

## Novos na v0.4.1

- **Território** (opção "Território"): por equipe, imóveis com cadastro atualizado há menos de 1 ano, cadastro completo e domicílios visitados no mês, somando as microáreas. A microárea **FA (fora de área)** não entra; fica guardada à parte (TERR-FA), com o detalhe por microárea, para planejamento. O PEC só mostra as visitas do mês corrente: para TERR-VIS, colete no fim do mês.
- **C7** (Nota C7): nota = A×20 + B×30 + C×30 + D×20, cada item com o seu denominador (faixa etária do item). Entram pessoas de sexo feminino (menos mulheres trans) e homens trans.
  - A: exame de colo solicitado ou avaliado em 36 meses (HPV molecular: 60); B: dose de HPV em 9 a 14 anos; D: mamografia em 24 meses.
  - C: o PEC filtra um código por vez (vários códigos = "todos ao mesmo tempo"), por isso cada CIAP/CID da nota é consultado em separado e o resultado é unido. É aproximado: o PEC não informa a data do código, só a do último atendimento médico ou de enfermagem (12 meses). Leva cerca de 1 minuto por equipe; dá para desligar (opção "C7 item C").
- **CVAT** (NT 30/2025, porte 50 a 100 mil): parâmetro eSF 2.750, eAP 30 h 2.063, eAP 20 h 1.375 (`cvat.eapHoras` / `cvat.eapHorasPorEquipe`).
  - Cadastro: cadastro individual de origem CDS atualizado em 24 meses × 0,75, mais 0,75 estimado pela fração de imóveis atualizados da microárea da pessoa. Ficam fora: "Fora da área", cadastro só no PEC e cadastro vencido.
  - Acompanhamento: pessoa com 2 tipos diferentes de contato em 12 meses (médico, enfermagem, odontologia, visita domiciliar), pesos 1,0 / 1,2 (menor de 5 ou 60+) / 1,3 (Bolsa Família) / 2,5. É um piso: o PEC informa só a data do último contato de cada tipo.
  - O divisor do acompanhamento não está escrito na nota; o padrão é o parâmetro da equipe (`cvat.denominadorAcompanhamento`). Sem o bônus de satisfação.
- **CR2** (gestação na eCR), **CR3** (testes de sífilis, HIV e hepatites em 12 meses) e **CR4** parcial (pessoas com tuberculose e o teste de HIV; consultas, baciloscopia e raio X sem fonte).

## Novos na v0.8.0

- **Barra de progresso:** percentual, etapa atual, tempo restante estimado e um indicador por unidade (⏳ ✓ ⚠ ✗). O registro detalhado fica recolhido.
- **Layout:** conexão com o PEC em uma linha; grupos recolhíveis com caixa e contador; atalhos "Completa", "Só município" e "Limpar"; a última seleção é lembrada; botão fixo no rodapé com estimativa de tempo e a duração da última coleta.
- **Inconsistências (PDF):** relatório imprimível com falhas por unidade, indicadores ausentes e valores suspeitos da coleta.
- **Refazer só as que falharam:** depois de uma coleta com unidades com erro, um botão marca só essas unidades e já refaz a coleta nelas.

## Novos na v0.7.0

- **"O que coletar" organizado por tema:** Mais acesso (C1), Cuidado ao longo da vida (C2 a C7, cada um separado), Vínculo e acompanhamento territorial (território, CVAT), Odontologia (B1 a B6), eMulti (M1, M2), Consultório na Rua (CR1 a CR4) e Estrutura (composição). Dá para coletar só um tema, e a extensão só passa pelas unidades quando algum item "por unidade" está marcado. Há "marcar tudo" e "limpar".

## Novos na v0.6.2

- **"O que coletar" reorganizado em dois grupos:** (1) município inteiro (atendimentos e absenteísmo, atividades coletivas, eMulti) e (2) por unidade, com as opções que dependem da troca de acesso (território, CVAT, C7 item C, escuta inicial, saúde bucal, composição) recuadas sob "Indicadores por unidade" e desativadas quando ele está desmarcado.

## Novos na v0.6.1

- **Mais resistente a recarregamentos do PEC:** se o canal com a página cair (troca de acesso, relatório clássico), a extensão espera a página voltar e tenta de novo; antes de cada unidade volta à página inicial do PEC.

## Novos na v0.6.0

- **Composição das equipes** (opção "Composição das equipes"): em cada unidade, lê o quadro de lotação (profissional, categoria e equipe) na lista de profissionais do relatório clássico. O CNS do profissional é descartado na leitura. Monta a árvore município → unidade → equipe → profissionais, com os vínculos entre equipes e as horas das eSB, e avalia: equipe sem a composição mínima (regras em `composicao.minimo`), eSB sem vínculo, eMulti com poucas equipes, ACS, dentistas e profissionais da ESF sem equipe, lotação em equipe que não está ativa na unidade e profissional em mais de uma equipe. Para guardar só as categorias, sem nomes, use `composicao.guardarNomes: false`.
- **Envio ao Painel APS:** com o endereço e a chave de coleta preenchidos no painel da extensão, a composição é enviada para a página "Composição" do Painel APS.

## Novos na v0.4.3

- **Saúde bucal só com dentistas da APS.** B1 a B6 consideram apenas o Cirurgião-dentista da Estratégia de Saúde da Família (CBO 223293) e o Cirurgião-dentista clínico geral (CBO 223208). O relatório odontológico é exportado pela categoria "Cirurgião dentista" (sem ASB e TSB); se a equipe tiver dentista de outro CBO (ex.: saúde coletiva), a produção dele é exportada à parte e descontada. A B4 segue a lista de CBOs da nota (cirurgiões-dentistas 2232-08, 2232-93 e 2232-72, TSB 3224-05 e 3224-25, ASB 3224-15 e 3224-30), com CPF ou CNS válido da criança; escovações sem nenhum desses CBOs na equipe viram observação. As horas da eSB somam só as agendas dos dentistas de CBO 223293 e 223208.

## Novos na v0.4.2

- **eMulti completa** (opção "eMulti"):
  - **M2**: (atendimentos individuais com "Atendimento compartilhado" + atividades coletivas com 2 ou mais profissionais) ÷ (atendimentos individuais + atividades coletivas), no mês, pelo relatório gerencial de atendimentos.
  - **M1** (quadrimestre até o mês da coleta): (atendimentos individuais + participações em atividades coletivas) ÷ pessoas diferentes. As pessoas vêm da lista de atendimentos de cada unidade e dos participantes das atividades; para contar a mesma pessoa uma vez só entre unidades, a coleta usa resumos com um sal sorteado na hora, que ficam só na memória e são descartados no fim. Atendimentos só em ficha CDS entram por estimativa, com faixa mínima e máxima.
- **CR4**: itens A, B e C pelo relatório de atendimento individual da eCR em 6 meses, filtrado pelos CIDs de tuberculose da nota. O relatório dá totais, então cada item vem como teto, com faixa. Sem nenhum atendimento com esses CIDs, o PEC não gera o arquivo e os itens contam zero.
- **Observações**: o que a nota não conta, mas vale acompanhar (cadastro só no PEC, cadastro vencido, pessoas e imóveis fora de área, sem microárea, contato de um só tipo, sem contato em 12 meses), por equipe, em `observacoes` da coleta, para a futura página de observações.
- **Balão (i)**: indicadores aproximados mostram a precisão e a justificativa ao passar o mouse no "i"; quando há faixa, ela aparece ao lado do resultado.
- eAP: Cajamar tem uma eAP ativa, de 20 h (parâmetro 1.375 na CVAT).

## Ainda não coletados

Bônus de satisfação da CVAT (não será considerado, por decisão da gestão). Bolsa Família da CVAT: já considerado (marcador do PEC, peso 1,3); BPC: fora, não consta no PEC. Há uma nota informativa na página Federal do Painel e no balão (i) da CVAT.

## Personalização

- Unidades, grupos de CBO e esquema vacinal: `shared/config.js`.
- Cores e fonte (identidade visual): `panel/tema.css`.
- Consultas ao PEC (se uma atualização do PEC mudar algum campo): `content/queries.js`.
