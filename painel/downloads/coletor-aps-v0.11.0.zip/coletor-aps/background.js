// O ícone da extensão só ABRE o painel lateral (nunca fecha). Antes o clique alternava abrir/fechar, e fechar o painel
// no meio de uma coleta a interrompia. Para fechar, use o X do próprio painel.
const comportamento = () => chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
chrome.runtime.onInstalled.addListener(comportamento);
chrome.runtime.onStartup.addListener(comportamento);
chrome.action.onClicked.addListener(tab => {
  chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {});
});
