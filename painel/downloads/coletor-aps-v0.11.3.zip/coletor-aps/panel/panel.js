// Painel lateral: orquestra a coleta, guarda o histórico e calcula os indicadores.
const $ = id => document.getElementById(id);
const estado = { aba: null, cancelar: false, coletaAtual: null, filtros: null };

// ---------------------------------------------------------------- inicialização
document.addEventListener('DOMContentLoaded', async () => {
  $('versao').textContent = 'v' + CONFIG.versao;
  $('competencia').value = UTIL.competenciaAnterior();
  montarUnidades();
  estado.filtros = filtrosPadrao();
  $('btnVerificar').onclick = verificarPEC;
  $('btnColetar').onclick = coletar;
  $('btnRetro').onclick = coletarRetroativo;
  $('retroDe').value = new Date().getFullYear() + '-01'; $('retroAte').value = UTIL.competenciaAnterior();
  $('btnRefazer').onclick = refazerFalhas;
  $('btnRetomar').onclick = retomarColeta;
  $('btnDescartar').onclick = descartarRetomada;
  $('btnCancelar').onclick = () => {
    if (estado.cancelar) return;
    estado.cancelar = true;
    $('btnCancelar').disabled = true; $('btnCancelar').textContent = 'Cancelando…';
    log('Cancelamento solicitado: parando a etapa em curso.');
    if (estado.aba) chrome.tabs.sendMessage(estado.aba.id, { acao: 'cancelar', valor: true }).catch(() => {});
    if (estado.abaAux) chrome.tabs.sendMessage(estado.abaAux.id, { acao: 'cancelar', valor: true }).catch(() => {});
  };
  // Modo de duas abas (experimental): a escolha fica guardada neste navegador.
  chrome.storage.local.get('duasAbas').then(({ duasAbas }) => { if ($('optDuasAbas')) $('optDuasAbas').checked = !!duasAbas; });
  if ($('optDuasAbas')) $('optDuasAbas').onchange = e => chrome.storage.local.set({ duasAbas: e.target.checked });
  $('nivel').onchange = renderizar;
  await iniciarSelecao();
  $('btnJSON').onclick = () => exportarJSON(estado.coletaAtual);
  $('btnCSV').onclick = () => exportarCSV(estado.coletaAtual);
  $('btnInconsist').onclick = () => abrirInconsistencias(estado.coletaAtual);
  chrome.runtime.onMessage.addListener((msg, _r, responder) => {
    if (msg && msg.tipo === 'progresso') log(msg.texto, msg.classe);
    // Outro painel quer saber se a trava ainda tem dono vivo (ver travaViva).
    else if (msg && msg.tipo === 'travaViva' && TRAVA.id && msg.id === TRAVA.id) responder({ viva: true });
  });
  await verificarPEC();
  await renderizarHistorico();
  await mostrarRetomada();
});

function montarUnidades() {
  const div = $('listaUnidades');
  div.innerHTML = '';
  CONFIG.unidadesAPS.forEach((u, i) => {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" checked data-unidade="${i}"> ${u}`;
    div.appendChild(l);
  });
  div.onchange = () => { $('qtdUnidades').textContent = unidadesSelecionadas().length; };
}
const unidadesSelecionadas = () => [...document.querySelectorAll('[data-unidade]')].filter(c => c.checked).map(c => CONFIG.unidadesAPS[+c.dataset.unidade]);

function filtrosPadrao() {
  return {
    grupos: Object.fromEntries(Object.entries(CONFIG.gruposCBO).map(([k, g]) => [k, g.padrao])),
    faltas: Object.fromEntries(CONFIG.tiposFalta.map(t => [t, true]))
  };
}

function log(texto, classe) {
  const li = document.createElement('li');
  li.textContent = `${new Date().toLocaleTimeString('pt-BR')} · ${texto}`;
  if (estado.registro) {
    const t = li.textContent.slice(0, 500);
    estado.registro.push(t); if (estado.registro.length > 3000) estado.registro.shift();
    if (estado.registroPendente) { estado.registroPendente.push(t); if (estado.registroPendente.length > 3000) estado.registroPendente.shift(); }
  }
  if (classe) li.className = classe;
  $('log').appendChild(li);
  $('log').scrollTop = $('log').scrollHeight;
}


// "4 min 12 s", "38 s".
function duracao(ms) {
  const s = Math.round((ms || 0) / 1000);
  return s >= 60 ? `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, '0')} s` : `${s} s`;
}

// ---------------------------------------------------------------- seleção, estimativa e andamento
const ITENS = () => [...document.querySelectorAll('#secColeta .grupo .corpo input[type=checkbox]')];
const marcar = v => { ITENS().forEach(i => { i.checked = v; }); aoMudarSelecao(); };
function atualizarGrupos() {
  document.querySelectorAll('#secColeta .grupo').forEach(g => {
    const it = [...g.querySelectorAll('.corpo input[type=checkbox]')], n = it.filter(i => i.checked).length, cb = g.querySelector('.gcb');
    cb.checked = n === it.length; cb.indeterminate = n > 0 && n < it.length;
    g.querySelector('.cont').textContent = `${n} de ${it.length}`;
  });
  $('optC7C').disabled = !$('optC7').checked;
  const it = ITENS().filter(i => !i.disabled), n = it.filter(i => i.checked).length;
  if ($('qtdItens')) $('qtdItens').textContent = n === it.length ? 'todos os itens marcados' : `${n} de ${it.length} itens marcados`;
}
// Minutos aproximados por item (valores de referência; o tempo real depende do PEC).
const TEMPO = { optMunicipal: [1, 0], optAbsenteismo: [1, 0], optEmulti: [3, 0.3], optB4: [3, 0], optC2: [0, 0.15], optC3: [0, 0.15], optC4: [0, 0.15], optC5: [0, 0.15], optC6: [0, 0.15],
  optC7: [0, 0.3], optC7C: [0, 1.5], optTerritorio: [0, 0.4], optCvat: [0, 1.8], optEscuta: [0, 1], optBucal: [0, 0.8], optCR: [0, 0.2], optComposicao: [0, 0.5], optFilas: [1, 0.3], optFilasHora: [0, 0.2], optVacinas: [0.3, 0], optProducao: [4, 0] };
// Itens que fazem a coleta passar pelas unidades (troca de acesso em cada uma).
const ITENS_UNIDADE = ['optEscuta', 'optC2', 'optC3', 'optC4', 'optC5', 'optC6', 'optC7', 'optTerritorio', 'optCvat', 'optBucal', 'optCR', 'optComposicao', 'optEmulti', 'optB4', 'optFilas', 'optFilasHora'];
// Itens com data no atendimento: o PEC devolve o que aconteceu no período pedido, então valem para meses passados
// (relatórios de produção, atividades coletivas, vacinação e agendas do mês). Os demais (C2 a C7, CR, território,
// CVAT, composição, filas) mostram a situação do cadastro no dia da coleta.
const ITENS_COM_DATA = ['optMunicipal', 'optAbsenteismo', 'optEscuta', 'optBucal', 'optB4', 'optEmulti', 'optVacinas', 'optProducao', 'optFilasHora'];
// Linhas que, mesmo nesse modo, vêm do cadastro de hoje (pessoas vinculadas, divisor de B1 e B4): entram no cálculo,
// mas não vão ao Painel numa coleta retroativa, para não trocar o número do mês pelo de hoje.
const LINHAS_DE_HOJE = ['Q12.2', 'VINC6A12'];
function minutosEstimados(marc, un) {
  const passaUnidades = ITENS_UNIDADE.some(marc);
  let min = 0;
  for (const [id, [fixo, porUn]] of Object.entries(TEMPO)) if (marc(id)) min += fixo + porUn * un;
  min -= 3 * Math.max(0, ['optB4', 'optEmulti', 'optProducao'].filter(marc).length - 1); // a leitura das atividades coletivas é uma só
  if (passaUnidades) min += 0.5 * un; // troca de acesso e recarga da página
  return { min, passaUnidades };
}
function estimar() {
  const marc = id => $(id) && $(id).checked && !$(id).disabled;
  const un = unidadesSelecionadas().length;
  const { min, passaUnidades } = minutosEstimados(marc, un);
  resumirColeta(un, passaUnidades);
  const el = $('estimativa');
  if (!min) { el.textContent = 'Nada marcado.'; return; }
  el.textContent = `${passaUnidades ? un + ' unidades · ' : 'Município inteiro · '}cerca de ${Math.max(1, Math.round(min))} min (estimativa)`;
  lerHistorico().then(h => { const u = h[0]; if (u && u.concluidoEm && u.iniciadoEm) el.textContent += ` · última coleta: ${Math.max(1, Math.round((Date.parse(u.concluidoEm) - Date.parse(u.iniciadoEm)) / 60000))} min`; });
}
// Quadro "o que vai acontecer", logo acima do botão Iniciar coleta.
function resumirColeta(un, passaUnidades) {
  const el = $('resumoColeta'); if (!el) return;
  const marcados = EXTRACAO.ITENS.filter(i => $(i.id) && $(i.id).checked && !$(i.id).disabled);
  if (!marcados.length) { el.textContent = ''; return; }
  const porFin = f => marcados.filter(i => i.finalidade === f).length;
  const unicas = marcados.filter(i => i.escopo === 'municipio').length, porUn = marcados.filter(i => i.escopo !== 'municipio').length;
  const comp = $('competencia').value ? $('competencia').value.split('-').reverse().join('/') : 'competência não escolhida';
  const partes = Object.entries(EXTRACAO.FINALIDADES).map(([f, n]) => porFin(f) ? `${n}: ${porFin(f)}` : '').filter(Boolean).join(' · ');
  const linhas = [`Competência ${comp} · ${passaUnidades ? un + ' unidades' : 'município inteiro'}`, partes,
    `${unicas} ${unicas === 1 ? 'consulta única' : 'consultas únicas'} do município · ${porUn} ${porUn === 1 ? 'item' : 'itens'} com passada por unidade`,
    ...(() => { // a C1 precisa dos dois itens: atendimentos (numerador) e escuta inicial (parte do denominador)
      const at = $('optMunicipal').checked || $('optAbsenteismo').checked, esc = $('optEscuta').checked;
      return ($('optMunicipal').checked && !esc) || (esc && !at) ? ['A C1 só é calculada com "C1 · Atendimentos" e "Escuta inicial na C1" marcados juntos.'] : [];
    })(),
    'Só totais: nenhum nome de paciente, CPF ou prontuário é guardado ou enviado.' + (marcados.some(i => ['optFilas', 'optComposicao', 'optFilasHora', 'optProducao'].includes(i.id)) ? ' Composição, filas e produção levam nome e cargo de profissionais.' : '')];
  el.replaceChildren(...linhas.map(t => { const d = document.createElement('div'); d.textContent = t; return d; }));
  chrome.storage.local.get(['painelUrl', 'painelChave']).then(({ painelUrl, painelChave }) => {
    const d = document.createElement('div'); d.textContent = painelUrl && painelChave ? 'Será enviado ao Painel APS ao terminar.' : 'Sem chave de coleta: o resultado fica só neste computador.'; el.append(d);
  });
}
const id_b4_ou_emulti = () => $('optB4').checked && $('optEmulti').checked;
function aoMudarSelecao() { atualizarGrupos(); estimar(); const sel = {}; ITENS().forEach(i => { sel[i.id] = i.checked; }); chrome.storage.local.set({ selecao: sel }); }
// Selo de modo e custo + ícone ⓘ em cada item, a partir de shared/extracao.js (o mesmo texto da página "Como coletamos" do Painel).
function decorarItens() {
  const ESC = { municipio: 'município', unidade: 'por unidade', ambos: 'município + unidade' };
  for (const it of EXTRACAO.ITENS) {
    const cb = $(it.id); if (!cb) continue;
    const rot = cb.closest('label'), t = TEMPO[it.id] || [0, 0];
    const custo = t[1] > 0 && !t[0] ? `~${String(t[1]).replace('.', ',')} min por unidade` : t[0] && !t[1] ? `~${String(t[0]).replace('.', ',')} min` : t[0] ? `~${String(t[0]).replace('.', ',')} min + ${String(t[1]).replace('.', ',')} por unidade` : '';
    const modo = document.createElement('span'); modo.className = 'modo ' + it.escopo; modo.textContent = ESC[it.escopo] + (custo ? ' · ' + custo : '');
    const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'info'; btn.textContent = 'ⓘ'; btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-label', 'Como é coletado: ' + it.nome);
    const txt = document.createElement('div'); txt.className = 'infotxt'; txt.hidden = true;
    const linha = (r, v) => { const p = document.createElement('p'); const b = document.createElement('b'); b.textContent = r + ': '; p.append(b, v); txt.append(p); };
    linha('Fonte', it.fonte); linha('Como', it.como); linha('Vai ao Painel', it.sai); linha('Dados pessoais', it.pessoal);
    btn.onclick = e => { e.preventDefault(); e.stopPropagation(); txt.hidden = !txt.hidden; btn.setAttribute('aria-expanded', String(!txt.hidden)); };
    rot.append(' ', modo, ' ', btn);
    (rot.closest('.sub') || rot).after(txt);
  }
}

async function iniciarSelecao() {
  decorarItens();
  const { selecao } = await chrome.storage.local.get('selecao');
  if (selecao) ITENS().forEach(i => { if (i.id in selecao) i.checked = selecao[i.id]; });
  document.querySelectorAll('#secColeta .grupo').forEach(g => {
    const corpo = g.querySelector('.corpo'), exp = g.querySelector('.exp');
    exp.onclick = () => { corpo.hidden = !corpo.hidden; exp.setAttribute('aria-expanded', String(!corpo.hidden)); exp.textContent = corpo.hidden ? '▾' : '▴'; };
    g.querySelector('.gcb').onchange = e => { g.querySelectorAll('.corpo input[type=checkbox]').forEach(i => { i.checked = e.target.checked; }); aoMudarSelecao(); };
    corpo.addEventListener('change', aoMudarSelecao);
  });
  // A C1 precisa dos atendimentos (numerador) e da escuta inicial (parte do denominador): marcar um marca o outro.
  const ligar = (a, b) => $(a).addEventListener('change', () => { if ($(b).checked !== $(a).checked) { $(b).checked = $(a).checked; aoMudarSelecao(); } });
  ligar('optMunicipal', 'optEscuta'); ligar('optEscuta', 'optMunicipal');
  $('btnMes').onclick = coletaDoMes;
  $('btnCompleta').onclick = () => marcar(true);
  $('limparTudo').onclick = () => marcar(false);
  $('btnMunicipio').onclick = () => { marcar(false); $('optMunicipal').checked = true; $('optAbsenteismo').checked = true; aoMudarSelecao(); };
  $('btnRecolher').onclick = () => { const abrir = [...document.querySelectorAll('.grupo .corpo')].some(c => c.hidden); document.querySelectorAll('.grupo .exp').forEach(b => { if ((b.getAttribute('aria-expanded') === 'true') !== abrir) b.click(); }); };
  $('listaUnidades').addEventListener('change', estimar); $('competencia').addEventListener('change', estimar);
  atualizarGrupos(); estimar();
}

// Deixa marcadas só as unidades que falharam (e os itens por unidade) para repetir a coleta apenas nelas.
// Ao terminar, devolve as unidades e os itens que estavam marcados antes (a seleção reduzida não fica guardada).
async function refazerFalhas() {
  const falhas = new Set((estado.unidadesErro || []).map(u => UTIL.normalizar(u)));
  const itensAntes = ITENS().map(i => [i, i.checked]);
  const unidadesAntes = [...document.querySelectorAll('[data-unidade]')].map(c => [c, c.checked]);
  const devolver = () => {
    itensAntes.forEach(([i, v]) => { i.checked = v; }); unidadesAntes.forEach(([c, v]) => { c.checked = v; });
    $('qtdUnidades').textContent = unidadesSelecionadas().length; aoMudarSelecao();
  };
  document.querySelectorAll('[data-unidade]').forEach(c => { c.checked = falhas.has(UTIL.normalizar(CONFIG.unidadesAPS[+c.dataset.unidade])); });
  // Os atendimentos ficam marcados (consulta única e rápida): sem eles, a C1 das unidades refeitas não sai.
  ['optAbsenteismo', 'optColetivas', 'optEmulti', 'optB4', 'optProducao'].forEach(id => { if ($(id)) $(id).checked = false; });
  $('detUnidades').open = true; $('qtdUnidades').textContent = unidadesSelecionadas().length;
  aoMudarSelecao();
  if (!falhas.size) { devolver(); log('Não há unidades com falha para refazer.', 'erro'); return; }
  // O botão já inicia a recoleta (antes só marcava as unidades e esperava um segundo clique em "Iniciar coleta").
  const sel = document.querySelector('input[name="substituir"][value="selecionados"]'); if (sel) sel.checked = true;
  log(`Refazendo só as ${falhas.size} unidades que falharam…`);
  $('btnRefazer').hidden = true;
  try { await coletar(); } finally { devolver(); }
}

// Barra de andamento: cada etapa (consulta municipal, unidade, envio) conta um passo.
const prog = { feito: 0, total: 0, ini: 0 };
function progIniciar(total) {
  Object.assign(prog, { feito: 0, total, ini: Date.now() });
  $('progresso').hidden = false; $('estadoUnidades').innerHTML = ''; $('btnRefazer').hidden = true;
  progAtualizar('Preparando…');
}
function progAtualizar(texto) {
  const pct = prog.total ? Math.round(100 * prog.feito / prog.total) : 0;
  $('barra').value = pct;
  let resto = '';
  if (prog.feito > 0 && prog.feito < prog.total) { const m = Math.max(1, Math.round((Date.now() - prog.ini) / prog.feito * (prog.total - prog.feito) / 60000)); resto = ` · faltam cerca de ${m} min`; }
  $('andamento').textContent = `${pct}% · etapa ${Math.min(prog.feito + 1, prog.total)} de ${prog.total}${resto} — ${texto}`;
}
function progPasso(texto) { prog.feito++; progAtualizar(texto); }
function chipUnidade(unidade, estado) {
  let c = [...$('estadoUnidades').children].find(x => x.dataset.u === unidade);
  if (!c) { c = document.createElement('span'); c.dataset.u = unidade; $('estadoUnidades').appendChild(c); }
  c.className = estado; c.textContent = ({ agora: '⏳ ', ok: '✓ ', aviso: '⚠ ', erro: '✗ ' }[estado] || '') + unidade.replace(/^(ESF|Psf|Usf|UBS|Posto de Saude)\s+/i, '');
  c.title = unidade;
}

// ---------------------------------------------------------------- comunicação com a aba do PEC
async function acharAbaPEC() {
  const abas = await chrome.tabs.query({ url: CONFIG.host + '/*' });
  if (!abas.length) return null;
  return abas.find(a => a.active) || abas[0];
}

function enviarUmaVez(tabId, msg) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, msg, resp => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (resp && resp.erro) return reject(new Error(resp.erro));
      resolve(resp);
    });
  });
}

// A página do PEC recarrega ao trocar de acesso ou abrir relatórios; nesse instante o canal com a extensão cai.
// Nesses casos espera a página voltar (reabrindo o início do PEC se preciso) e tenta de novo, uma vez.
const ERRO_CANAL = /Receiving end does not exist|Could not establish connection|message channel closed|No tab with id/i;
async function enviar(tabId, msg) {
  try { return await enviarUmaVez(tabId, msg); }
  catch (e) {
    if (!ERRO_CANAL.test(e.message) || msg.acao === 'ping') throw e;
    if (!(await abaExiste(tabId))) throw new Error('A aba do PEC foi fechada.'); // não adianta esperar
    try { await aguardarPronto(tabId, 25000); }
    catch (_) { await voltarAoInicio(tabId); }
    return enviarUmaVez(tabId, msg);
  }
}

async function abaExiste(tabId) {
  if (!chrome.tabs.get) return true;
  try { await chrome.tabs.get(tabId); return true; } catch (_) { return false; }
}

// Leva a aba de volta à página inicial do PEC (onde a extensão sempre está ativa) e espera ela ficar pronta.
async function voltarAoInicio(tabId) {
  await chrome.tabs.update(tabId, { url: CONFIG.host + '/' });
  await aguardarPronto(tabId, 90000);
}

async function aguardarPronto(tabId, limiteMs = 90000, caminho) {
  const ini = Date.now();
  await UTIL.dormir(2500);
  while (Date.now() - ini < limiteMs) {
    try {
      const r = await enviar(tabId, { acao: 'ping' });
      if (r && r.pronto && (!caminho || (r.caminho || '').startsWith(caminho))) return r;
    } catch (_) { /* página recarregando */ }
    await UTIL.dormir(1500);
  }
  throw new Error('A página do PEC não respondeu a tempo.');
}

// Modo de duas abas: abre uma segunda aba do PEC ao lado da principal, à frente (aba escondida fica lenta no Chrome),
// e espera a extensão responder nela.
async function abrirAbaAuxiliar(principal) {
  const t = await chrome.tabs.create({ url: CONFIG.host + '/', active: true, windowId: principal.windowId, index: (principal.index || 0) + 1 });
  await aguardarPronto(t.id, 90000);
  try { await chrome.tabs.sendMessage(t.id, { acao: 'cancelar', valor: false }); } catch (_) { /* recarregando */ }
  return t;
}

async function verificarPEC() {
  const st = $('status');
  st.className = 'status';
  estado.aba = await acharAbaPEC();
  if (!estado.aba) { st.textContent = 'Abra o PEC (esus.cajamar.sp.gov.br) numa aba e faça login.'; st.classList.add('aviso'); return false; }
  try {
    const r = await enviar(estado.aba.id, { acao: 'ping' });
    if (!r.logado) { st.textContent = 'PEC aberto, mas sem login. Faça login e escolha um acesso.'; st.classList.add('aviso'); return false; }
    st.textContent = `Conectado. Acesso atual: ${r.acesso || 'não identificado'}.`;
    st.classList.add('ok');
    return true;
  } catch (e) {
    st.textContent = 'A aba do PEC precisa ser recarregada (F5) para a extensão funcionar nela.';
    st.classList.add('aviso');
    return false;
  }
}

// ---------------------------------------------------------------- uma coleta por vez
// O PEC tem um só acesso ativo por login. Duas coletas ao mesmo tempo (clique duplo, ou o painel aberto em duas janelas)
// trocam a unidade uma da outra e derrubam as consultas ("Acesso não permitido", "Failed to fetch", canal fechado).
// A trava vale para todos os painéis da extensão: fica em chrome.storage.session, com um sinal de vida a cada 20 s.
// Sem sinal há mais de 3 min, o painel dono foi fechado e a trava pode ser tomada.
const TRAVA = { chave: 'coletaEmAndamento', vidaMs: 20000, validadeMs: 180000, id: null, desde: 0, timer: null };
async function pegarTrava() {
  if (TRAVA.id) { log('Já há uma coleta em andamento neste painel. Espere terminar ou clique em Cancelar.', 'erro'); return false; }
  // Reserva já no clique, antes de qualquer espera: um segundo clique cai na linha acima.
  const id = TRAVA.id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  TRAVA.desde = Date.now();
  $('btnColetar').disabled = true; $('btnRetro').disabled = true;
  const recusar = msg => { TRAVA.id = null; $('btnColetar').disabled = false; $('btnRetro').disabled = false; estado.recusa = msg; log(msg, 'erro'); return false; };
  try {
    const { [TRAVA.chave]: t } = await chrome.storage.session.get(TRAVA.chave);
    // Trava recente: só vale se o painel dono ainda estiver aberto (um painel fechado não responde e a trava é tomada na hora).
    if (t && t.id !== id && Date.now() - t.batida < TRAVA.validadeMs && await travaViva(t.id)) {
      const desde = new Date(t.desde).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      return recusar(`Já há uma coleta em andamento em outro painel desta extensão (começou às ${desde}). O PEC só aceita uma unidade por vez: espere terminar ou cancele lá. Se aquele painel foi fechado, a trava se solta sozinha em até 3 minutos.`);
    }
    await chrome.storage.session.set({ [TRAVA.chave]: { id, desde: TRAVA.desde, batida: Date.now() } });
    await UTIL.dormir(150); // dois painéis no mesmo instante: fica quem gravou por último
    const { [TRAVA.chave]: conf } = await chrome.storage.session.get(TRAVA.chave);
    if (!conf || conf.id !== id) return recusar('Outro painel começou uma coleta neste mesmo instante; esta não foi iniciada.');
  } catch (_) { /* sem storage.session: vale ao menos a trava deste painel */ }
  TRAVA.timer = setInterval(() => {
    try { chrome.storage.session.set({ [TRAVA.chave]: { id, desde: TRAVA.desde, batida: Date.now() } }).catch(() => {}); } catch (_) { /* sem storage.session */ }
  }, TRAVA.vidaMs);
  return true;
}
// Pergunta aos outros painéis da extensão se algum segura a trava "id". Sem resposta (painel fechado), a trava está solta.
// Se ninguém responder a tempo (painel ocupado), vale como viva, por segurança.
async function travaViva(id) {
  try {
    const r = await Promise.race([chrome.runtime.sendMessage({ tipo: 'travaViva', id }), new Promise(ok => setTimeout(() => ok({ viva: true, demorou: true }), 3000))]);
    return !!(r && r.viva);
  } catch (_) { return false; } // nenhum painel recebeu: o dono foi fechado
}
function soltarTrava() {
  const id = TRAVA.id; if (!id) return;
  clearInterval(TRAVA.timer); TRAVA.timer = null; TRAVA.id = null;
  $('btnColetar').disabled = false; $('btnRetro').disabled = false;
  try {
    chrome.storage.session.get(TRAVA.chave).then(({ [TRAVA.chave]: t }) => { if (t && t.id === id) return chrome.storage.session.remove(TRAVA.chave); }).catch(() => {});
  } catch (_) { /* sem storage.session */ }
}
window.addEventListener('pagehide', soltarTrava); // painel fechado no meio: solta a trava na hora

// ---------------------------------------------------------------- nova tentativa
// Repete uma etapa uma vez, depois de uma pausa, quando ela falha por motivo passageiro (rede, página do PEC recarregando,
// relatório que não abriu). "falha" diz se um resultado que voltou sem erro ainda assim falhou (ex.: relatório com aviso).
// Não repete cancelamento nem sessão caída: a segunda tentativa falharia igual.
const NAO_REPETIR = /Sessão do PEC|Coleta cancelada|Você não tem acesso|aba do PEC foi fechada/i;
async function comNovaTentativa(nome, fn, { falha = () => null, esperaMs = 5000 } = {}) {
  let erro;
  try {
    const r = await fn();
    const f = falha(r);
    if (!f) return r;
    erro = Object.assign(new Error(f), { resultado: r });
  } catch (e) {
    if (estado.cancelar || NAO_REPETIR.test(e.message || '')) throw e;
    erro = e;
  }
  log(`${nome}: ${erro.message} Tentando de novo em ${Math.round(esperaMs / 1000)} s…`, 'aviso');
  await UTIL.dormir(esperaMs);
  if (estado.cancelar) { if (erro.resultado) return erro.resultado; throw erro; }
  const r = await fn();
  if (!falha(r)) log(`${nome}: certo na segunda tentativa.`, 'ok');
  return r;
}

// ---------------------------------------------------------------- coleta retroativa
// Meses de "de" a "ate" (AAAA-MM), inclusive.
function mesesEntre(de, ate) {
  const out = []; let [a, m] = de.split('-').map(Number); const [fa, fm] = ate.split('-').map(Number);
  while ((a < fa || (a === fa && m <= fm)) && out.length < 36) { out.push(a + '-' + String(m).padStart(2, '0')); if (++m > 12) { m = 1; a++; } }
  return out;
}
// Coleta um mês por vez: só os itens com data no atendimento (ITENS_COM_DATA) ou tudo o que estiver marcado.
// A trava fica com a retroativa do primeiro ao último mês.
async function coletarRetroativo(op) {
  if (!(await pegarTrava())) return;
  try { await coletarRetroativoComTrava((op && op.retomar) || null); } finally { soltarTrava(); estado.retroCtx = null; }
}
async function coletarRetroativoComTrava(retomar) {
  if (retomar) return continuarRetroativo(retomar);
  const de = $('retroDe').value, ate = $('retroAte').value;
  if (!de || !ate || de > ate) { log('Escolha o período retroativo (de ≤ até).', 'erro'); return; }
  if (!(await verificarPEC())) return;
  const meses = mesesEntre(de, ate);
  const modo = (document.querySelector('input[name="retroModo"]:checked') || {}).value || 'producao';
  const subst = (document.querySelector('input[name="substituir"]:checked') || {}).value || 'selecionados';
  if (modo === 'selecao' && !ITENS().some(i => i.checked && !i.disabled)) { log('Marque os itens a coletar (ou escolha "Só dados com data no atendimento").', 'erro'); return; }
  const un = unidadesSelecionadas().length;
  if (modo === 'producao' && !un) { log('Marque ao menos uma unidade: a C1 (escuta inicial), a saúde bucal e as pessoas atendidas pela eMulti são lidas unidade por unidade.', 'erro'); return; }
  const porMes = modo === 'selecao' ? (/cerca de (\d+) min/.exec($('estimativa').textContent) || [])[1]
    : Math.max(1, Math.round(minutosEstimados(id => ITENS_COM_DATA.includes(id), un).min));
  const tempo = porMes ? `\n\nTempo estimado: cerca de ${String(Math.round(porMes * meses.length / 6) / 10).replace('.', ',')} h (${porMes} min por mês, ${un} unidades).` : '';
  const oQue = modo === 'selecao' ? 'todos os itens e unidades marcados'
    : `só os itens com data no atendimento (C1, B1 a B6, M1 e M2, vacinas, produção por profissional, atendimentos, absenteísmo e faltas por horário) em ${un} unidades`;
  const aviso = modo === 'selecao'
    ? '\n\nOs indicadores de situação (C2 a C7, CR, território e CVAT, composição e filas) mostrarão o cadastro do PEC de hoje, não o do mês, e passam por cima do que foi coletado na época.'
    : '\n\nAs pessoas vinculadas (divisor de B1 e B4) vêm do cadastro de hoje: entram só na conta e não trocam o número do mês no Painel.';
  const sub = subst !== 'todos' ? '' : '\n\nModo "substituir todos": em cada mês, só vale o que esta coleta trouxer.'
    + (modo === 'selecao' ? '' : ' Como este modo não traz C2 a C7, CR, território, CVAT, composição e filas, esses itens desses meses saem do Painel. Para mantê-los, cancele e escolha "Atualizar só os itens e unidades marcados".');
  if (!confirm(`Coletar ${meses.length} mês(es), de ${de} a ${ate}, com ${oQue}?${aviso}${sub}${tempo}\n\nCada mês é enviado ao Painel separado. Não feche esta janela nem use a aba do PEC até o fim.`)) return;
  // Guarda a seleção e a competência atuais para devolver depois.
  const guardado = ITENS().filter(i => i.checked).map(i => i.id);
  await lacoRetroativo({ meses, modo, guardado, competenciaAntes: $('competencia').value, inicio: 0 }, null);
}
// Continua uma retroativa interrompida: termina o mês em que parou (mesma coleta no Painel) e segue para os seguintes.
async function continuarRetroativo(r) {
  if (!(await verificarPEC())) return;
  log('Continuando a coleta retroativa de onde parou.');
  await lacoRetroativo(Object.assign({}, r.retro, { inicio: r.retro.idx }), r.coleta ? r : null);
}
async function lacoRetroativo(ctx, retomar) {
  const { meses, modo, guardado, competenciaAntes } = ctx;
  const resultado = [];
  try {
    for (let k = ctx.inicio; k < meses.length; k++) {
      const comp = meses[k];
      if (estado.cancelar && resultado.length) break;
      if (modo === 'producao') {
        ITENS().forEach(i => { i.checked = false; });
        ITENS_COM_DATA.forEach(id => { $(id).checked = true; });
        aoMudarSelecao();
      }
      $('competencia').value = comp;
      estado.coletaAtual = null; estado.retro = true; estado.retroModo = modo;
      estado.retroCtx = { meses, modo, guardado, competenciaAntes, idx: k };
      log(`Retroativo: ${comp} (${k + 1} de ${meses.length}).`);
      const primeiro = retomar && k === ctx.inicio ? retomar : null;
      await coletar({ semTrava: true, retomar: primeiro });
      const ok = !!(estado.coletaAtual && estado.coletaAtual.competencia === comp && estado.coletaAtual.concluidoEm) && !(estado.unidadesErro || []).length;
      resultado.push([comp, ok]);
      if (estado.cancelar) break;
      // Mês fechado: se o painel cair antes do próximo mês guardar o seu andamento, a retomada começa no mês seguinte.
      if (estado.coletaAtual && estado.coletaAtual.concluidoEm && k + 1 < meses.length) await salvarEntreMeses({ meses, modo, guardado, competenciaAntes, idx: k + 1 });
    }
  } finally {
    estado.retro = false; estado.retroCtx = null;
    $('competencia').value = competenciaAntes;
    ITENS().forEach(i => { i.checked = (guardado || []).includes(i.id); }); aoMudarSelecao();
  }
  // Retroativa terminada (ou cancelada por quem coleta): não há o que retomar.
  await limparRetomada();
  const falhas = resultado.filter(r => !r[1]).map(r => r[0]);
  const total = meses.length - ctx.inicio;
  const resumo = `Retroativo: ${resultado.length - falhas.length} de ${total} mês(es) concluído(s).` + (falhas.length ? ` Refazer: ${falhas.join(', ')}.` : '') + (resultado.length < total ? ' Interrompido antes do fim.' : '');
  $('retroInfo').textContent = resumo;
  log(resumo, falhas.length ? 'erro' : 'ok');
}

// ---------------------------------------------------------------- retomada depois de um acidente
// Durante a coleta, o andamento fica guardado em chrome.storage.session (memória do navegador, não vai para o disco):
// a coleta montada até ali, as unidades já feitas e, na retroativa, os meses que faltam. Se o painel fechar no meio,
// ao abrir de novo aparece "Continuar de onde parou", que segue a MESMA coleta no Painel (o que já foi enviado continua lá).
// Fechar o navegador apaga o andamento; as unidades já enviadas ao Painel continuam valendo.
const RETOMADA = 'retomada';
const paraJson = v => JSON.stringify(v, (k, x) => x instanceof Map ? { __mapa: [...x] } : x instanceof Set ? { __conj: [...x] } : x);
const deJson = t => JSON.parse(t, (k, x) => x && x.__mapa ? new Map(x.__mapa) : x && x.__conj ? new Set(x.__conj) : x);
async function salvarRetomada(ctx) {
  try {
    await chrome.storage.session.set({ [RETOMADA]: paraJson({
      versao: CONFIG.versao, salvoEm: Date.now(), coleta: ctx.coleta, unidades: ctx.unidades, feitas: [...ctx.feitas],
      municipalFeito: !!ctx.municipalFeito, m1: ctx.m1 || null, acessoInicial: ctx.acessoInicial || null,
      itens: ITENS().filter(i => i.checked).map(i => i.id), retro: estado.retroCtx || null, registro: estado.registro || [], registroPendente: estado.registroPendente || [],
      abaAux: estado.abaAux ? estado.abaAux.id : null }) });
  } catch (e) { if (!estado.avisoRetomada) { estado.avisoRetomada = true; log('O andamento não pôde ser guardado para retomar (' + e.message + '); a coleta segue normalmente.', 'aviso'); } }
}
// Entre um mês e outro da retroativa: não há coleta aberta, só os meses que faltam.
async function salvarEntreMeses(retro) {
  try {
    await chrome.storage.session.set({ [RETOMADA]: paraJson({
      versao: CONFIG.versao, salvoEm: Date.now(), coleta: null, unidades: unidadesSelecionadas(), feitas: [],
      substituir: (document.querySelector('input[name="substituir"]:checked') || {}).value || 'selecionados',
      itens: (retro.guardado || []).slice(), retro, registro: [] }) });
  } catch (_) { /* sem storage.session: segue sem retomada */ }
}
async function lerRetomada() {
  try { const { [RETOMADA]: t } = await chrome.storage.session.get(RETOMADA); return t ? deJson(t) : null; } catch (_) { return null; }
}
async function limparRetomada() { try { await chrome.storage.session.remove(RETOMADA); } catch (_) { /* sem storage.session */ } mostrarRetomada(); }
async function mostrarRetomada() {
  const box = $('retomada'); if (!box) return;
  const r = TRAVA.id ? null : await lerRetomada();
  if (!r || !(r.coleta || (r.retro && r.retro.meses))) { box.hidden = true; return; }
  const mmaa = c => c.split('-').reverse().join('/');
  const hora = new Date(r.salvoEm).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  const faltam = (r.unidades || []).filter(u => !(r.feitas || []).includes(u)).length;
  let txt;
  if (!r.coleta) txt = `Coleta retroativa interrompida entre um mês e outro (último registro às ${hora}). Faltam ${r.retro.meses.slice(r.retro.idx).map(mmaa).join(', ')}.`;
  else {
    txt = `Coleta de ${mmaa(r.coleta.competencia)} interrompida (último registro às ${hora}): `
      + (r.municipalFeito ? `${(r.feitas || []).length} de ${(r.unidades || []).length} unidade(s) feitas, já enviadas ao Painel. Faltam ${faltam}.`
        : 'parou nos relatórios do município, que serão lidos de novo; depois seguem as unidades.');
    if (r.retro && r.retro.meses) { const resto = r.retro.meses.slice(r.retro.idx + 1); if (resto.length) txt += ` Coleta retroativa: depois deste mês faltam ${resto.map(mmaa).join(', ')}.`; }
  }
  $('retomadaTexto').textContent = txt;
  box.hidden = false;
}
// A segunda aba de uma coleta interrompida (modo de duas abas) fica aberta. Fecha, se ainda for do PEC
// e houver outra aba do PEC aberta, para a coleta seguir nela.
async function fecharAbaAuxSobrando(r) {
  if (!r || !r.abaAux) return;
  try {
    const pec = await chrome.tabs.query({ url: CONFIG.host + '/*' });
    if (pec.length > 1 && pec.some(t => t.id === r.abaAux)) { await chrome.tabs.remove(r.abaAux); if (estado.aba && estado.aba.id === r.abaAux) estado.aba = null; }
  } catch (_) { /* já fechada */ }
}
async function retomarColeta() {
  const r = await lerRetomada(); if (!r) { mostrarRetomada(); return; }
  await fecharAbaAuxSobrando(r);
  ITENS().forEach(i => { i.checked = (r.itens || []).includes(i.id); });
  document.querySelectorAll('[data-unidade]').forEach(c => { c.checked = (r.unidades || []).includes(CONFIG.unidadesAPS[+c.dataset.unidade]); });
  $('qtdUnidades').textContent = unidadesSelecionadas().length;
  if (r.coleta) $('competencia').value = r.coleta.competencia;
  const sub = document.querySelector(`input[name="substituir"][value="${(r.coleta && r.coleta.substituir) || r.substituir || 'selecionados'}"]`); if (sub) sub.checked = true;
  atualizarGrupos(); estimar();
  $('retomada').hidden = true;
  estado.recusa = null;
  if (r.retro) await coletarRetroativo({ retomar: r }); else await coletar({ retomar: r });
  await mostrarRetomada();
  // Não começou (trava de outro painel, PEC sem login…): o motivo aparece na própria caixa, não só no registro.
  const motivo = estado.recusa || (!$('retomada').hidden && $('status').classList.contains('aviso') ? $('status').textContent : null);
  if (motivo && !$('retomada').hidden) $('retomadaTexto').textContent = 'Não foi possível continuar: ' + motivo;
}
async function descartarRetomada() {
  const r = await lerRetomada();
  await fecharAbaAuxSobrando(r);
  if (r && r.coleta && r.coleta.abertaNoPainel) {
    // Fecha a coleta no Painel como parcial (o que já foi enviado continua valendo).
    try { await painelFetch(`/coletas/${encodeURIComponent(r.coleta.id)}/concluir`, 'POST', { status: 'parcial', concluidoEm: new Date().toISOString(), substituir: 'selecionados' }); } catch (_) { /* sem rede */ }
  }
  await limparRetomada();
  log('Coleta interrompida descartada. O que já tinha sido enviado continua no Painel.');
}

// Equipes de atenção domiciliar (Saúde em Casa, EMAD/EMAP) ficam fora de tudo, logo que os dados chegam do PEC.
const semFora = (lista, campo = 'equipe') => (lista || []).filter(x => !UTIL.equipeFora(x && x[campo]));

// ---------------------------------------------------------------- coleta do mês
// Caminho de rotina: competência do mês anterior, todos os itens, todas as unidades e "atualizar só o que vier".
async function coletaDoMes() {
  if (TRAVA.id) { log('Já há uma coleta em andamento neste painel. Espere terminar ou clique em Cancelar.', 'erro'); return; }
  // A competência é a do campo (que já abre no mês anterior).
  const comp = $('competencia').value || UTIL.competenciaAnterior();
  const un = CONFIG.unidadesAPS.length;
  const min = Math.max(1, Math.round(minutosEstimados(id => !!$(id), un).min));
  const mmaa = comp.split('-').reverse().join('/');
  const antiga = comp < UTIL.competenciaAnterior()
    ? '\n\nAtenção: é um mês anterior ao mês passado. Os indicadores de situação (C2 a C7, CR, território, CVAT, composição e filas) vão mostrar o cadastro de hoje, não o daquele mês. Para meses passados, prefira a coleta retroativa em "Mais opções".' : '';
  if (!confirm(`Coleta do mês ${mmaa}: todos os itens, nas ${un} unidades.\n\nTempo estimado: cerca de ${String(Math.round(min / 6) / 10).replace('.', ',')} h. Cada unidade vai para o Painel assim que termina.${antiga}\n\nNão feche este painel nem use a aba do PEC até o fim.`)) return;
  $('competencia').value = comp;
  ITENS().forEach(i => { i.checked = true; });
  document.querySelectorAll('[data-unidade]').forEach(c => { c.checked = true; });
  $('qtdUnidades').textContent = unidadesSelecionadas().length;
  const sel = document.querySelector('input[name="substituir"][value="selecionados"]'); if (sel) sel.checked = true;
  aoMudarSelecao();
  await coletar();
}

// ---------------------------------------------------------------- coleta
// "Iniciar coleta" e "Refazer falhas" pegam a trava; a retroativa já a segura e chama com { semTrava: true }.
async function coletar(op) {
  const retomar = (op && op.retomar) || null;
  if (op && op.semTrava === true) return coletarCompetencia(retomar);
  if (!(await pegarTrava())) return;
  try { await coletarCompetencia(retomar); } finally { soltarTrava(); mostrarRetomada(); }
}
// retomar: andamento guardado de uma coleta interrompida (ver salvarRetomada); a coleta segue de onde parou.
async function coletarCompetencia(retomar = null) {
  if (!(await verificarPEC())) return;
  if (retomar) $('competencia').value = retomar.coleta.competencia;
  const comp = $('competencia').value;
  if (!comp) { log('Escolha a competência.', 'erro'); return; }
  const tabId = estado.aba.id;
  estado.cancelar = false;
  $('btnColetar').disabled = true; $('btnCancelar').disabled = false;
  $('btnCancelar').textContent = 'Cancelar';
  try { await chrome.tabs.sendMessage(tabId, { acao: 'cancelar', valor: false }); } catch (_) { /* aba ainda carregando */ }
  $('log').innerHTML = '';

  // Substituir todos os dados da competência no Painel: pede confirmação, porque o que esta coleta não trouxer deixa de valer.
  const modoSubst = (document.querySelector('input[name="substituir"]:checked') || {}).value || 'selecionados';
  if (modoSubst === 'todos' && !estado.retro && !retomar && !confirm(`Substituir todos os dados de ${comp} no Painel APS?\n\nSó vai valer o que esta coleta trouxer. Itens e unidades desmarcados deixam de aparecer para esta competência. Se alguma unidade falhar, os dados anteriores são mantidos.`)) {
    $('btnColetar').disabled = !!TRAVA.id; $('btnCancelar').disabled = true; return;
  }
  const coleta = retomar ? retomar.coleta : {
    id: `${comp}-${Date.now()}`, competencia: comp, versao: CONFIG.versao, substituir: modoSubst,
    iniciadoEm: new Date().toISOString(), concluidoEm: null,
    config: { unidadesAPS: CONFIG.unidadesAPS, gruposCBO: CONFIG.gruposCBO, tiposFalta: CONFIG.tiposFalta, substituir: modoSubst },
    cubos: { atendimentos: [], absenteismo: [], escuta: [], coletivas: [], odonto: [], equipes: [] }, linhas: [], avisos: [], observacoes: [],
    escutaUnidades: []
  };
  // Há passagem pelas unidades (troca de acesso) quando algum item "por unidade" está marcado.
  const comUnidades = ITENS_UNIDADE.some(id => $(id).checked);
  const comEscuta = $('optEscuta').checked && comUnidades;
  const comBucal = $('optBucal').checked && comUnidades;
  const comColetivas = $('optB4').checked || $('optEmulti').checked || $('optProducao').checked; // a leitura das atividades serve à B4, à M1/M2 e à produção por profissional
  const temas = { c2: $('optC2').checked, c3: $('optC3').checked, c4: $('optC4').checked, c5: $('optC5').checked, c6: $('optC6').checked, c7: $('optC7').checked, cr: $('optCR').checked };
  // Retroativa só com dados com data: as pessoas vinculadas (cadastro de hoje) servem à conta, mas não vão ao Painel (ver enviarColeta).
  coleta.retroComData = !!(estado.retro && estado.retroModo !== 'selecao');
  if (estado.retro && !retomar) coleta.observacoes.push(estado.retroModo === 'selecao'
    ? 'Coleta retroativa com todos os itens: os indicadores de situação refletem o cadastro do PEC na data da coleta, não o do mês.'
    : 'Coleta retroativa só com dados com data no atendimento (C1, B1 a B6, M1, M2, vacinas, produção, atendimentos, absenteísmo e faltas por horário). Os divisores de B1 e B4 usam as pessoas vinculadas do cadastro de hoje; os indicadores de situação não foram coletados.');
  // Na retomada, o município (atendimentos, atividades coletivas, eMulti…) e as unidades já feitas não são lidos de novo.
  const pular = !!(retomar && retomar.municipalFeito);
  const feitas = new Set(retomar ? retomar.feitas : []);
  const unidadesDaColeta = retomar && retomar.unidades ? retomar.unidades : unidadesSelecionadas();
  estado.registro = retomar && retomar.registro ? retomar.registro.slice() : [];
  // Linhas do registro ainda não enviadas ao Painel (o registro vai em partes, só com as linhas novas).
  estado.registroPendente = retomar ? (retomar.registroPendente || retomar.registro || []).slice() : [];
  log(retomar ? `Continuando a coleta de ${comp}: ${feitas.size} de ${unidadesDaColeta.length} unidade(s) já feitas.` : `Coleta da competência ${comp} iniciada.`);
  await abrirNoPainel(coleta);
  // Andamento guardado desde já: se o painel cair nos relatórios do município, a retomada lê o município de novo, na mesma coleta.
  if (!pular) await salvarRetomada({ coleta, unidades: unidadesDaColeta, feitas, municipalFeito: false });
  estado.unidadesErro = [];
  const passosMun = pular ? 0 : ($('optMunicipal').checked || $('optAbsenteismo').checked ? 1 : 0) + (comColetivas ? 1 : 0) + ($('optEmulti').checked ? 1 : 0);
  progIniciar(passosMun + (comUnidades ? unidadesDaColeta.filter(u => !feitas.has(u)).length : 0) + 1);

  try {
    // Os relatórios do município só respondem com o acesso de uma unidade de APS ativo
    // (com "Secretaria de Saude" o PEC devolve 403). Troca antes e devolve o acesso original ao final.
    let acessoInicial = pular ? retomar.acessoInicial : null;
    if (!pular && ($('optMunicipal').checked || $('optAbsenteismo').checked || comColetivas || $('optEmulti').checked || $('optFilas').checked || $('optVacinas').checked || $('optProducao').checked)) {
      try {
        acessoInicial = await enviar(tabId, { acao: 'ping' });
        const un = unidadesSelecionadas()[0] || CONFIG.unidadesAPS[0];
        const t = await enviar(tabId, { acao: 'trocarAcesso', unidade: un });
        if (t && t.recarregando) await aguardarPronto(tabId);
        log(`Relatórios do município: usando o acesso de ${un}.`);
      } catch (e) { coleta.avisos.push('Não foi possível selecionar um acesso de unidade para os relatórios do município: ' + e.message); }
    }
    // Atendimentos (C1) e absenteísmo (Q14.2.1) saem dos relatórios gerenciais do município.
    // O absenteísmo também lê os atendimentos, que entram no denominador.
    // coleta.lidos diz o que esta coleta leu: o que não foi lido não vira linha (não passa por cima do Painel).
    const partes = { atendimentos: $('optMunicipal').checked, absenteismo: $('optAbsenteismo').checked };
    if (!pular) coleta.lidos = { atendimentos: false, absenteismo: false };
    if (!pular && (partes.atendimentos || partes.absenteismo)) {
      const nome = partes.atendimentos && partes.absenteismo ? 'Atendimentos e absenteísmo' : partes.atendimentos ? 'Atendimentos (C1)' : 'Absenteísmo (Q14.2.1)';
      progAtualizar(nome.toLowerCase() + ' do município');
      const t0 = Date.now();
      try {
        // O relatório volta com aviso (e não com erro) quando uma das partes falha: o aviso também conta como falha.
        const r = await comNovaTentativa(nome, () => enviar(tabId, { acao: 'municipal', comp, partes }),
          { falha: r => (r.avisos || []).length ? r.avisos.join('; ') + '.' : null });
        coleta.cubos.atendimentos = semFora(r.atendimentos);
        coleta.cubos.absenteismo = semFora(r.absenteismo);
        const falhou = p => (r.avisos || []).some(a => a.startsWith(p + ':'));
        coleta.lidos = { atendimentos: !falhou('Atendimentos'), absenteismo: partes.absenteismo && !falhou('Absenteísmo') && !falhou('Atendimentos') };
        (r.avisos || []).forEach(a => coleta.avisos.push(a));
        log(`${nome}: coletado${(r.avisos || []).length ? ' com falha' : ''} em ${duracao(Date.now() - t0)}.`, (r.avisos || []).length ? 'erro' : 'ok');
        await enviarMunicipioAoPainel(coleta);
      } catch (e) { coleta.avisos.push(`${nome} do município: ${e.message}`); log(`${nome} do município: ${e.message}`, 'erro'); }
      progPasso('município concluído');
    }

    // Filas e faltas: faltas e atendimentos por profissional (médicos e enfermeiros), numa chamada para o município.
    const filas = pular && coleta.filas instanceof Map ? coleta.filas : new Map();
    const chaveFila = p => [UTIL.normalizar(p.unidade), UTIL.normalizar(p.nome), UTIL.codigoCBO(p.cbo)].join('|');
    if (!pular && $('optFilas').checked && !estado.cancelar) {
      try {
        const t0 = Date.now();
        const r = await comNovaTentativa('Filas e faltas', () => enviar(tabId, { acao: 'filasMunicipal', comp }));
        semFora(r.profissionais).forEach(p => filas.set(chaveFila(p), p));
        log(`Filas e faltas: ${filas.size} profissionais com produção no mês (${duracao(Date.now() - t0)}).`, 'ok');
      } catch (e) { coleta.avisos.push('Filas e faltas: ' + e.message); log('Filas e faltas: ' + e.message, 'erro'); }
    }
    // Vacinas (estadual): doses aplicadas do município no mês; vão ao Painel APS como estimativa, separada do lançamento oficial.
    if (!pular) coleta.vacinas = [];
    if (!pular && $('optVacinas').checked && !estado.cancelar) {
      try {
        const t0 = Date.now();
        const r = await comNovaTentativa('Vacinas', () => enviar(tabId, { acao: 'vacinas', comp }));
        coleta.vacinas = r.doses || [];
        log(`Vacinas: ${coleta.vacinas.reduce((s, d) => s + d.n, 0)} doses lidas (${duracao(Date.now() - t0)}).`, 'ok');
      } catch (e) { coleta.avisos.push('Vacinas: ' + e.message); log('Vacinas: ' + e.message, 'erro'); }
    }
    coleta.filas = filas;
    const filasHorario = pular && Array.isArray(coleta.filasHorario) ? coleta.filasHorario : [];
    coleta.filasHorario = filasHorario;

    if (!pular && comColetivas && !estado.cancelar) {
      progAtualizar('atividades coletivas');
      const t0 = Date.now();
      try {
        log('Atividades coletivas (B4, M1, M2): lendo as atividades do mês; leva alguns minutos…');
        const r = await comNovaTentativa('Atividades coletivas', () => enviar(tabId, { acao: 'coletivas', comp }));
        coleta.cubos.coletivas = semFora(r.linhas);
        coleta.producaoColetiva = semFora(r.porProfissional);
        (r.avisos || []).forEach(a => coleta.avisos.push(a));
        log(`Atividades coletivas: ${r.lidas || 0} de ${r.total || 0} lidas (${duracao(Date.now() - t0)}).`, 'ok');
      } catch (e) {
        coleta.avisos.push('Atividades coletivas: ' + e.message);
        log('Atividades coletivas: ' + e.message, 'erro');
      }
      progPasso('atividades coletivas concluídas');
    }

    // Produção por profissional (relatório "Produção e notas"): atendimentos individuais do mês, juntados às coletivas.
    if (!pular) coleta.producao = [];
    if (!pular && $('optProducao').checked && !estado.cancelar) {
      try {
        const t0 = Date.now();
        const r = await comNovaTentativa('Produção por profissional', () => enviar(tabId, { acao: 'producaoProfissional', comp }));
        coleta.producao = juntarProducao(semFora(r.profissionais), coleta.producaoColetiva || []);
        log(`Produção por profissional: ${coleta.producao.length} profissionais (${duracao(Date.now() - t0)}).`, 'ok');
      } catch (e) { coleta.avisos.push('Produção por profissional: ' + e.message); log('Produção por profissional: ' + e.message, 'erro'); }
    }
    delete coleta.producaoColetiva;

    // eMulti (M1 do quadrimestre e M2 completa). Os resumos ficam só na memória desta coleta.
    let m1 = pular ? retomar.m1 : null;
    if (!pular && $('optEmulti').checked && !estado.cancelar) {
      progAtualizar('eMulti (M1 e M2)');
      const t0 = Date.now();
      try {
        log('eMulti (M1 e M2): atendimentos compartilhados e atividades coletivas do quadrimestre; alguns minutos…');
        const sal = [...crypto.getRandomValues(new Uint8Array(16))].map(x => x.toString(16)).join('');
        const r = await comNovaTentativa('eMulti (M1 e M2)', () => enviar(tabId, { acao: 'emultiMunicipal', comp, sal }));
        coleta.cubos.compartilhado = r.compartilhado || [];
        coleta.cubos.cuidado = r.cuidado || [];
        if (r.cuidadoErro) coleta.avisos.push('M2: compartilhamento do cuidado não lido (' + r.cuidadoErro + '); a M2 ficou sem esse componente.');
        coleta.cuidadoLido = !r.cuidadoErro;
        const cq = r.coletivasQuad || {};
        if (cq.documentoNaoLido) coleta.avisos.push('M1: o PEC não devolveu CPF/CNS dos participantes; a conferência de documento ficou desligada e o numerador pode estar acima do real.');
        else if (cq.semDocumento) coleta.observacoes.push(`M1: ${cq.semDocumento} participação(ões) em atividades coletivas sem CPF/CNS válido ficaram de fora, como pede a nota.`);
        m1 = { sal, quad: UTIL.quadrimestreAte(comp).quad, periodo: { inicio: UTIL.quadrimestreAte(comp).inicio, fim: UTIL.quadrimestreAte(comp).fim }, equipes: r.equipes || [], atendQuad: r.atendQuad || {}, coletivasQuad: r.coletivasQuad || {}, ind: {} };
        if (r.coletivasQuad && r.coletivasQuad.falhas) coleta.avisos.push(`M1: ${r.coletivasQuad.falhas} atividades coletivas do quadrimestre não puderam ser lidas.`);
        log(`eMulti: ${(r.coletivasQuad && r.coletivasQuad.total) || 0} atividades coletivas no quadrimestre (${duracao(Date.now() - t0)}).`, 'ok');
      } catch (e) {
        coleta.avisos.push('eMulti (M1/M2): ' + e.message);
        log('eMulti (M1/M2): ' + e.message, 'erro');
      }
      progPasso('eMulti concluída');
    }

    // Andamento guardado: daqui em diante, um acidente com o painel não perde o que já foi feito.
    const ctxRet = { coleta, unidades: unidadesDaColeta, feitas, municipalFeito: true, m1, acessoInicial };
    await salvarRetomada(ctxRet);

    if (!comUnidades && acessoInicial && acessoInicial.acessoId) {
      try { await enviar(tabId, { acao: 'restaurarAcesso', acessoId: acessoInicial.acessoId }); } catch (e) {}
    }
    if (comUnidades) {
      const original = acessoInicial || await enviar(tabId, { acao: 'ping' });
      const unidades = unidadesDaColeta.filter(u => !feitas.has(u));
      if ($('optDuasAbas') && $('optDuasAbas').checked && (comEscuta || comBucal || $('optComposicao').checked) && unidades.length) {
        try {
          estado.abaAux = await abrirAbaAuxiliar(estado.aba);
          // Se alguém fechar a segunda aba, a coleta segue com uma aba só (em vez de falhar as unidades seguintes).
          const auxId = estado.abaAux.id;
          estado.aoFecharAux = id => { if (id === auxId && estado.abaAux && estado.abaAux.id === auxId) { estado.abaAux = null; log('Duas abas: a segunda aba foi fechada; a coleta segue com uma aba.', 'aviso'); } };
          if (chrome.tabs.onRemoved) chrome.tabs.onRemoved.addListener(estado.aoFecharAux);
          log('Duas abas: os relatórios clássicos (escuta inicial, saúde bucal, composição) rodam na aba nova, que fica à frente; as listas seguem na aba original. Deixe a aba nova visível.', 'aviso');
        } catch (e) { estado.abaAux = null; log('Duas abas: a segunda aba não abriu (' + e.message + '); a coleta segue com uma aba.', 'aviso'); }
      }
      // Uma unidade inteira. Devolve { falhou, sessao } — "sessao" quando o login do PEC caiu (não adianta seguir).
      // Cada passo depois da leitura principal tem sua própria nova tentativa e só grava o resultado se der certo,
      // então uma unidade com ✗ não deixa dados pela metade e pode ser coletada de novo inteira.
      const avisoDaFalha = {};
      const ROTA_IND = '/relatorios/producao/atendimento-individual', ROTA_ODONTO = '/relatorios/producao/atendimento-odontologico';
      // Relatórios clássicos: abrir a página do relatório faz parte da tentativa (se ela não abrir, abre de novo).
      const classico = (aba, rota, abrir, acao) => async () => {
        await enviar(aba, { acao: abrir });
        await aguardarPronto(aba, 120000, rota);
        return enviar(aba, acao);
      };
      const umaUnidade = async (unidade, rotulo, sairDoRelatorio) => {
        log(`${rotulo} ${unidade}: trocando de acesso…`);
        chipUnidade(unidade, 'agora'); progAtualizar(`${unidade} (${rotulo.replace(/[()]/g, '')})`);
        const avisosAntes = coleta.avisos.length;
        // Tempo de cada parte, para o registro (e para comparar uma aba com duas).
        const tempos = [], inicio = Date.now();
        const medir = async (nome, fn) => { const t = Date.now(); try { return await fn(); } finally { tempos.push([nome, Date.now() - t]); } };
        const abaB = estado.abaAux ? estado.abaAux.id : null; // modo de duas abas: relatórios clássicos na aba auxiliar
        try {
          await medir('troca de acesso', async () => {
            if (sairDoRelatorio) await voltarAoInicio(tabId); // sai do relatório clássico da unidade anterior
            const t = await enviar(tabId, { acao: 'trocarAcesso', unidade });
            if (t && t.recarregando) await aguardarPronto(tabId);
          });

          // Parte 1 (aba principal): listas da unidade, pessoas da eMulti, agendas e faltas por horário.
          const listas = async () => {
            const r = await medir('listas', () => enviar(tabId, { acao: 'unidade', comp, unidade, opcoes: { temas, c7ItemC: $('optC7C').checked && $('optC7').checked, territorio: $('optTerritorio').checked, cvat: $('optCvat').checked } }));
            r.linhas = semFora(r.linhas); r.equipes = semFora(r.equipes, 'nome');
            coleta.linhas.push(...r.linhas);
            coleta.observacoes.push(...semFora(r.observacoes));
            if (m1 && m1.equipes.length) {
              try {
                const p = await medir('pessoas da eMulti', () => comNovaTentativa(`${unidade} · pessoas atendidas pela eMulti`, () => enviar(tabId, { acao: 'emultiUnidade', comp, sal: m1.sal, equipes: m1.equipes })));
                for (const [ine, v] of Object.entries(p)) {
                  const o = m1.ind[ine] = m1.ind[ine] || { atendimentos: 0, resumos: new Set() };
                  o.atendimentos += v.atendimentos; v.resumos.forEach(x => o.resumos.add(x));
                }
              } catch (err) { coleta.avisos.push(`${unidade}: pessoas atendidas pela eMulti não lidas (${err.message}).`); }
            }
            if ($('optFilas').checked && !estado.cancelar) {
              try {
                const ag = await medir('agendas', () => comNovaTentativa(`${unidade} · agendas`, () => enviar(tabId, { acao: 'agendaUnidade', unidade })));
                semFora(ag.agendas).forEach(x => { const k = chaveFila(x); filas.set(k, Object.assign(filas.get(k) || { unidade: x.unidade, equipe: x.equipe, cbo: x.cbo, categoria: x.categoria, nome: x.nome }, { proximaVaga: x.proximaVaga, diasVaga: x.diasVaga, semVaga: x.semVaga, agendaLidaEm: x.agendaLidaEm })); });
              } catch (err) { coleta.avisos.push(`${unidade}: agendas não lidas (${err.message}).`); }
            }
            if ($('optFilasHora').checked && !estado.cancelar) {
              try {
                const fh = await medir('faltas por horário', () => comNovaTentativa(`${unidade} · faltas por horário`, () => enviar(tabId, { acao: 'faltasHorarioUnidade', unidade, comp })));
                semFora(fh.profissionais).forEach(x => filasHorario.push(x));
              } catch (err) { coleta.avisos.push(`${unidade}: faltas por horário não lidas (${err.message}).`); }
            }
            (r.avisos || []).forEach(a => coleta.avisos.push(`${unidade}: ${a}`));
            (r.equipes || []).forEach(e => coleta.cubos.equipes.push(Object.assign({ unidade }, e)));
            return r;
          };

          // Parte 2: relatórios clássicos (composição, escuta inicial, saúde bucal). Precisam só da lista de equipes.
          // feito: partes já lidas nesta unidade (se a segunda aba fechar no meio, a aba principal refaz só o que faltou).
          const feito = new Set();
          const relatorios = async (aba, equipes) => {
            if ($('optComposicao').checked && !estado.cancelar && !feito.has('composição')) {
              try {
                const lt = await medir('composição', () => comNovaTentativa(`${unidade} · composição`, classico(aba, ROTA_IND, 'abrirRelatorioClassico', { acao: 'lotacoes' })));
                (coleta.cubos.lotacoes = coleta.cubos.lotacoes || []).push(...semFora(lt.lotacoes).map(l => Object.assign({ unidade }, l)));
                feito.add('composição');
                log(`${unidade}: ${(lt.lotacoes || []).length} lotações lidas.`);
              } catch (err) { coleta.avisos.push(`${unidade}: composição não lida (${err.message}).`); }
            }
            // Escuta inicial (C1): relatório de atendimento individual por equipe eSF/eAP e categoria.
            const eqEscuta = equipes.filter(e => CONFIG.c1.tiposEquipe.includes(String(e.tipo).toUpperCase()) && e.ine).map(e => ({ ine: e.ine, nome: e.nome }));
            if (comEscuta && eqEscuta.length && !estado.cancelar && !feito.has('escuta inicial')) {
              try {
                const e = await medir('escuta inicial', () => comNovaTentativa(`${unidade} · escuta inicial`, classico(aba, ROTA_IND, 'abrirRelatorioClassico', { acao: 'escutaInicial', comp, unidade, equipes: eqEscuta })));
                coleta.cubos.escuta.push(...(e.linhas || []));
                feito.add('escuta inicial');
                (coleta.escutaUnidades = coleta.escutaUnidades || []).push(unidade);
                (e.avisos || []).forEach(a => coleta.avisos.push(`${unidade}: ${a}`));
              } catch (err) {
                coleta.avisos.push(`${unidade}: escuta inicial não coletada (${err.message}).`);
                log(`${unidade}: escuta inicial não coletada (${err.message}).`, 'erro');
              }
            }
            // Saúde bucal (B1, B2, B3, B5, B6): relatório de atendimento odontológico por equipe eSB.
            const esb = equipes.filter(e => String(e.tipo).toUpperCase() === 'ESB' && e.ine).map(e => ({ nome: e.nome, ine: e.ine, tipo: e.tipo }));
            if (comBucal && esb.length && !estado.cancelar && !feito.has('saúde bucal')) {
              try {
                const o = await medir('saúde bucal', () => comNovaTentativa(`${unidade} · saúde bucal`, classico(aba, ROTA_ODONTO, 'abrirRelatorioOdonto', { acao: 'odontologico', comp, unidade, equipes: esb })));
                coleta.cubos.odonto.push(...(o.linhas || []));
                feito.add('saúde bucal');
                (o.avisos || []).forEach(a => coleta.avisos.push(`${unidade}: ${a}`));
              } catch (err) {
                coleta.avisos.push(`${unidade}: saúde bucal não coletada (${err.message}).`);
                log(`${unidade}: saúde bucal não coletada (${err.message}).`, 'erro');
              }
            }
          };

          let r;
          if (abaB) {
            // Duas abas: as listas na principal e os relatórios clássicos na auxiliar, ao mesmo tempo, na MESMA unidade.
            // As duas terminam antes de trocar de unidade (o acesso ao PEC é um só para as duas).
            let eqs = null;
            try { eqs = semFora((await enviar(abaB, { acao: 'equipesUnidade', unidade })).equipes, 'nome'); } catch (_) { /* segunda aba fechada ou recarregando */ }
            if (!eqs || !estado.abaAux) {
              // A segunda aba sumiu: esta unidade (e as seguintes) vão com uma aba só.
              r = await listas();
              await relatorios(tabId, r.equipes || []);
            } else {
              const avisosAntesRel = coleta.avisos.length;
              const [a1, a2] = await Promise.allSettled([listas(), relatorios(abaB, eqs)]);
              if (a1.status === 'rejected') throw a1.reason;
              r = a1.value;
              if (!estado.abaAux) {
                // Fechada no meio da unidade: os relatórios clássicos são refeitos na aba principal (sem os avisos da tentativa perdida).
                log(`${unidade}: a segunda aba foi fechada no meio; ${[$('optComposicao').checked && 'composição', comEscuta && 'escuta inicial', comBucal && 'saúde bucal'].filter(x => x && !feito.has(x)).join(', ') || 'nada'} segue na aba principal.`, 'aviso');
                coleta.avisos.splice(avisosAntesRel).filter(a => !/: (composição não lida|escuta inicial não coletada|saúde bucal não coletada) \(/.test(a)).forEach(a => coleta.avisos.push(a));
                await relatorios(tabId, r.equipes || []);
              } else if (a2.status === 'rejected') coleta.avisos.push(`${unidade}: relatórios clássicos na segunda aba falharam (${a2.reason && a2.reason.message}).`);
            }
          } else {
            r = await listas();
            await relatorios(tabId, r.equipes || []);
          }
          // Parte 3: CR4 (eCR) — itens A, B e C pelo relatório de atendimento individual filtrado por tuberculose; precisa da lista da eCR.
          const ecr = (r.equipes || []).find(e => String(e.tipo).toUpperCase() === 'ECR' && e.ine);
          const lcr4 = ecr && coleta.linhas.find(l => l.codigo === 'CR4' && l.ine === ecr.ine);
          if (lcr4 && lcr4.denominador > 0 && !estado.cancelar) {
            try {
              const tb = await medir('CR4', () => comNovaTentativa(`${unidade} · CR4`, classico(abaB || tabId, ROTA_IND, 'abrirRelatorioClassico', { acao: 'tuberculose', comp, unidade, equipe: { ine: ecr.ine, nome: ecr.nome } })));
              Object.assign(lcr4, CALCULO.cr4(lcr4, tb));
            } catch (err) { coleta.avisos.push(`${unidade}: CR4, itens A a C não lidos (${err.message}).`); }
          }
          // Coletada na segunda passada: o aviso da primeira falha passa a dizer isso.
          if (unidade in avisoDaFalha) { coleta.avisos[avisoDaFalha[unidade].i] = `${unidade}: falhou na primeira tentativa (${avisoDaFalha[unidade].msg}) e foi coletada na nova tentativa automática.`; delete avisoDaFalha[unidade]; }
          chipUnidade(unidade, coleta.avisos.length > avisosAntes ? 'aviso' : 'ok');
          log(`${unidade}: concluída em ${duracao(Date.now() - inicio)}${abaB ? ' (duas abas)' : ''} — ${tempos.map(([n, ms]) => `${n} ${duracao(ms)}`).join(' · ')}.`, 'ok');
          await enviarUnidadeAoPainel(coleta, unidade);
          return { falhou: false, sessao: false };
        } catch (e) {
          estado.unidadesErro.push(unidade);
          coleta.avisos.push(`${unidade}: ${e.message}`);
          if (!(unidade in avisoDaFalha)) avisoDaFalha[unidade] = { i: coleta.avisos.length - 1, msg: e.message };
          log(`${unidade}: ${e.message} (depois de ${duracao(Date.now() - inicio)})`, 'erro');
          chipUnidade(unidade, 'erro');
          return { falhou: true, sessao: /Sessão do PEC/.test(e.message) };
        }
      };
      const sessaoCaiu = (desde, lista) => {
        const resto = lista.slice(desde);
        resto.forEach(u => { estado.unidadesErro.push(u); chipUnidade(u, 'erro'); });
        if (resto.length) coleta.avisos.push(`Coleta interrompida: sessão do PEC encerrada. Ficaram sem coletar: ${resto.join(', ')}.`);
        log('A sessão do PEC caiu. Entre de novo no PEC e clique em "Refazer falhas" para coletar só o que faltou.', 'erro');
      };
      let caiu = false;
      for (const [i, unidade] of unidades.entries()) {
        if (estado.cancelar) { log('Coleta cancelada.', 'erro'); break; }
        const r = await umaUnidade(unidade, `(${i + 1}/${unidades.length})`, i > 0 || !!retomar);
        if (!r.falhou) feitas.add(unidade);
        ctxRet.m1 = m1; await salvarRetomada(ctxRet);
        progPasso(`${unidade} ${r.falhou ? 'com erro' : 'concluída'}`);
        // Sessão caída: as próximas unidades falhariam igual. Para aqui e deixa todas marcadas para refazer.
        if (r.sessao) { sessaoCaiu(i + 1, unidades); caiu = true; break; }
      }
      // Nova tentativa automática: as unidades com ✗ são coletadas de novo, uma vez, antes do envio ao Painel.
      if (!estado.cancelar && !caiu && estado.unidadesErro.length) {
        const refazer = estado.unidadesErro.splice(0);
        prog.total += refazer.length;
        log(`Nova tentativa automática para ${refazer.length} unidade(s) com falha: ${refazer.join(', ')}.`, 'aviso');
        await UTIL.dormir(5000);
        for (const [k, unidade] of refazer.entries()) {
          if (estado.cancelar) { estado.unidadesErro.push(...refazer.slice(k)); log('Coleta cancelada.', 'erro'); break; }
          const r = await umaUnidade(unidade, `(nova tentativa ${k + 1}/${refazer.length})`, true);
          if (!r.falhou) feitas.add(unidade);
          await salvarRetomada(ctxRet);
          progPasso(`${unidade} ${r.falhou ? 'com erro' : 'concluída'} na nova tentativa`);
          if (r.sessao) { sessaoCaiu(k + 1, refazer); break; }
        }
      }
      if (original && original.acessoId) {
        try {
          await enviar(tabId, { acao: 'restaurarAcesso', acessoId: original.acessoId });
          log(`Acesso original restaurado (${original.acesso || original.acessoId}). Recarregue a página do PEC para o cabeçalho refletir isso.`);
        } catch (e) { log('Não foi possível restaurar o acesso original: ' + e.message, 'erro'); }
      }
    }

    if (m1) {
      try { coleta.linhas.push(...CALCULO.m1(m1, coleta)); } catch (e) { coleta.avisos.push('M1: ' + e.message); }
      m1 = null; // descarta os resumos
    }
    try { coleta.observacoes.push(...CALCULO.observacoesBucal(coleta)); } catch (_) { /* sem atividades */ }
    if ((coleta.cubos.lotacoes || []).length) {
      try {
        coleta.composicao = CALCULO.composicao(coleta);
        coleta.composicao.alertas.forEach(a => coleta.avisos.push('Composição: ' + a));
        for (const u of coleta.composicao.unidades) {
          u.alertas.forEach(a => coleta.avisos.push(`Composição · ${u.nome}: ${a}`));
          u.equipes.forEach(e => e.alertas.forEach(a => coleta.avisos.push(`Composição · ${u.nome} · ${e.nome}: ${a}`)));
        }
        delete coleta.cubos.lotacoes; // a árvore já tem tudo
        await enviarComposicao(coleta);
      } catch (e) { coleta.avisos.push('Composição: ' + e.message); }
    }
    // Conferência dos vínculos eSB → eSF (regra de 40 h de eSB por eSF).
    try { CALCULO.conferirSaudeBucal(coleta).forEach(a => coleta.avisos.push('Saúde bucal: ' + a)); } catch (_) { /* sem dados de equipes */ }
    try { conferirC1(coleta).forEach(a => coleta.avisos.push(a)); } catch (_) { /* sem atendimentos ou escuta */ }
    coleta.concluidoEm = new Date().toISOString();
    registrarCobertura(coleta);
    progAtualizar('enviando ao Painel APS');
    await enviarFilas(coleta);
    await enviarFilasHorario(coleta);
    await enviarVacinas(coleta);
    await enviarProducao(coleta);
    delete coleta.producao; // os nomes dos profissionais não ficam no histórico da extensão
    delete coleta.vacinas;
    delete coleta.filas; // os nomes dos profissionais não ficam no histórico da extensão
    delete coleta.filasHorario;
    await enviarColeta(coleta);
    progPasso('coleta enviada');
    // Não chegou ao Painel: guarda o registro e se ficou incompleta, para o botão "Enviar ao Painel" do histórico.
    if (!coleta.enviadoEm) { coleta.registroGuardado = (estado.registroPendente || []).slice(-2000); coleta.incompleta = !!(estado.cancelar || estado.unidadesErro.length); }
    await salvarColeta(coleta);
    if (estado.unidadesErro.length) $('btnRefazer').hidden = false;
    estado.coletaAtual = coleta;
    if (!estado.retro) await limparRetomada();
    log('Coleta salva no histórico.', 'ok');
    renderizar();
    await renderizarHistorico();
  } catch (e) {
    log('Erro: ' + e.message, 'erro');
  } finally {
    if (estado.aoFecharAux && chrome.tabs.onRemoved) { chrome.tabs.onRemoved.removeListener(estado.aoFecharAux); estado.aoFecharAux = null; }
    if (estado.abaAux) {
      const aux = estado.abaAux; estado.abaAux = null;
      chrome.tabs.remove(aux.id).catch(() => {});
      chrome.tabs.update(tabId, { active: true }).catch(() => {});
    }
    $('btnColetar').disabled = !!TRAVA.id; $('btnCancelar').disabled = true; $('btnCancelar').textContent = 'Cancelar';
    if (estado.cancelar) chrome.tabs.sendMessage(tabId, { acao: 'cancelar', valor: false }).catch(() => {});
  }
}

// ---------------------------------------------------------------- cálculo
// Gera linhas no nível equipe para todos os indicadores; o nível escolhido é obtido por agregação.
// Conferência das duas fontes da C1: para cada equipe e categoria (médico, enfermeiro), os atendimentos que não são escuta
// inicial têm de bater entre o relatório de atendimento individual (de onde vem a escuta) e o relatório gerencial de atendimentos.
// Se batem, a escuta é o único acréscimo e nada é contado duas vezes. Devolve avisos; só totais.
function conferirC1(coleta) {
  const N = UTIL.normalizar, out = [];
  const categoria = cbo => String(cbo || '').startsWith('2235') ? 'enfermeiro' : String(cbo || '').startsWith('225') ? 'medico' : null;
  const ger = new Map();
  for (const a of (coleta.cubos && coleta.cubos.atendimentos) || []) {
    const c = categoria(a.cboCodigo); if (!c) continue;
    const k = N(`${a.unidade}|${a.equipe}`) + '|' + c; ger.set(k, (ger.get(k) || 0) + (a.n || 0));
  }
  if (!ger.size) return out;
  for (const e of (coleta.cubos && coleta.cubos.escuta) || []) {
    if (e.periodoOk === false || !e.tipos) continue;
    const fora = Object.entries(e.tipos).filter(([t]) => !N(t).startsWith('escuta inicial') && !/^total/.test(N(t))).reduce((s, [, n]) => s + (Number(n) || 0), 0);
    const g = ger.get(N(`${e.unidade}|${e.equipe}`) + '|' + N(e.categoria)) || 0;
    if (fora !== g) out.push(`C1 · ${e.unidade} · ${e.equipe} (${String(e.categoria).toLowerCase()}): o relatório de atendimento individual tem ${fora} atendimento(s) além da escuta inicial e o relatório gerencial tem ${g}. A C1 dessa equipe pode estar contando algo duas vezes ou deixando de contar; confira.`);
  }
  return out;
}

function linhasCalculadas(coleta, filtros) {
  const out = coleta.linhas.map(l => Object.assign({}, l));
  const chaveEq = l => `${l.unidade}|${l.equipe}`;
  const grupoOk = (l, grupos) => !!grupos[l.grupoCBO];

  // Q14.2.1 — faltas ÷ (atendimentos + faltas), com filtros de CBO e tipo de falta.
  // Só com o absenteísmo lido nesta coleta: sem ele, as faltas sairiam zeradas. (Coletas antigas não têm "lidos".)
  const comAbsenteismo = !coleta.lidos || coleta.lidos.absenteismo;
  // As faltas e os atendimentos da mesma equipe se juntam pelo nome normalizado: os dois relatórios escrevem alguns nomes
  // de jeitos diferentes ("Sem Equipe" no absenteísmo, "SEM EQUIPE" nos atendimentos), o que partia a equipe em duas linhas.
  const chaveQ = l => UTIL.normalizar(`${l.unidade}|${l.equipe}`);
  const acc = new Map();
  for (const a of coleta.cubos.absenteismo) {
    if (!grupoOk(a, filtros.grupos) || !filtros.faltas[a.tipoFalta]) continue;
    const k = chaveQ(a); const o = acc.get(k) || { unidade: a.unidade, equipe: a.equipe, faltas: 0, atend: 0 };
    o.faltas += a.n; acc.set(k, o);
  }
  for (const a of coleta.cubos.atendimentos) {
    if (!grupoOk(a, filtros.grupos)) continue;
    const k = chaveQ(a); const o = acc.get(k) || { unidade: a.unidade, equipe: a.equipe, faltas: 0, atend: 0 };
    o.atend += a.n; acc.set(k, o);
  }
  if (comAbsenteismo) for (const o of acc.values()) out.push({ codigo: 'Q14.2.1', unidade: o.unidade, equipe: o.equipe, numerador: o.faltas, denominador: o.atend + o.faltas });

  // C1 — demanda programada ÷ total, só com os CBOs e tipos de equipe da Nota C1.
  // O tipo de cada equipe vem da coleta por unidade; sem ela, todas as equipes entram.
  const cbosC1 = new Set(CONFIG.c1.cbos);
  const tiposEq = new Map(coleta.linhas.filter(l => l.tipoEquipe).map(l => [UTIL.normalizar(`${l.unidade}|${l.equipe}`), String(l.tipoEquipe).toUpperCase()]));
  // Fica de fora: atendimento sem equipe e equipe cujo tipo conhecido não é eSF/eAP.
  // Equipe de tipo desconhecido entra (os CBOs da nota já excluem ESB e eMulti).
  const equipeOkC1 = a => {
    // "Sem equipe" e "INE não encontrado" não são equipes; Consultório na Rua e Saúde em Casa não fazem C1.
    if (UTIL.equipeFalsa(a.equipe) || UTIL.pareceECR(a.equipe) || UTIL.equipeFora(a.equipe)) return false;
    const t = tiposEq.get(UTIL.normalizar(`${a.unidade}|${a.equipe}`));
    return !t || CONFIG.c1.tiposEquipe.includes(t);
  };
  const c1 = new Map();
  for (const a of coleta.cubos.atendimentos) {
    if (!cbosC1.has(a.cboCodigo) || !equipeOkC1(a)) continue;
    const k = chaveEq(a); const o = c1.get(k) || { unidade: a.unidade, equipe: a.equipe, prog: 0, total: 0, ger: 0 };
    o.total += a.n; o.ger += a.n;
    const t = UTIL.normalizar(a.tipoAtendimento);
    if (t === 'consulta agendada' || t.startsWith('consulta agendada programada')) o.prog += a.n;
    c1.set(k, o);
  }
  // Escuta inicial (demanda espontânea) lida do relatório de atendimento individual.
  const escuta = coleta.cubos.escuta || [];
  const porNome = new Map([...c1.values()].map(o => [UTIL.normalizar(`${o.unidade}|${o.equipe}`), o]));
  for (const e of escuta) {
    if (e.periodoOk === false) continue; // relatório saiu com outro período: não vale
    const k = UTIL.normalizar(`${e.unidade}|${e.equipe}`);
    let o = porNome.get(k);
    if (!o) { o = { unidade: e.unidade, equipe: e.equipe, prog: 0, total: 0, ger: 0 }; porNome.set(k, o); c1.set(`${e.unidade}|${e.equipe}`, o); }
    o.total += e.escuta || 0;
    o.escuta = (o.escuta || 0) + (e.escuta || 0);
  }
  // A C1 precisa da escuta inicial (demanda espontânea) da mesma unidade: sem ela, o denominador fica menor e a C1 sai acima do real.
  // Unidade sem escuta lida nesta coleta não gera C1 (no Painel continua a da coleta anterior). Coletas antigas não têm a lista.
  // E precisa dos atendimentos (numerador): só com a escuta, a C1 sairia zerada.
  // A conferência é por equipe: as duas categorias da escuta (médico e enfermeiro) lidas, no período certo.
  const novas = !!coleta.escutaUnidades; // coletas a partir da 0.9.15
  const cats = CONFIG.c1.categoriasEscuta.map(c => UTIL.normalizar(c));
  const lidas = new Map();
  for (const e of escuta) {
    if (e.periodoOk === false) continue;
    const k = UTIL.normalizar(`${e.unidade}|${e.equipe}`);
    if (!lidas.has(k)) lidas.set(k, new Set()); lidas.get(k).add(UTIL.normalizar(e.categoria));
  }
  const escutaCompleta = o => cats.every(c => (lidas.get(UTIL.normalizar(`${o.unidade}|${o.equipe}`)) || new Set()).has(c));
  const comAtendimentos = !coleta.lidos || coleta.lidos.atendimentos;
  for (const o of c1.values()) {
    // Equipe só da escuta (sem atendimento no relatório gerencial, por exemplo nome escrito de outro jeito) não vira C1 zerada.
    if (!comAtendimentos || (novas && (!escutaCompleta(o) || !o.ger))) continue;
    out.push({ codigo: 'C1', unidade: o.unidade, equipe: o.equipe, numerador: o.prog, denominador: o.total, escuta: o.escuta || 0 });
  }
  out.push(...CALCULO.saudeBucal(coleta));
  out.push(...CALCULO.emulti(coleta));
  out.push(...CALCULO.coletivasEquipes(coleta));
  return out;
}

function agregarNivel(linhas, nivel) {
  const grupos = new Map();
  for (const l of linhas) {
    const k = [l.codigo, nivel === 'municipio' ? '' : l.unidade, nivel === 'equipe' ? l.equipe : ''].join('|');
    const g = grupos.get(k) || { codigo: l.codigo, unidade: nivel === 'municipio' ? 'Município' : l.unidade, equipe: nivel === 'equipe' ? l.equipe : '', numerador: 0, denominador: 0, somaPontos: 0, valor: 0 };
    g.numerador += l.numerador || 0;
    g.denominador += l.denominador || 0;
    g.somaPontos += l.somaPontos || 0;
    g.valor += l.valor || 0;
    g.fontes = (g.fontes || 0) + 1; if (l.faixa) g.faixa = l.faixa;
    grupos.set(k, g);
  }
  // C7: a nota sai dos itens já agregados no mesmo nível (Σ cumpridas ÷ faixa × peso).
  const itensC7 = new Map();
  for (const g of grupos.values()) {
    const m = /^C7-([ABCD])$/.exec(g.codigo);
    if (!m) continue;
    const k = `${g.unidade}|${g.equipe}`;
    const o = itensC7.get(k) || { unidade: g.unidade, equipe: g.equipe, itens: {} };
    o.itens[m[1]] = [g.numerador, g.denominador];
    itensC7.set(k, o);
  }
  for (const o of itensC7.values()) {
    const r = INDICADORES_C7.nota(o.itens);
    grupos.set(`C7|${o.unidade}|${o.equipe}`, { codigo: 'C7', unidade: o.unidade, equipe: o.equipe, numerador: 0, denominador: 0, somaPontos: 0, valor: r.nota, resultadoDireto: r.nota });
  }
  // CVAT: escore do cadastro (até 3) + escore do acompanhamento (até 7), pelas faixas da NT 30/2025.
  const cvat = new Map();
  for (const g of grupos.values()) {
    if (g.codigo !== 'CVAT-CAD' && g.codigo !== 'CVAT-ACO') continue;
    const k = `${g.unidade}|${g.equipe}`;
    const o = cvat.get(k) || { unidade: g.unidade, equipe: g.equipe };
    o[g.codigo] = g; cvat.set(k, o);
  }
  for (const o of cvat.values()) {
    if (!o['CVAT-CAD'] || !o['CVAT-ACO']) continue;
    const r = CALCULO.notaCvat(o['CVAT-CAD'], o['CVAT-ACO']);
    grupos.set(`CVAT|${o.unidade}|${o.equipe}`, { codigo: 'CVAT', unidade: o.unidade, equipe: o.equipe, numerador: 0, denominador: 0, somaPontos: 0, valor: r.nota, resultadoDireto: r.nota, escores: r });
  }
  return [...grupos.values()].map(g => {
    if (g.resultadoDireto !== undefined) { g.resultado = g.resultadoDireto; return g; }
    const tipo = (CATALOGO[g.codigo] || {}).tipo;
    if (tipo === 'pontos') g.resultado = g.denominador ? g.somaPontos / g.denominador : null;
    else if (tipo === 'percentual') g.resultado = g.denominador ? 100 * g.numerador / g.denominador : null;
    else if (tipo === 'razao') g.resultado = g.denominador ? g.numerador / g.denominador : null;
    else g.resultado = g.valor;
    return g;
  }).sort((a, b) => a.codigo.localeCompare(b.codigo, 'pt', { numeric: true }) || a.unidade.localeCompare(b.unidade) || a.equipe.localeCompare(b.equipe));
}

const fmt = (n, casas = 1) => n === null || n === undefined || isNaN(n) ? '—' : Number(n).toLocaleString('pt-BR', { maximumFractionDigits: casas, minimumFractionDigits: casas });

// ---------------------------------------------------------------- exibição
function renderizar() {
  const c = estado.coletaAtual;
  if (!c) return;
  $('secResultado').hidden = false;
  $('resComp').textContent = c.competencia;
  montarFiltrosQ14();
  const nivel = $('nivel').value;
  const linhas = agregarNivel(linhasCalculadas(c, estado.filtros), nivel);
  const t = $('tabela');
  const local = nivel === 'municipio' ? 'Abrangência' : nivel === 'equipe' ? 'Unidade · equipe' : 'Unidade';
  let html = `<thead><tr><th>${local}</th><th class="num">Num.</th><th class="num">Den.</th><th class="num">Result.</th></tr></thead><tbody>`;
  // excluídos por indicador (ex.: gestações acima de 42 semanas)
  const excl = {};
  for (const l of c.linhas) if (l.excluidos) excl[l.codigo] = (excl[l.codigo] || 0) + l.excluidos;
  let ultimo = '';
  for (const l of linhas) {
    const cat = CATALOGO[l.codigo] || { nome: l.codigo, tipo: '' };
    if (l.codigo !== ultimo) {
      const notaCat = l.codigo === 'C1' && !((c.cubos && c.cubos.escuta) || []).length ? 'sem escuta inicial no denominador (não coletada)' : (cat.nota || '');
      const nota = [cat.meta ? `meta ${cat.meta}` : '', notaCat,excl[l.codigo] ? `${excl[l.codigo]} registro(s) fora do período desconsiderado(s)` : ''].filter(Boolean).join(' · ');
      const esc = t => String(t).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
      const info = cat.margem ? ` <span class="info" title="${esc((cat.precisao === 'piso' ? 'Piso: o valor real é igual ou maior. ' : cat.precisao === 'aproximado' ? 'Aproximado. ' : '') + cat.margem)}">i</span>` : '';
      html += `<tr class="grupo"><td colspan="4">${l.codigo} · ${cat.nome}${info}${nota ? ` <small>(${nota})</small>` : ''}</td></tr>`;
      ultimo = l.codigo;
    }
    const semNumDen = cat.tipo === 'contagem' || cat.tipo === 'nota';
    const num = cat.tipo === 'pontos' ? fmt(l.somaPontos, 0) : semNumDen ? '' : fmt(l.numerador, 0);
    const res = cat.tipo === 'percentual' ? fmt(l.resultado) + '%' : cat.tipo === 'razao' ? fmt(l.resultado, 2) : (cat.tipo === 'pontos' || cat.tipo === 'nota') ? fmt(l.resultado) : fmt(l.resultado, 0);
    const faixa = l.faixa && l.fontes === 1 ? ` <small>(${fmt(l.faixa[0], cat.tipo === 'razao' ? 2 : 1)} a ${fmt(l.faixa[1], cat.tipo === 'razao' ? 2 : 1)})</small>` : '';
    const onde = nivel === 'municipio' ? 'Município' : nivel === 'equipe' ? `${l.unidade}<br><small>${l.equipe || ''}</small>` : l.unidade;
    html += `<tr><td>${onde}</td><td class="num">${num}</td><td class="num">${semNumDen ? '' : fmt(l.denominador, 0)}</td><td class="num"><strong>${res}</strong>${faixa}</td></tr>`;
  }
  t.innerHTML = html + '</tbody>';
  const av = $('avisos');
  av.innerHTML = (c.avisos || []).map(a => `<li>${a}</li>`).join('');
  av.hidden = !(c.avisos || []).length;
}

function montarFiltrosQ14() {
  const c = $('filtrosCBO'), f = $('filtrosFalta');
  if (c.childElementCount) return;
  c.innerHTML = '<strong>Grupos de CBO</strong>';
  for (const [k, g] of Object.entries(CONFIG.gruposCBO)) {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" ${estado.filtros.grupos[k] ? 'checked' : ''}> ${g.rotulo}`;
    l.querySelector('input').onchange = e => { estado.filtros.grupos[k] = e.target.checked; renderizar(); };
    c.appendChild(l);
  }
  f.innerHTML = '<strong>Tipo de falta</strong>';
  for (const t of CONFIG.tiposFalta) {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" ${estado.filtros.faltas[t] ? 'checked' : ''}> ${t.charAt(0) + t.slice(1).toLowerCase()}`;
    l.querySelector('input').onchange = e => { estado.filtros.faltas[t] = e.target.checked; renderizar(); };
    f.appendChild(l);
  }
}

// ---------------------------------------------------------------- histórico e exportação
// Envio da composição ao Painel APS (endereço e chave ficam só neste navegador, em chrome.storage).
// Filas e faltas: envia os totais por profissional (médicos e enfermeiros). O Painel junta com o que já tinha do mês.
async function enviarFilas(coleta) {
  const lista = !coleta.filas ? [] : Array.isArray(coleta.filas) ? coleta.filas : [...coleta.filas.values()];
  if (!lista.length) return;
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Filas e faltas: Painel APS não configurado para envio.'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/filas', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave }, body: JSON.stringify({ competencia: coleta.competencia, profissionais: lista }) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    log(`Filas e faltas: ${lista.length} profissionais enviados ao Painel APS.`, 'ok');
  } catch (e) { coleta.avisos.push('Filas e faltas não enviadas ao Painel APS: ' + e.message); log('Filas e faltas não enviadas ao Painel APS: ' + e.message, 'erro'); }
}

// Junta a produção individual (relatório gerencial) com a coletiva (atividades) do mesmo profissional.
// Chave: unidade + equipe + CBO + nome. Se a equipe vier escrita de outro jeito, tenta unidade + CBO + nome (quando único).
function juntarProducao(individuais, coletivas) {
  const N = UTIL.normalizar;
  const chave = p => [N(p.unidade), N(p.equipe), UTIL.codigoCBO(p.cbo), N(p.nome)].join('|');
  const curta = p => [N(p.unidade), UTIL.codigoCBO(p.cbo), N(p.nome)].join('|');
  const out = new Map(), porCurta = new Map();
  const zero = { individuais: 0, compartilhados: 0, porTipo: {}, coletivasResponsavel: 0, coletivasEnvolvido: 0, participacoes: 0 };
  for (const p of individuais) {
    const o = Object.assign({}, zero, p, { ine: p.ine || '' });
    out.set(chave(p), o);
    const k = curta(p); porCurta.set(k, porCurta.has(k) ? null : o);
  }
  for (const p of coletivas) {
    let o = out.get(chave(p)) || porCurta.get(curta(p));
    if (!o) { o = Object.assign({}, zero, { unidade: p.unidade, equipe: p.equipe, ine: p.ine, cbo: p.cbo, cboNome: p.cboNome, nome: p.nome }); out.set(chave(p), o); }
    o.ine = o.ine || p.ine; o.cboNome = o.cboNome || p.cboNome;
    o.coletivasResponsavel += p.coletivasResponsavel; o.coletivasEnvolvido += p.coletivasEnvolvido; o.participacoes += p.participacoes;
  }
  return [...out.values()];
}

// Produção por profissional: envia ao Painel APS. O Painel troca a produção do mês pela recebida.
async function enviarProducao(coleta) {
  const lista = Array.isArray(coleta.producao) ? coleta.producao : [];
  if (!lista.length) return;
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Produção por profissional: Painel APS não configurado para envio.'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/producao', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave },
      body: JSON.stringify({ competencia: coleta.competencia, profissionais: lista }) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    log(`Produção por profissional: ${lista.length} profissionais enviados ao Painel APS.`, 'ok');
  } catch (e) { coleta.avisos.push('Produção por profissional não enviada ao Painel APS: ' + e.message); log('Produção por profissional não enviada ao Painel APS: ' + e.message, 'erro'); }
}

// Vacinas: envia as doses aplicadas do mês (só totais). O Painel troca as doses do mês.
async function enviarVacinas(coleta) {
  const lista = Array.isArray(coleta.vacinas) ? coleta.vacinas : [];
  if (!lista.length) return;
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Vacinas: Painel APS não configurado para envio.'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/vacinas-pec', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave },
      body: JSON.stringify({ competencia: coleta.competencia, doses: lista }) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    log(`Vacinas: ${lista.length} linhas de doses enviadas ao Painel APS.`, 'ok');
  } catch (e) { coleta.avisos.push('Vacinas não enviadas ao Painel APS: ' + e.message); log('Vacinas não enviadas ao Painel APS: ' + e.message, 'erro'); }
}

// Faltas por horário: envia a grade "dia da semana × hora" de cada profissional. O Painel troca a grade do mês.
async function enviarFilasHorario(coleta) {
  const lista = Array.isArray(coleta.filasHorario) ? coleta.filasHorario : [];
  if (!lista.length) return;
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Faltas por horário: Painel APS não configurado para envio.'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/filas/horarios', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave },
      body: JSON.stringify({ competencia: coleta.competencia, profissionais: lista.map(p => ({ unidade: p.unidade, equipe: p.equipe, cbo: p.cbo, categoria: p.categoria, nome: p.nome, grade: p.grade })) }) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const tot = lista.reduce((t, p) => ({ a: t.a + p.atendidos, f: t.f + p.faltas }), { a: 0, f: 0 });
    log(`Faltas por horário: ${lista.length} profissionais enviados ao Painel APS (${tot.f} faltas em ${tot.a + tot.f} consultas com desfecho).`, 'ok');
  } catch (e) { coleta.avisos.push('Faltas por horário não enviadas ao Painel APS: ' + e.message); log('Faltas por horário não enviadas ao Painel APS: ' + e.message, 'erro'); }
}

async function enviarComposicao(coleta) {
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Composição guardada na coleta (Painel APS não configurado para envio).'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/composicao', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave }, body: JSON.stringify(coleta.composicao) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    log('Composição enviada ao Painel APS.', 'ok');
  } catch (e) { coleta.avisos.push('Composição não enviada ao Painel APS: ' + e.message); log('Composição não enviada ao Painel APS: ' + e.message, 'erro'); }
}

// Envio completo da coleta ao Painel APS: abre a coleta, grava as etapas (idempotente) e conclui.
// As linhas enviadas já incluem os indicadores calculados no nível equipe; os cubos vão em lotes.
async function painelFetch(caminho, metodo, corpo) {
  // No limite diário de gravação, nem tenta (cada tentativa recusada também conta para o Worker e só gera erro).
  if (limiteAtivo() && metodo !== 'GET') throw new Error('limite diário de gravação do banco do Painel atingido (volta às ' + horaLimite() + ')');
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1' + caminho, { method: metodo,
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave }, body: JSON.stringify(corpo) });
  if (!r.ok) {
    let m = ''; try { m = (await r.json()).erro || ''; } catch (_) { /* sem corpo */ }
    if (r.status === 401) avisarChave(m);
    if (r.status === 503 && /limite di[aá]rio/i.test(m)) avisarLimite(m);
    throw new Error(`HTTP ${r.status}${m ? ' – ' + m : ''}`);
  }
  if (estado.chaveRecusada) limparAvisoChave();
  if (estado.limiteAte && !limiteAtivo()) { estado.limiteAte = null; const el = $('alertaChave'); if (el) el.hidden = true; }
  return r.json();
}
// Próxima virada do limite diário do D1: 00:00 UTC (21:00 em Brasília).
function proximaViradaUTC() { const d = new Date(); d.setUTCHours(24, 0, 0, 0); return d.getTime(); }
const horaLimite = () => new Date(estado.limiteAte || proximaViradaUTC()).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
function avisarLimite(msg) {
  const novo = !limiteAtivo();
  estado.limiteAte = proximaViradaUTC();
  if (novo) log('Painel APS: ' + (msg || 'limite diário de gravação atingido') + ' A coleta continua; o envio fica para depois de ' + horaLimite() + ', pelo histórico.', 'erro');
  const el = $('alertaChave'); if (!el) return;
  el.innerHTML = '<strong>O banco do Painel APS atingiu o limite diário de gravação.</strong>É o limite do plano gratuito da Cloudflare. '
    + 'A coleta continua e fica guardada no histórico deste computador. Depois de ' + horaLimite() + ', clique em "Enviar ao Painel" em cada mês do histórico.';
  el.hidden = false;
}
// Chave de coleta recusada (vencida, revogada ou errada): aviso fixo no topo do painel, não só uma linha no registro.
// A coleta continua; como cada envio lê a chave na hora, basta colar uma chave nova em "Envio ao Painel APS".
function avisarChave(msg) {
  const el = $('alertaChave'); if (!el) return;
  if (!estado.chaveRecusada) log('Painel APS recusou a chave de coleta' + (msg ? ` (${msg})` : '') + '. O que não foi enviado vai assim que a chave for trocada.', 'erro');
  estado.chaveRecusada = true;
  el.innerHTML = '<strong>O Painel APS recusou a chave de coleta.</strong>Ela venceu, foi revogada ou está errada. A coleta continua, mas nada está chegando ao Painel. '
    + 'Gere uma chave nova em Painel APS → Extensões → Chaves de coleta e cole em "Envio ao Painel APS" (abaixo). O que ficou para trás é enviado na próxima unidade e no fim.';
  el.hidden = false;
  const det = $('painelChave') && $('painelChave').closest('details'); if (det) det.open = true;
}
function limparAvisoChave() {
  estado.chaveRecusada = false;
  const el = $('alertaChave'); if (el && !el.hidden) { el.hidden = true; log('Painel APS: chave aceita, envio normalizado.', 'ok'); }
}

// ---------------------------------------------------------------- envio ao Painel durante a coleta
// A coleta é aberta no Painel logo no começo, e cada unidade vai assim que termina, na mesma etapa do envio final
// (que a substitui, sem duplicar). Se o painel fechar no meio, o que já foi enviado fica valendo.
// B1, B4 e M1 dependem de outras unidades ou do fim da coleta: só vão no envio final.
const SO_NO_FIM = new Set(['B1', 'B4', 'M1']);
function linhasParaEnvio(coleta) {
  return linhasCalculadas(coleta, filtrosPadrao())
    .filter(l => !(coleta.retroComData && LINHAS_DE_HOJE.includes(l.codigo)))
    .map(l => Object.assign({}, l, { unidade: l.unidade || 'Município', equipe: l.equipe || 'Município' }));
}
const lote = (lista, n = 10000) => { const o = []; for (let i = 0; i < lista.length; i += n) o.push(lista.slice(i, i + n)); return o; };
function etapasMunicipais(coleta) {
  const etapas = [];
  lote(coleta.cubos.atendimentos || []).forEach((l, i) => etapas.push({ chave: 'cubo-atendimentos:' + (i + 1), bloco: 'cubos', cubos: { atendimentos: l } }));
  lote(coleta.cubos.absenteismo || []).forEach((l, i) => etapas.push({ chave: 'cubo-absenteismo:' + (i + 1), bloco: 'cubos', cubos: { absenteismo: l } }));
  return etapas;
}
// Escuta inicial: uma etapa por unidade. Assim, uma coleta de poucas unidades não apaga a escuta das outras no Painel.
function etapasEscuta(coleta, so) {
  const porUn = new Map();
  for (const e of coleta.cubos.escuta || []) {
    if (so && UTIL.normalizar(e.unidade) !== UTIL.normalizar(so)) continue;
    if (!porUn.has(e.unidade)) porUn.set(e.unidade, []); porUn.get(e.unidade).push(e);
  }
  return [...porUn].map(([u, l]) => ({ chave: 'cubo-escuta:' + u, bloco: 'cubos', unidade: u, cubos: { escuta: l } }));
}
// Registro da coleta (o passo a passo do painel, com o tempo de cada parte): vai ao Painel para conferência. Sem dado de paciente.
// Vai em partes ("registro:0001", "registro:0002"…), cada uma só com as linhas novas. Antes o registro inteiro ia de novo
// a cada unidade e regravava centenas de linhas no banco do Painel (o plano gratuito grava 100 mil linhas por dia).
function etapaRegistro(coleta, linhas) {
  const n = Math.min(linhas.length, 2000);
  return { chave: 'registro:' + String((coleta.registroSeq || 0) + 1).padStart(4, '0'), bloco: 'registro', avisos: linhas.slice(0, n), _n: n };
}
// Marca de conteúdo de uma etapa: no envio final, a etapa que já foi ao Painel igualzinha não é mandada de novo.
function assinatura(et) {
  const s = JSON.stringify([et.bloco, et.unidade || null, et.linhas || null, et.cubos || null, et.avisos || null]);
  let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 0).toString(36) + '.' + s.length;
}
// Limite diário de gravação do banco do Painel (Cloudflare D1, plano gratuito): até a virada (00:00 UTC), não adianta enviar.
const limiteAtivo = () => !!(estado.limiteAte && Date.now() < estado.limiteAte);
async function painelConfigurado() {
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  return !!(painelUrl && painelChave);
}
async function abrirNoPainel(coleta, quieto = false) {
  if (!(await painelConfigurado())) return;
  try {
    await painelFetch('/coletas', 'POST', { id: coleta.id, competencia: coleta.competencia, tipo: 'completa', versaoExtensao: coleta.versao,
      iniciadoEm: coleta.iniciadoEm, config: coleta.config });
    coleta.abertaNoPainel = true;
  } catch (e) { if (!quieto) log('Painel APS: a coleta não foi aberta agora (' + e.message + '); tenta de novo a cada unidade e no fim.', 'aviso'); }
}
// A coleta não abriu no começo (chave recusada, sem rede): tenta de novo a cada unidade. Se abrir, manda logo tudo o que
// já foi lido (município, unidades feitas, escuta e registro), para um acidente depois disso não perder nada.
async function abrirAtrasado(coleta) {
  await abrirNoPainel(coleta, true);
  if (!coleta.abertaNoPainel) return false;
  log('Painel APS: coleta aberta agora; enviando o que já foi lido.', 'ok');
  try {
    for (const et of etapasMunicipais(coleta)) await enviarEtapaJa(coleta, et);
    const porChave = new Map();
    for (const l of linhasParaEnvio(coleta)) { if (SO_NO_FIM.has(l.codigo)) continue; if (!porChave.has(l.unidade)) porChave.set(l.unidade, []); porChave.get(l.unidade).push(l); }
    for (const [u, ls] of porChave) await enviarEtapaJa(coleta, { chave: 'unidade:' + u, bloco: 'unidade', unidade: u, linhas: ls });
    for (const et of etapasEscuta(coleta)) await enviarEtapaJa(coleta, et);
    await enviarRegistro(coleta);
  } catch (e) { log('Painel APS: parte do que já foi lido não foi enviada agora (' + e.message + '); vai de novo no fim.', 'aviso'); }
  return true;
}
async function enviarEtapaJa(coleta, et) {
  await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/etapa`, 'PUT', Object.assign({ status: 'ok', coletadoEm: coleta.iniciadoEm, tentativas: 1 }, et));
  (coleta.enviadas = coleta.enviadas || {})[et.chave] = assinatura(et);
}
// Manda as linhas novas do registro numa parte nova; se falhar, ficam para o próximo envio.
async function enviarRegistro(coleta, linhas = estado.registroPendente) {
  if (!linhas || !linhas.length) return;
  const { _n, ...et } = etapaRegistro(coleta, linhas);
  await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/etapa`, 'PUT', Object.assign({ status: 'ok', coletadoEm: coleta.iniciadoEm, tentativas: 1 }, et));
  coleta.registroSeq = (coleta.registroSeq || 0) + 1;
  linhas.splice(0, _n);
}
async function enviarUnidadeAoPainel(coleta, unidade) {
  if (limiteAtivo()) return; // fica tudo para o fim (e para o histórico, se o limite ainda valer)
  if (!coleta.abertaNoPainel) { if (await abrirAtrasado(coleta)) log(`${unidade}: enviada ao Painel APS.`, 'ok'); return; }
  const n = UTIL.normalizar(unidade);
  try {
    const porChave = new Map();
    for (const l of linhasParaEnvio(coleta)) {
      if (SO_NO_FIM.has(l.codigo) || UTIL.normalizar(l.unidade) !== n) continue;
      if (!porChave.has(l.unidade)) porChave.set(l.unidade, []); porChave.get(l.unidade).push(l);
    }
    for (const [u, ls] of porChave) await enviarEtapaJa(coleta, { chave: 'unidade:' + u, bloco: 'unidade', unidade: u, linhas: ls });
    for (const et of etapasEscuta(coleta, unidade)) await enviarEtapaJa(coleta, et);
    if (porChave.size) log(`${unidade}: enviada ao Painel APS.`, 'ok');
    await enviarRegistro(coleta);
  } catch (e) { log(`${unidade}: envio ao Painel falhou agora (${e.message}); vai de novo no fim.`, 'aviso'); }
}
async function enviarMunicipioAoPainel(coleta) {
  if (!coleta.abertaNoPainel || limiteAtivo()) return;
  try { for (const et of etapasMunicipais(coleta)) await enviarEtapaJa(coleta, et); }
  catch (e) { log(`Atendimentos e absenteísmo: envio ao Painel falhou agora (${e.message}); vai de novo no fim.`, 'aviso'); }
}

// opc (reenvio a partir do histórico): { registro, incompleta } guardados com a coleta.
async function enviarColeta(coleta, opc = {}) {
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Indicadores guardados só neste computador (envio ao Painel APS não configurado).'); return; }
  const aviso = m => { coleta.avisos.push(m); log(m, 'erro'); };
  if (limiteAtivo()) { aviso('Coleta não enviada ao Painel APS: limite diário de gravação do banco do Painel atingido. Use "Enviar ao Painel" no histórico depois de ' + horaLimite() + '.'); return; }
  try {
    await painelFetch('/coletas', 'POST', { id: coleta.id, competencia: coleta.competencia, tipo: 'completa', versaoExtensao: coleta.versao,
      iniciadoEm: coleta.iniciadoEm, config: coleta.config });
  } catch (e) { aviso('Coleta não enviada ao Painel APS: ' + e.message); return; }

  const etapas = [];
  const porUnidade = new Map();
  for (const l of linhasParaEnvio(coleta)) { if (!porUnidade.has(l.unidade)) porUnidade.set(l.unidade, []); porUnidade.get(l.unidade).push(l); }
  for (const [unidade, ls] of porUnidade) etapas.push({ chave: 'unidade:' + unidade, bloco: 'unidade', unidade, linhas: ls });
  etapas.push(...etapasMunicipais(coleta), ...etapasEscuta(coleta));
  etapas.push({ chave: 'avisos', bloco: 'avisos', avisos: coleta.avisos.filter(a => !/^Coleta não (enviada|concluída) (ao|no) Painel APS/.test(a)).slice(0, 500) });

  let falhas = 0, iguais = 0;
  for (const et of etapas) {
    // Já está no Painel exatamente assim (foi na hora, unidade a unidade): não grava de novo.
    if (coleta.enviadas && coleta.enviadas[et.chave] === assinatura(et)) { iguais++; continue; }
    let ok = false, erro = '';
    for (let t = 1; t <= 3 && !ok; t++) {
      try { await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/etapa`, 'PUT', Object.assign({ status: 'ok', coletadoEm: coleta.iniciadoEm, tentativas: t }, et)); ok = true; }
      catch (e) { erro = e.message; await UTIL.dormir(1500 * t); }
    }
    if (ok) (coleta.enviadas = coleta.enviadas || {})[et.chave] = assinatura(et);
    if (!ok) { falhas++; log(`Etapa "${et.chave}" não enviada: ${erro}`, 'erro'); coleta.avisos.push(`Painel APS: etapa "${et.chave}" não enviada (${erro}).`);
      try { await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/etapa`, 'PUT', { chave: et.chave, bloco: et.bloco, unidade: et.unidade, status: 'falhou', erro, coletadoEm: coleta.iniciadoEm }); } catch (_) { /* sem rede */ } }
  }
  if (iguais) log(`Painel APS: ${iguais} parte(s) já estavam lá iguais e não foram gravadas de novo.`);
  // Registro: só as linhas que ainda não foram (no reenvio pelo histórico, as guardadas com a coleta).
  try { await enviarRegistro(coleta, 'registro' in opc ? (opc.registro || []) : estado.registroPendente); } catch (e) { log('Registro da coleta não enviado ao Painel: ' + e.message, 'aviso'); }
  try {
    const incompleta = 'incompleta' in opc ? !!opc.incompleta : (estado.cancelar || !!(estado.unidadesErro || []).length);
    const completa = !falhas && !incompleta;
    const substituir = coleta.substituir === 'todos' && completa;
    if (coleta.substituir === 'todos' && !completa)
      log('Coleta incompleta: os dados anteriores desta competência foram mantidos e só o que veio agora foi atualizado. Para substituir tudo, colete de novo sem falhas.', 'erro');
    const r = await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/concluir`, 'POST', { status: completa ? 'concluida' : 'parcial', concluidoEm: new Date().toISOString(), substituir: substituir ? 'todos' : 'selecionados' });
    if (r.substituidas) log(`Dados anteriores de ${coleta.competencia} substituídos no Painel APS (${r.substituidas} etapas antigas deixaram de valer).`, 'ok');
    coleta.enviadoEm = new Date().toISOString();
    log(`Coleta enviada ao Painel APS (${r.etapas.ok} etapas ok${r.etapas.falhas ? ', ' + r.etapas.falhas + ' com falha' : ''}).`, falhas ? 'erro' : 'ok');
  } catch (e) { aviso('Coleta não concluída no Painel APS: ' + e.message); }
}
document.addEventListener('DOMContentLoaded', async () => {
  const u = $('painelUrl'), k = $('painelChave'); if (!u || !k) return;
  const v = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  u.value = v.painelUrl || 'https://painelaps.pages.dev'; k.value = v.painelChave || '';
  const salvar = () => chrome.storage.local.set({ painelUrl: u.value.trim(), painelChave: k.value.trim() });
  u.addEventListener('change', salvar);
  k.addEventListener('change', async () => { await salvar(); if (estado.chaveRecusada) { $('alertaChave').hidden = true; log('Chave de coleta trocada: vale a partir do próximo envio.', 'ok'); } });
});

// Coleta que não chegou ao Painel (chave recusada, sem rede): pode ser enviada de novo a partir do histórico.
// Filas, faltas por horário, vacinas e produção por profissional não ficam no histórico (têm nomes de profissionais) e não vão.
const naoEnviada = c => !c.enviadoEm && (c.avisos || []).some(a => /^Coleta não (enviada|concluída) (ao|no) Painel APS/.test(a));
async function reenviarDoHistorico(c, botao) {
  if (TRAVA.id) { log('Espere a coleta em andamento terminar para enviar coletas do histórico.', 'erro'); return; }
  if (!(await painelConfigurado())) { log('Configure o envio ao Painel APS (endereço e chave) antes.', 'erro'); return; }
  if (limiteAtivo()) { log('O banco do Painel ainda está no limite diário de gravação. Tente depois de ' + horaLimite() + '.', 'erro'); return; }
  botao.disabled = true; botao.textContent = 'Enviando…';
  log(`Enviando ao Painel APS a coleta de ${c.competencia} guardada no histórico…`);
  await enviarColeta(c, { registro: c.registroGuardado || null, incompleta: !!c.incompleta });
  if (c.enviadoEm) {
    delete c.registroGuardado;
    c.avisos = c.avisos.filter(a => !/^Coleta não (enviada|concluída) (ao|no) Painel APS/.test(a));
    log(`Coleta de ${c.competencia} enviada ao Painel APS. Filas, faltas por horário, vacinas e produção por profissional não ficam no histórico; se faltarem no Painel, colete esse mês de novo só com esses itens.`, 'ok');
  }
  const h = await lerHistorico();
  const i = h.findIndex(x => x.id === c.id); if (i >= 0) { h[i] = c; await chrome.storage.local.set({ coletas: h }); }
  await renderizarHistorico();
}
async function lerHistorico() { return (await chrome.storage.local.get('coletas')).coletas || []; }
async function salvarColeta(c) { const h = await lerHistorico(); h.unshift(c); await chrome.storage.local.set({ coletas: h }); }

async function renderizarHistorico() {
  const h = await lerHistorico();
  const ul = $('historico');
  ul.innerHTML = h.length ? '' : '<li><small>Nenhuma coleta ainda.</small></li>';
  for (const c of h) {
    const li = document.createElement('li');
    const quando = new Date(c.iniciadoEm).toLocaleString('pt-BR');
    li.innerHTML = `<span><strong>${c.competencia}</strong> <small>coletado em ${quando}${c.avisos.length ? ` · ${c.avisos.length} aviso(s)` : ''}</small></span>
      <span class="acoes">${naoEnviada(c) ? '<button data-a="enviar" title="Esta coleta não chegou ao Painel APS">Enviar ao Painel</button>' : ''}<button class="sec" data-a="ver">Ver</button><button class="sec" data-a="inc" title="Relatório de inconsistências em PDF">Inconsistências</button><button class="sec" data-a="excluir">Excluir</button></span>`;
    const be = li.querySelector('[data-a="enviar"]'); if (be) be.onclick = () => reenviarDoHistorico(c, be);
    li.querySelector('[data-a="ver"]').onclick = () => { estado.coletaAtual = c; renderizar(); $('secResultado').scrollIntoView(); };
    li.querySelector('[data-a="inc"]').onclick = () => abrirInconsistencias(c);
    const bx = li.querySelector('[data-a="excluir"]');
    bx.onclick = async () => {
      if (bx.dataset.confirmar !== '1') { bx.dataset.confirmar = '1'; bx.textContent = 'Confirmar'; return; }
      await chrome.storage.local.set({ coletas: (await lerHistorico()).filter(x => x.id !== c.id) });
      renderizarHistorico();
    };
    ul.appendChild(li);
  }
}

function baixar(nome, conteudo, tipo) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([conteudo], { type: tipo }));
  a.download = nome; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

function exportarJSON(c) {
  if (!c) return;
  const pacote = Object.assign({}, c, {
    indicadores: ['municipio', 'unidade', 'equipe'].flatMap(n => agregarNivel(linhasCalculadas(c, filtrosPadrao()), n).map(l => Object.assign({ nivel: n }, l)))
  });
  baixar(`indicadores-aps-${c.competencia}.json`, JSON.stringify(pacote, null, 2), 'application/json');
}

function exportarCSV(c) {
  if (!c) return;
  const linhas = ['municipio', 'unidade', 'equipe'].flatMap(n => agregarNivel(linhasCalculadas(c, filtrosPadrao()), n).map(l => Object.assign({ nivel: n }, l)));
  const cab = ['competencia', 'nivel', 'codigo', 'indicador', 'unidade', 'equipe', 'numerador', 'denominador', 'soma_pontos', 'resultado'];
  const esc = v => `"${String(v === null || v === undefined ? '' : v).replace(/"/g, '""')}"`;
  const corpo = linhas.map(l => [c.competencia, l.nivel, l.codigo, (CATALOGO[l.codigo] || {}).nome || '', l.unidade, l.equipe, l.numerador, l.denominador, l.somaPontos,
    l.resultado === null ? '' : String(+l.resultado.toFixed(2)).replace('.', ',')].map(esc).join(';'));
  baixar(`indicadores-aps-${c.competencia}.csv`, '﻿' + [cab.join(';'), ...corpo].join('\n'), 'text/csv');
}


// ---------- Relatório de inconsistências (PDF) ----------
// Guarda, junto da coleta, só contagens por unidade (nenhum nome de profissional), para poder apontar o que ficou faltando.
function registrarCobertura(coleta) {
  const contar = (lista, filtro) => {
    const m = {};
    for (const x of lista) { if (filtro && !filtro(x)) continue; m[x.unidade] = (m[x.unidade] || 0) + 1; }
    return m;
  };
  const filas = !coleta.filas ? [] : Array.isArray(coleta.filas) ? coleta.filas : [...coleta.filas.values()];
  coleta.cobertura = {
    unidadesPlanejadas: unidadesSelecionadas(),
    unidadesComErro: [...new Set(estado.unidadesErro || [])],
    opcoes: { filas: !!$('optFilas').checked, horario: !!$('optFilasHora').checked, composicao: !!$('optComposicao').checked },
    filasPorUnidade: contar(filas),
    agendaPorUnidade: contar(filas, p => p.agendaLidaEm || p.diasVaga != null || p.semVaga),
    horarioPorUnidade: contar(Array.isArray(coleta.filasHorario) ? coleta.filasHorario : []),
    composicaoUnidades: ((coleta.composicao && coleta.composicao.unidades) || []).map(u => u.nome)
  };
}

const SEM_REGRA_100 = new Set(['CVAT-ACO', 'CVAT-CAD', 'B4']);     // CVAT: "piso" (o PEC só dá a data do último atendimento); B4: a nota não exige que a criança seja vinculada à equipe, então passa de 100%
const OPCIONAIS = /^(CR\d|M1$|M2$|B[1-6]$)/;                      // dependem do tipo de equipe da unidade

function montarInconsistencias(c) {
  const cob = c.cobertura || null;
  const norm = x => UTIL.normalizar(x);
  const achados = []; // { nivel: erro|atencao|info, unidade, tema, texto }
  const add = (nivel, unidade, tema, texto) => achados.push({ nivel, unidade: unidade || 'Geral', tema, texto });

  const planejadas = cob ? cob.unidadesPlanejadas : [...new Set(c.linhas.map(l => l.unidade))];
  const nomeDe = u => planejadas.find(p => norm(p) === norm(u)) || u;
  const falhou = new Set((cob ? cob.unidadesComErro : []).map(norm));

  // 1) Unidades com a coleta interrompida
  for (const u of (cob ? cob.unidadesComErro : [])) {
    const motivos = c.avisos.filter(a => norm(a).startsWith(norm(u) + ':')).map(a => a.slice(a.indexOf(':') + 1).trim());
    add('erro', u, 'Coleta da unidade', 'A coleta desta unidade não foi concluída' + (motivos.length ? ': ' + [...new Set(motivos)].join('; ') : '.') + ' Use "Refazer só as que falharam".');
  }

  // 2) Indicadores por unidade
  let linhasUn = [];
  try { linhasUn = agregarNivel(linhasCalculadas(c, filtrosPadrao()), 'unidade').filter(l => l.unidade && l.unidade !== 'Município'); } catch (_) { /* sem cálculo */ }
  const porUn = new Map();
  for (const l of linhasUn) { const k = norm(l.unidade); if (!porUn.has(k)) porUn.set(k, { nome: l.unidade, cods: new Map() }); porUn.get(k).cods.set(l.codigo, l); }
  const comDados = [...porUn.values()];
  const freq = {};
  comDados.forEach(u => u.cods.forEach((_, cod) => { if (cod !== 'COLET') freq[cod] = (freq[cod] || 0) + 1; })); // COLET é auxiliar (totais de produção): não entra nas conferências
  const limite = Math.max(2, Math.ceil(comDados.length * 0.6));
  const esperados = Object.keys(freq).filter(cod => freq[cod] >= limite && !OPCIONAIS.test(cod));
  const opcionais = Object.keys(freq).filter(cod => OPCIONAIS.test(cod));

  for (const u of planejadas) {
    if (falhou.has(norm(u))) continue;
    const d = porUn.get(norm(u));
    if (!d) { add('erro', u, 'Indicadores', 'Nenhum indicador por unidade foi coletado.'); continue; }
    const faltam = esperados.filter(cod => !d.cods.has(cod)).sort();
    if (faltam.length) add('atencao', u, 'Indicadores ausentes', `Não coletados (presentes na maioria das unidades): ${faltam.join(', ')}.`);
    const faltaOpc = opcionais.filter(cod => !d.cods.has(cod)).sort();
    if (faltaOpc.length) add('info', u, 'Indicadores opcionais', `Sem dados de: ${faltaOpc.join(', ')}. Pode ser normal se a unidade não tem esse tipo de equipe (odontologia, eMulti, eCR).`);
  }

  // 3) Valores suspeitos
  const NOTAS = { B2: 'O indicador conta registros sem vincular à primeira consulta; sem faixa oficial', B4: 'O denominador vem de VINC6A12 (crianças de 6 a 12 anos vinculadas), lido na coleta por unidade' };
  for (const d of comDados) {
    for (const l of d.cods.values()) {
      if (l.resultadoDireto !== undefined || l.somaPontos || l.codigo === 'COLET') continue;
      const num = l.numerador || 0, den = l.denominador || 0;
      if (den === 0 && num > 0) add('atencao', d.nome, 'Valores suspeitos', `${l.codigo}: numerador ${num} com denominador 0 (resultado indisponível).${NOTAS[l.codigo] ? ' ' + NOTAS[l.codigo] + '.' : ''}`);
      else if (den > 0 && num > den) add(SEM_REGRA_100.has(l.codigo) ? 'info' : 'atencao', d.nome, 'Valores suspeitos', `${l.codigo}: numerador ${num} maior que o denominador ${den} (${(100 * num / den).toFixed(1).replace('.', ',')}%).${SEM_REGRA_100.has(l.codigo) ? (l.codigo === 'B4' ? ' Esperado: pela nota, a criança do numerador não precisa estar vinculada à equipe.' : ' Esperado: é um índice por piso.') : NOTAS[l.codigo] ? ' ' + NOTAS[l.codigo] + '.' : ''}`);
    }
  }

  // 4) Filas, horários e composição
  if (cob) {
    for (const u of planejadas) {
      if (falhou.has(norm(u))) continue;
      const na = (m) => Object.entries(m || {}).filter(([k]) => norm(k) === norm(u)).reduce((t, [, n]) => t + n, 0);
      if (cob.opcoes.filas && !na(cob.filasPorUnidade)) add('atencao', u, 'Filas e faltas', 'Nenhum médico ou enfermeiro com produção ou agenda lido.');
      if (cob.opcoes.filas && na(cob.filasPorUnidade) && !na(cob.agendaPorUnidade)) add('atencao', u, 'Filas e faltas', 'Profissionais lidos, mas nenhuma agenda (dias até a próxima vaga).');
      if (cob.opcoes.horario && !na(cob.horarioPorUnidade)) add('atencao', u, 'Faltas por horário', 'Nenhuma grade de horários lida.');
      if (cob.opcoes.composicao && !cob.composicaoUnidades.some(n => norm(n) === norm(u))) add('atencao', u, 'Composição', 'Unidade fora do quadro de composição desta coleta.');
    }
  }

  // 5) Demais avisos da coleta (os que já viraram achado por unidade não se repetem)
  const usados = new Set();
  for (const a of c.avisos) {
    const un = planejadas.find(p => norm(a).startsWith(norm(p) + ':'));
    if (un && falhou.has(norm(un))) continue;
    const comp = /^Composição/.test(a);
    const m = /^([^:]+):\s*(.*)$/.exec(a);
    const unidade = un || null;
    const texto = un ? a.slice(a.indexOf(':') + 1).trim() : a;
    const chave = (unidade || '') + '|' + texto;
    if (usados.has(chave)) continue; usados.add(chave);
    add('atencao', unidade, comp ? 'Composição' : 'Avisos da coleta', texto);
    void m;
  }
  const ordem = { erro: 0, atencao: 1, info: 2 };
  achados.sort((a, b) => ordem[a.nivel] - ordem[b.nivel] || a.unidade.localeCompare(b.unidade, 'pt') || a.tema.localeCompare(b.tema, 'pt'));
  return {
    competencia: c.competencia, versao: c.versao, iniciadoEm: c.iniciadoEm, concluidoEm: c.concluidoEm,
    geradoEm: new Date().toISOString(), semCobertura: !cob,
    unidadesPlanejadas: planejadas.length, unidadesComErro: cob ? cob.unidadesComErro.length : null,
    totais: { erro: achados.filter(a => a.nivel === 'erro').length, atencao: achados.filter(a => a.nivel === 'atencao').length, info: achados.filter(a => a.nivel === 'info').length },
    achados
  };
}

async function abrirInconsistencias(c) {
  if (!c) { log('Faça uma coleta ou abra uma do histórico para gerar o relatório.', 'erro'); return; }
  const rel = montarInconsistencias(c);
  await chrome.storage.local.set({ relInconsistencias: rel });
  chrome.tabs.create({ url: chrome.runtime.getURL('panel/inconsistencias.html') });
}
