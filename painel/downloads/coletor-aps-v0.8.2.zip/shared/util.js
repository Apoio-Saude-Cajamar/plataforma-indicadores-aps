// Funções utilitárias compartilhadas (painel e página).
var UTIL = {
  normalizar(s) {
    return String(s || '')
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/\s+/g, ' ').trim().toLowerCase();
  },

  // "2026-10" -> { inicio: '2026-10-01', fim: '2026-10-31', referencia: Date(fim 23:59) }
  // Últimos 4 meses até o fim da competência: { inicio: '2026-07-01', fim: '2026-10-31' }
  quadrimestreAte(comp) {
    // Janela móvel da NT 43/2026 (M1): os 4 meses até a competência, incluindo o mês dela.
    const [a, m] = comp.split('-').map(Number);
    const d = new Date(a, m - 4, 1);
    const c = UTIL.competencia(comp);
    return { inicio: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`, fim: c.fim, quad: `4m-${comp}`, meses: 4 };
  },

  // Resumo irreversível de um identificador interno, com um sal sorteado a cada coleta.
  // Serve só para contar pessoas diferentes entre unidades; o sal e os resumos nunca são salvos.
  async resumo(sal, id) {
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(sal + '|' + id));
    return [...new Uint8Array(b).slice(0, 10)].map(x => x.toString(16).padStart(2, '0')).join('');
  },

  competencia(comp) {
    const [a, m] = comp.split('-').map(Number);
    const ultimo = new Date(a, m, 0).getDate();
    const mm = String(m).padStart(2, '0');
    return {
      ano: a, mes: m,
      inicio: `${a}-${mm}-01`,
      fim: `${a}-${mm}-${String(ultimo).padStart(2, '0')}`,
      referencia: new Date(a, m - 1, ultimo, 23, 59, 59)
    };
  },

  competenciaAnterior(hoje = new Date()) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth() - 1, 1);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  },

  // Converte datas do PEC (ISO "AAAA-MM-DD", ISO com hora, "DD/MM/AAAA" ou epoch ms) em Date.
  data(v) {
    if (v === null || v === undefined || v === '') return null;
    if (typeof v === 'number') return new Date(v);
    const s = String(v);
    let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
    m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})/);
    if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
    const d = new Date(s);
    return isNaN(d) ? null : d;
  },

  dias(a, b) { return (b - a) / 86400000; },

  mesesAntes(ref, meses) {
    const d = new Date(ref);
    d.setMonth(d.getMonth() - meses);
    return d;
  },

  // Data está entre (ref - meses) e ref.
  dentroDe(v, ref, meses) {
    const d = UTIL.data(v);
    if (!d) return false;
    return d <= ref && d >= UTIL.mesesAntes(ref, meses);
  },

  // Código CBO de 6 dígitos a partir de "Nome - 223565" ou "223565".
  codigoCBO(s) {
    const m = String(s || '').match(/(\d{6})\s*$/) || String(s || '').match(/\b(\d{4,6})\b/);
    return m ? m[1] : '';
  },

  grupoCBO(codigo, grupos) {
    for (const [id, g] of Object.entries(grupos)) {
      if (g.prefixos.some(p => codigo.startsWith(p))) return id;
    }
    return 'outros';
  },

  dormir(ms) { return new Promise(r => setTimeout(r, ms)); }
};
