// Coletores. Cada um devolve apenas totais agregados.
var COLETORES = {

  ehAPS(nome) {
    const n = UTIL.normalizar(nome);
    return CONFIG.unidadesAPS.some(u => UTIL.normalizar(u) === n);
  },

  // ================= MUNICIPAIS (uma chamada cobre todas as unidades) =================

  // Atendimentos individuais e odontológicos por unidade, equipe, CBO e tipo (C1 e base do Q14.2.1).
  async atendimentos(comp, progresso) {
    const c = UTIL.competencia(comp);
    const keys = ['unidadeSaude', 'equipe', 'cbo', 'tipoAtendimento'];
    progresso && progresso('Atendimentos: consultando relatório gerencial do município...');
    const resp = await PEC.gerencial('atendimento-profissional/build', {
      keys, dateRange: { startDate: c.inicio, endDate: c.fim }, periodUnit: 'MES', filtroCiapCid: [], filterKeys: {}
    });
    const linhas = [];
    COLETORES._achatar(resp, keys, {}, linhas, 0);
    const aps = linhas.filter(l => COLETORES.ehAPS(l.unidadeSaude)).map(l => ({
      unidade: l.unidadeSaude, equipe: l.equipe, cbo: l.cbo,
      cboCodigo: UTIL.codigoCBO(l.cbo), grupoCBO: UTIL.grupoCBO(UTIL.codigoCBO(l.cbo), CONFIG.gruposCBO),
      tipoAtendimento: l.tipoAtendimento, n: l.n
    }));
    progresso && progresso(`Atendimentos: ${aps.reduce((s, l) => s + l.n, 0)} registros nas unidades de APS.`);
    return aps;
  },

  // Faltas (não compareceu / não aguardou) por unidade, equipe e CBO (Q14.2.1).
  async absenteismo(comp, progresso) {
    const c = UTIL.competencia(comp);
    progresso && progresso('Absenteísmo: consultando faltas do município...');
    const q = QUERIES.absenteismos;
    const data = await PEC.gql(q.op, q.query, { input: { dateRange: { startDate: c.inicio, endDate: c.fim }, periodUnit: 'MES' } });
    const mapa = new Map();
    for (const r of data.absenteismos || []) {
      if (!COLETORES.ehAPS(r.unidadeSaude)) continue;
      const chave = [r.unidadeSaude, r.equipe, r.cbo, r.nomeSituacaoAgendamento].join('|');
      mapa.set(chave, (mapa.get(chave) || 0) + 1);
    }
    const linhas = [...mapa.entries()].map(([k, n]) => {
      const [unidade, equipe, cbo, tipoFalta] = k.split('|');
      const cod = UTIL.codigoCBO(cbo);
      return { unidade, equipe, cbo, cboCodigo: cod, grupoCBO: UTIL.grupoCBO(cod, CONFIG.gruposCBO), tipoFalta, n };
    });
    progresso && progresso(`Absenteísmo: ${linhas.reduce((s, l) => s + l.n, 0)} faltas nas unidades de APS.`);
    return linhas;
  },

  // Tipo de cada equipe do município, pelo INE (ESF, EAP, ESB, EMULTI, ECR...).
  async tiposDeEquipe() {
    const q = QUERIES.equipes;
    const d = await PEC.gql(q.op, q.query, { input: { query: null, pageParams: { size: 500, fetchPageInfo: false, sort: ['nome'] } } });
    const m = {};
    for (const e of d.equipes.content || []) if (e.ine) m[e.ine] = (e.tipoEquipe && e.tipoEquipe.sigla) || '';
    return m;
  },

  // Atividades coletivas do mês (B4, M1 e M2): lista do município e detalhe de cada atividade.
  // Devolve totais por equipe; nada identifica os participantes.
  async atividadesColetivas(comp, progresso) {
    const c = UTIL.competencia(comp);
    progresso && progresso('Atividades coletivas: listando as atividades do mês...');
    const ql = QUERIES.atividadesLista;
    const base = { isReuniao: false, equipesIne: [], tiposAtividade: [], origens: [], periodo: { startDate: c.inicio, endDate: c.fim } };
    const itens = await PEC.paginar(ql.op, ql.query,
      (page, size) => ({ input: Object.assign({}, base, { pageParams: { page, size, sort: ['-dataAtividade'] } }) }),
      d => d.atividadesColetivas);
    const ids = itens.map(i => i.id);
    const tipos = await COLETORES.tiposDeEquipe();
    const qd = QUERIES.atividadeDetalhe;
    const detalhes = [];
    let falhas = 0;
    const lote = CONFIG.atividadesParalelas || 6;
    for (let i = 0; i < ids.length; i += lote) {
      await Promise.all(ids.slice(i, i + lote).map(async id => {
        for (let t = 0; t < 3; t++) {
          try { const d = await PEC.gql(qd.op, qd.query, { id }, 1); detalhes.push(d.atividadeColetiva); return; }
          catch (e) { if (/Sessão do PEC/.test(e.message)) throw e; await UTIL.dormir(1500 * (t + 1)); }
        }
        falhas++;
      }));
      if (progresso && (i / lote) % 10 === 0) progresso(`Atividades coletivas: ${Math.min(i + lote, ids.length)} de ${ids.length} lidas...`);
    }
    const linhas = INDICADORES.agregarAtividades(detalhes.filter(Boolean), tipos, CONFIG.saudeBucal.b4);
    const avisos = falhas ? [`Atividades coletivas: ${falhas} de ${ids.length} atividades não puderam ser lidas.`] : [];
    progresso && progresso(`Atividades coletivas: ${detalhes.length} atividades lidas, ${linhas.length} equipes envolvidas.`);
    return { linhas, total: ids.length, lidas: detalhes.length, avisos };
  },

  // ---------- eMulti: M1 (quadrimestre) e M2 ----------
  // M2, parte individual: atendimentos da eMulti com e sem "Atendimento compartilhado" (relatório gerencial, mês).
  async compartilhadoEmulti(comp) {
    const c = UTIL.competencia(comp);
    const keys = ['equipe', 'atendimentoCompartilhadoLotacao'];
    const resp = await PEC.gerencial('atendimento-profissional/build', { keys, dateRange: { startDate: c.inicio, endDate: c.fim }, periodUnit: 'MES', filtroCiapCid: [], filterKeys: {} });
    const linhas = [];
    COLETORES._achatar(resp, keys, {}, linhas, 0);
    const out = {};
    for (const l of linhas) {
      const o = out[l.equipe] = out[l.equipe] || { equipe: l.equipe, total: 0, compartilhados: 0 };
      o.total += l.n;
      if (/^sim$/i.test(String(l.atendimentoCompartilhadoLotacao).trim())) o.compartilhados += l.n;
    }
    return Object.values(out);
  },

  // Equipes eMulti do município (id, nome, INE).
  async equipesEmulti() {
    const q = QUERIES.equipesEmulti;
    const d = await PEC.gql(q.op, q.query, { input: { query: null, pageParams: { size: 500, fetchPageInfo: false, sort: ['nome'] } } });
    const ines = (CONFIG.emulti && CONFIG.emulti.ines) || {};
    return (d.equipes.content || []).filter(e => e.ativo !== false && ((e.tipoEquipe && e.tipoEquipe.sigla === 'EMULTI') || ines[e.ine])).map(e => ({ id: e.id, nome: e.nome, ine: e.ine }));
  },

  // M1, numerador individual: atendimentos individuais da eMulti no quadrimestre até o mês (gerencial, todas as unidades).
  async atendimentosEmultiQuad(comp) {
    const q = UTIL.quadrimestreAte(comp);
    const keys = ['equipe'];
    const resp = await PEC.gerencial('atendimento-profissional/build', { keys, dateRange: { startDate: q.inicio, endDate: q.fim }, periodUnit: 'MES', filtroCiapCid: [], filterKeys: {} });
    const linhas = [];
    COLETORES._achatar(resp, keys, {}, linhas, 0);
    const out = {};
    linhas.forEach(l => { out[l.equipe] = (out[l.equipe] || 0) + l.n; });
    return out;
  },

  // M1, pessoas atendidas individualmente: lista de atendimentos da unidade atual, por equipe eMulti, no quadrimestre.
  // Só entra o que foi registrado no PEC (fichas CDS não aparecem nesta lista). Devolve contagens e resumos com sal.
  async pessoasEmultiUnidade(comp, sal, equipes) {
    const q = UTIL.quadrimestreAte(comp);
    const ql = QUERIES.listaAtendimentos;
    const [a1, m1] = q.inicio.split('-').map(Number), [a2, m2, d2] = q.fim.split('-').map(Number);
    const out = {};
    for (const e of equipes) {
      const lst = await PEC.paginar(ql.op, ql.query, (page, size) => ({ input: {
        ordem: 'CLASSIFICACAO_RISCO', somenteMeusAtendimentos: false, statusAtendimento: [],
        dataInicio: new Date(a1, m1 - 1, 1).getTime(), dataFim: new Date(a2, m2 - 1, d2, 23, 59, 59).getTime(),
        equipesIds: [e.id], isRegistroTardio: false, pageParams: { page, size } } }), d => d.atendimentos, null, 1000);
      const feitos = lst.filter(x => x.statusAtendimento === 'ATENDIMENTO_REALIZADO' && x.cidadao && x.cidadao.id);
      if (!feitos.length) continue;
      const resumos = new Set();
      for (const x of feitos) resumos.add(await UTIL.resumo(sal, x.cidadao.id));
      out[e.ine] = { atendimentos: feitos.length, resumos: [...resumos] };
    }
    return out;
  },

  // M1, atividades coletivas da eMulti no quadrimestre até o mês: participações e resumos dos participantes por INE.
  async coletivasEmultiQuad(comp, sal, ines, progresso) {
    const q = UTIL.quadrimestreAte(comp);
    const ql = QUERIES.atividadesLista, qd = QUERIES.atividadeDetalhe;
    const base = { isReuniao: false, equipesIne: ines, tiposAtividade: [], origens: [], periodo: { startDate: q.inicio, endDate: q.fim } };
    const ids = (await PEC.paginar(ql.op, ql.query, (page, size) => ({ input: Object.assign({}, base, { pageParams: { page, size } }) }), d => d.atividadesColetivas)).map(i => i.id);
    const alvo = new Set(ines);
    const out = {};
    let falhas = 0;
    const lote = CONFIG.atividadesParalelas || 6;
    for (let i = 0; i < ids.length; i += lote) {
      await Promise.all(ids.slice(i, i + lote).map(async id => {
        let a = null;
        for (let t = 0; t < 3 && !a; t++) { try { a = (await PEC.gql(qd.op, qd.query, { id }, 1)).atividadeColetiva; } catch (e) { await UTIL.dormir(1500 * (t + 1)); } }
        if (!a) { falhas++; return; }
        const eqs = new Set([a.lotacaoResponsavel, ...(a.lotacoesEnvolvidas || [])].filter(l => l && l.equipe && alvo.has(l.equipe.ine)).map(l => l.equipe.ine));
        const pids = (a.participantes || []).map(p => (p.cidadao || p.cidadaoParticipante || {}).id).filter(Boolean);
        for (const ine of eqs) {
          const o = out[ine] = out[ine] || { atividades: 0, participacoes: 0, resumos: new Set() };
          o.atividades++;
          o.participacoes += pids.length;
          for (const pid of pids) o.resumos.add(await UTIL.resumo(sal, pid));
        }
      }));
      if (progresso && (i / lote) % 15 === 0) progresso(`M1: atividades coletivas da eMulti no quadrimestre, ${Math.min(i + lote, ids.length)} de ${ids.length}...`);
    }
    Object.values(out).forEach(o => { o.resumos = [...o.resumos]; });
    return { porIne: out, total: ids.length, falhas };
  },

  // Achata a árvore do relatório gerencial { chave: { subchave: { nodeValue } } }.
  _achatar(no, keys, ctx, out, nivel) {
    for (const [k, v] of Object.entries(no || {})) {
      if (k === 'nodeKey' || k === 'nodeValue' || k === 'maxLeafValue') continue;
      const c2 = Object.assign({}, ctx, { [keys[nivel]]: k });
      if (nivel === keys.length - 1) out.push(Object.assign(c2, { n: (v && v.nodeValue) || 0 }));
      else COLETORES._achatar(v, keys, c2, out, nivel + 1);
    }
  },

  // ================= POR ACESSO (uma unidade de cada vez) =================

  async sessao() {
    const q = QUERIES.sessao;
    return (await PEC.gql(q.op, q.query, {})).sessao;
  },

  // Troca o acesso para a unidade pela própria API do PEC (sem recarregar a página).
  async trocarAcesso(unidade, progresso) {
    const s = await COLETORES.sessao();
    const alvo = UTIL.normalizar(unidade);
    const candidatos = (s.profissional.acessos || []).filter(a => a.unidadeSaude && UTIL.normalizar(a.unidadeSaude.nome) === alvo);
    if (!candidatos.length) throw new Error('Você não tem acesso a esta unidade no PEC.');
    const preferido = candidatos.find(a => !a.equipe && UTIL.normalizar(a.cbo && a.cbo.nome).startsWith(UTIL.normalizar(CONFIG.perfilAcesso))) || candidatos.find(a => !a.equipe) || candidatos[0];
    if (s.acesso && s.acesso.id === preferido.id) return { recarregando: false, acessoId: preferido.id };
    const q = QUERIES.selecionarAcesso;
    await PEC.gql(q.op, q.query, { input: { id: preferido.id } });
    const s2 = await COLETORES.sessao();
    if (!s2.acesso || s2.acesso.id !== preferido.id) throw new Error('O PEC não confirmou a troca de acesso.');
    progresso && progresso(`${unidade}: acesso selecionado.`);
    return { recarregando: false, acessoId: preferido.id };
  },

  async equipes(unidadeSaudeId) {
    const q = QUERIES.equipes;
    const d = await PEC.gql(q.op, q.query, { input: { query: null, unidadeSaudeId, pageParams: { size: 100, fetchPageInfo: false, sort: ['nome'] } } });
    return (d.equipes.content || []).filter(e => e.ativo !== false).map(e => ({ id: e.id, nome: e.nome, ine: e.ine, tipo: (e.tipoEquipe && e.tipoEquipe.sigla) || '' }));
  },

  // Horas semanais na agenda dos dentistas da APS (CBO 223293 e 223208) de cada eSB da unidade do acesso atual.
  async horasSaudeBucal() {
    const ql = QUERIES.lotacoesAgenda, qg = QUERIES.gradeAgenda;
    const d = await PEC.gql(ql.op, ql.query, { input: { pageParams: { size: 300 }, isAgendaAd: false } });
    const min = h => { const [a, b] = String(h).split(':').map(Number); return a * 60 + (b || 0); };
    const horas = {};
    for (const l of (d.lotacoesAgenda.content || [])) {
      if (l.ativo === false || !l.equipe || !l.equipe.ine || !CONFIG.saudeBucal.cbos.includes(String((l.cbo && l.cbo.cbo2002) || '')) || !l.hasConfiguracaoAgenda) continue;
      const g = await PEC.gql(qg.op, qg.query, { lotacaoId: l.id });
      const dias = (((g.lotacao || {}).configuracaoAgenda || {}).configuracaoHorarioAgenda || {}).configuracaoDiasSemana || [];
      const h = dias.reduce((s, dd) => s + (dd.periodos || []).filter(p => p.horarioInicial && p.horarioFinal)
        .reduce((x, p) => x + Math.max(0, min(p.horarioFinal) - min(p.horarioInicial)), 0), 0) / 60;
      horas[l.equipe.ine] = (horas[l.equipe.ine] || 0) + h;
    }
    return horas;
  },

  async equipesVinculadas(equipeId) {
    const q = QUERIES.equipesVinculadas;
    const d = await PEC.gql(q.op, q.query, { input: { equipePrincipalId: equipeId, pageParams: { size: 50 } } });
    return (d.equipesVinculadas.content || []).filter(e => e.ativo !== false && e.ine).map(e => e.ine);
  },

  // Índices do acompanhamento do território por microárea (só totais).
  // Devolve { dentro, fa, microareas }: "dentro" soma as microáreas da equipe, "fa" é a microárea Fora de Área,
  // guardada à parte (não entra na CVAT, mas serve para planejar).
  async territorio(cnes, ine) {
    const base = { cnes, ine, tipoEndereco: 'LOGRADOURO', stAtivo: true };
    const qe = QUERIES.territorioEquipe, qm = QUERIES.territorioMicroarea;
    const ms = ((await PEC.gql(qe.op, qe.query, { input: base })).territorioEquipe || {}).microareas || [];
    const vazio = () => ({ imoveis: 0, imoveisAtualizados: 0, imoveisNaoRecusados: 0, cadastroCompleto: 0, domiciliosAvaliados: 0, domiciliosVisitados: 0 });
    const dentro = vazio(), fa = vazio(), microareas = [];
    for (const m of ms.filter(x => x !== null && x !== undefined)) {
      const d = await PEC.gql(qm.op, qm.query, { input: Object.assign({}, base, { microarea: m, pageParams: { page: 0, size: 1 } }) });
      const i = (d.territorioMicroarea || {}).indices || {};
      const r = {
        imoveis: i.totalImoveisAtualizados || 0, imoveisAtualizados: i.quantidadeImoveisAtualizados || 0,
        imoveisNaoRecusados: i.totalImoveisNaoRecusados || 0, cadastroCompleto: i.quantidadeImoveisCadastroCompleto || 0,
        domiciliosAvaliados: i.quantidadeDomiciliosAvaliados || 0, domiciliosVisitados: i.quantidadeDomiciliosVisitados || 0
      };
      const alvo = String(m).toUpperCase() === 'FA' ? fa : dentro;
      Object.keys(r).forEach(k => { alvo[k] += r[k]; });
      microareas.push(Object.assign({ microarea: String(m) }, r));
    }
    return { dentro, fa, microareas };
  },

  async vinculados(equipeId, faixaEtaria) {
    const q = QUERIES.vinculados;
    const d = await PEC.gql(q.op, q.query, { input: { equipeResponsavelId: equipeId, faixaEtaria: faixaEtaria || { tipoFaixaEtaria: 'TODAS_FAIXAS', faixaEtariaRange: {} }, pageParams: { page: 0, size: 1 } } });
    return d.acompanhamentoCidadaosVinculados.pageInfo.totalElements;
  },

  // Busca todas as páginas de uma lista temática para uma equipe.
  async lista(unidadeSaudeId, equipeId, tematica, opcoes = {}) {
    const q = QUERIES.lista(tematica);
    const faixas = {
      PESSOA_IDOSA: { tipoFaixaEtaria: 'IDOSO', faixaEtariaRange: { idadeMinima: 60, tipoFaixaEtaria: 'ANOS' } },
      DESENVOLVIMENTO_INFANTIL: { tipoFaixaEtaria: 'OUTRA', faixaEtariaRange: { idadeMinima: 0, idadeMaxima: 1, tipoFaixaEtaria: 'ANOS' } }
    };
    // Diabetes e hipertensão: a própria tela filtra pelo grupo de condição prioritário
    // na lista de problemas ativa (5 = diabetes, 10 = hipertensão).
    const grupos = { DIABETES: [5], HIPERTENSAO_ARTERIAL: [10] };
    const base = {
      // Atenção: com mais de um código, o PEC devolve quem tem TODOS os códigos (E, não OU).
      ciaps: opcoes.ciaps || [], cid10: opcoes.cid10 || [],
      grupoCondicao: grupos[tematica] || [],
      tipoFiltroLPC: grupos[tematica] ? 'SOMENTE_ATIVOS_LPC' : 'TODOS',
      unidadeResponsavelId: unidadeSaudeId, equipeResponsavelId: equipeId,
      sexo: opcoes.sexo || null, identidadeGenero: opcoes.identidadeGenero || null,
      faixaEtaria: opcoes.faixaEtaria || faixas[tematica] || { tipoFaixaEtaria: 'TODAS_FAIXAS' },
      periodoUltimoAtendimento: opcoes.periodo || null,
      microareas: null, ivcf: null, tematica: tematica === 'GERAL_CODIGO' ? 'GERAL' : tematica,
      condicaoMaternal: tematica === 'GESTANTE_PUERPERA' ? 'TODAS' : null
    };
    return PEC.paginar(q.op, q.query,
      (page, size) => ({ input: Object.assign({}, base, { pageParams: { page, size, sort: ['microarea'] } }) }),
      d => d.acompanhamentoCondicaoSaude);
  },

  // Parâmetro populacional da CVAT pelo tipo da equipe (e carga horária da eAP).
  parametroCvat(eq) {
    const cf = CONFIG.cvat, tipo = String(eq.tipo || '').toUpperCase();
    if (tipo !== 'EAP') return cf.parametros.ESF;
    const N = UTIL.normalizar;
    const corr = Object.entries(cf.eapHorasPorEquipe || {}).find(([k]) => N(k) === N(eq.nome) || N(k) === N(eq.ine));
    return (corr ? corr[1] : cf.eapHoras) === 20 ? cf.parametros.EAP20 : cf.parametros.EAP30;
  },

  // CVAT por equipe: lê as duas listas (só datas, microárea, origem e o marcador do Bolsa Família) e devolve totais.
  async cvat(unidadeSaudeId, eq, ref, partes) {
    const tam = CONFIG.cvat.tamanhoPagina;
    const qv = QUERIES.vinculadosLista, qg = QUERIES.listaCvat;
    const vinc = await PEC.paginar(qv.op, qv.query,
      (page, size) => ({ input: { equipeResponsavelId: eq.id, faixaEtaria: { tipoFaixaEtaria: 'TODAS_FAIXAS', faixaEtariaRange: {} }, pageParams: { page, size } } }),
      d => d.acompanhamentoCidadaosVinculados, null, tam);
    const base = { ciaps: [], cid10: [], grupoCondicao: [], tipoFiltroLPC: 'TODOS', unidadeResponsavelId: unidadeSaudeId, equipeResponsavelId: eq.id,
      sexo: null, identidadeGenero: null, faixaEtaria: { tipoFaixaEtaria: 'TODAS_FAIXAS' }, periodoUltimoAtendimento: null, microareas: null, ivcf: null, tematica: 'GERAL', condicaoMaternal: null };
    const geral = await PEC.paginar(qg.op, qg.query, (page, size) => ({ input: Object.assign({}, base, { pageParams: { page, size } }) }),
      d => d.acompanhamentoCondicaoSaude, null, tam);
    return INDICADORES.cvat(vinc, geral, ref, partes);
  },

  // C7 item C: pessoas de 14 a 69 anos com algum código de saúde sexual e reprodutiva e atendimento
  // de médico ou enfermeiro nos 12 meses. O PEC aplica vários códigos como E, então cada código vai numa
  // consulta e o resultado é a união. Os identificadores ficam só na memória, para cruzar com a lista
  // de Saúde da Mulher; nada disso é guardado.
  async idsItemC7(unidadeSaudeId, equipeId, ref) {
    const cf = CONFIG.c7;
    const ini = UTIL.mesesAntes(ref, cf.janelaConsultaMeses);
    const periodo = { startDate: ini.toISOString(), endDate: ref.toISOString() };
    const faixaEtaria = { tipoFaixaEtaria: 'OUTRA', faixaEtariaRange: { idadeMinima: cf.faixas.C[0], idadeMaxima: cf.faixas.C[1], tipoFaixaEtaria: 'ANOS' } };
    const tarefas = [...cf.ciaps.map(c => ({ ciaps: [c] })), ...cf.cid10.map(c => ({ cid10: [c] }))];
    const ids = new Set();
    let i = 0;
    const trabalhador = async () => {
      while (i < tarefas.length) {
        const t = tarefas[i++];
        const lst = await COLETORES.lista(unidadeSaudeId, equipeId, 'GERAL_CODIGO', Object.assign({ periodo, faixaEtaria }, t));
        for (const p of lst) {
          if (UTIL.dentroDe(p.dataUltimoAtendimentoMedico, ref, cf.janelaConsultaMeses) || UTIL.dentroDe(p.dataUltimoAtendimentoEnfermagem, ref, cf.janelaConsultaMeses)) ids.add(String(p.cidadaoId));
        }
      }
    };
    await Promise.all(Array.from({ length: CONFIG.atividadesParalelas || 4 }, trabalhador));
    return ids;
  },

  // C7 por equipe: lista de Saúde da Mulher (sexo feminino + homens trans) e, se ligado, o item C.
  async c7(unidadeSaudeId, equipeId, ref, comItemC = true) {
    const mulheres = await COLETORES.lista(unidadeSaudeId, equipeId, 'SAUDE_MULHER', { sexo: 'FEMININO' });
    const homensTrans = await COLETORES.lista(unidadeSaudeId, equipeId, 'SAUDE_MULHER', { identidadeGenero: 'HOMEM_TRANS' });
    const ids = (comItemC && CONFIG.c7.coletarItemC) ? await COLETORES.idsItemC7(unidadeSaudeId, equipeId, ref) : null;
    const r = INDICADORES.c7(mulheres.concat(homensTrans), ref, ids);
    r.itemCColetado = !!ids;
    return r;
  },

  // Coleta todos os indicadores por equipe da unidade atualmente selecionada.
  async porUnidade(comp, unidade, progresso, opcoes = {}) {
    const c = UTIL.competencia(comp);
    const ref = c.referencia;
    const avisos = [];
    const s = await COLETORES.sessao();
    const us = s.acesso && s.acesso.unidadeSaude;
    if (!us || UTIL.normalizar(us.nome) !== UTIL.normalizar(unidade)) throw new Error(`O acesso ativo é "${us ? us.nome : '?'}", não "${unidade}".`);
    const equipes = await COLETORES.equipes(us.id);
    progresso && progresso(`${unidade}: ${equipes.length} equipes ativas.`);
    const T = Object.assign({ c2: true, c3: true, c4: true, c5: true, c6: true, c7: true, cr: true }, opcoes.temas || {});
    const linhas = [];
    // Observações: o que a nota não conta, mas vale acompanhar (vão para a página de observações da plataforma).
    const observacoes = [];
    const obs = (eq, tipo, valor, texto) => { if (valor) observacoes.push({ unidade, unidadeCnes: us.cnes, equipe: eq.nome, ine: eq.ine, tipo, valor, texto }); };
    const base = eq => ({ unidade, unidadeCnes: us.cnes, equipe: eq.nome, ine: eq.ine, tipoEquipe: eq.tipo });

    for (const eq of equipes) {
      const tipo = eq.tipo.toUpperCase();
      const territorial = ['ESF', 'EAP', 'EACS'].includes(tipo);
      if (!territorial && tipo !== 'ECR') continue; // ESB e eMulti não têm listas próprias aqui (fase 2)
      if (tipo === 'ECR' && !T.cr) continue;
      const op = { tipoEquipe: tipo, esquema: CONFIG.esquemaVacinalC2, agora: new Date() };
      try {
        // Q12.2 — pessoas vinculadas
        const nVinc = await COLETORES.vinculados(eq.id);
        linhas.push(Object.assign(base(eq), { codigo: 'Q12.2', valor: nVinc, fonte: 'Cidadãos vinculados' }));
        if (territorial) {
          // Crianças de 6 a 12 anos vinculadas: divisor da B4 (eSB de referência).
          try {
            const n612 = await COLETORES.vinculados(eq.id, { tipoFaixaEtaria: 'OUTRA', faixaEtariaRange: { idadeMinima: 6, idadeMaxima: 12, tipoFaixaEtaria: 'ANOS' } });
            linhas.push(Object.assign(base(eq), { codigo: 'VINC6A12', valor: n612, fonte: 'Cidadãos vinculados (6 a 12 anos)' }));
          } catch (e) { avisos.push(`${eq.nome}: vinculados de 6 a 12 anos não lidos (${e.message}).`); }
          // Território (CVAT, cadastro domiciliar): sem a microárea FA; a FA vai em linha própria.
          let terr = null;
          if (CONFIG.coletarTerritorio !== false && opcoes.territorio !== false) {
            try {
              const t = terr = await COLETORES.territorio(us.cnes, eq.ine);
              const fonte = 'Acompanhamento do território';
              const extra = { microareas: t.microareas.filter(m => m.microarea.toUpperCase() !== 'FA') };
              linhas.push(Object.assign(base(eq), { codigo: 'TERR-ATU', numerador: t.dentro.imoveisAtualizados, denominador: t.dentro.imoveis, fonte }, extra));
              linhas.push(Object.assign(base(eq), { codigo: 'TERR-COMP', numerador: t.dentro.cadastroCompleto, denominador: t.dentro.imoveisNaoRecusados, fonte }));
              linhas.push(Object.assign(base(eq), { codigo: 'TERR-VIS', numerador: t.dentro.domiciliosVisitados, denominador: t.dentro.domiciliosAvaliados, fonte, dataColeta: new Date().toISOString().slice(0, 10) }));
              obs(eq, 'imoveis-fora-de-area', t.fa.imoveis, 'Imóveis na microárea FA (fora de área): não entram na CVAT.');
              linhas.push(Object.assign(base(eq), { codigo: 'TERR-FA', valor: t.fa.imoveis, imoveisAtualizados: t.fa.imoveisAtualizados, cadastroCompleto: t.fa.cadastroCompleto, imoveisNaoRecusados: t.fa.imoveisNaoRecusados, fonte }));
            } catch (e) { avisos.push(`${eq.nome}: acompanhamento do território não lido (${e.message}).`); }
          }
          // CVAT: cadastro (MICI em 24 meses, mais o domicílio estimado pelo território) e acompanhamento.
          if (opcoes.cvat !== false) {
            try {
              const partes = {};
              (terr ? terr.microareas : []).forEach(m => { if (m.imoveis) partes[m.microarea] = m.imoveisAtualizados / m.imoveis; });
              const r = await COLETORES.cvat(us.id, eq, ref, partes);
              const par = COLETORES.parametroCvat(eq);
              const fonte = 'Cidadãos vinculados + Condições de saúde · Geral';
              obs(eq, 'cadastro-so-no-pec', r.cadastro.origemPec, 'Pessoas vinculadas com cadastro feito só no PEC (sem ficha de cadastro individual): não contam na CVAT.');
              obs(eq, 'cadastro-vencido', r.cadastro.miciVencido, 'Cadastros individuais sem atualização há mais de 24 meses: não contam na CVAT.');
              obs(eq, 'pessoas-fora-de-area', r.cadastro.foraDeArea, 'Pessoas vinculadas marcadas como fora da área: não contam na CVAT.');
              obs(eq, 'sem-microarea', r.cadastro.semMicroarea, 'Cadastros válidos sem microárea informada: o domicílio conta como não atualizado.');
              obs(eq, 'contato-de-um-tipo', r.acompanhamento.umTipo, 'Pessoas com contato de um só tipo em 12 meses: podem ter 2 contatos do mesmo tipo, que o PEC não mostra.');
              obs(eq, 'sem-contato-12m', r.acompanhamento.nenhum, 'Pessoas vinculadas sem atendimento nem visita em 12 meses.');
              linhas.push(Object.assign(base(eq), { codigo: 'CVAT-CAD', numerador: r.cadastro.ponderado, denominador: par, fonte, detalhe: r.cadastro, semTerritorio: !terr }));
              const denA = CONFIG.cvat.denominadorAcompanhamento === 'cadastrados' ? r.cadastro.ponderado : par;
              linhas.push(Object.assign(base(eq), { codigo: 'CVAT-ACO', numerador: r.acompanhamento.ponderado, denominador: denA, parametro: par, fonte, detalhe: r.acompanhamento }));
              if (!terr) avisos.push(`${eq.nome}: CVAT sem o território; o cadastro domiciliar conta como não atualizado.`);
            } catch (e) { avisos.push(`${eq.nome}: CVAT não coletada (${e.message}).`); }
          }
        }

        if (territorial) {
          let gest = [], idosos = [], dm = [], has = [], c2 = { denominador: 0 };
          if (T.c3) {
            gest = await COLETORES.lista(us.id, eq.id, 'GESTANTE_PUERPERA');
            const c3 = INDICADORES.agregar(gest, INDICADORES.c3, ref, op);
            linhas.push(Object.assign(base(eq), { codigo: 'C3', denominador: c3.denominador, somaPontos: c3.somaPontos, itens: c3.itens, excluidos: c3.excluidos, puerperasPor294: c3.extras.puerperaPor294 || 0 }));
            linhas.push(Object.assign(base(eq), { codigo: 'S20', denominador: c3.denominador, somaPontos: c3.somaPontos }));
            linhas.push(Object.assign(base(eq), { codigo: 'S3', numerador: c3.extras.S3_7consultas || 0, denominador: c3.denominador }));
            linhas.push(Object.assign(base(eq), { codigo: 'S4', numerador: c3.extras.S4_sifilis1e3 || 0, denominador: c3.denominador }));
          }
          if (T.c6) {
            idosos = await COLETORES.lista(us.id, eq.id, 'PESSOA_IDOSA');
            const c6 = INDICADORES.agregar(idosos, INDICADORES.c6, ref, op);
            linhas.push(Object.assign(base(eq), { codigo: 'C6', denominador: c6.denominador, somaPontos: c6.somaPontos, itens: c6.itens }));
          }
          if (T.c2) {
            const criancas = await COLETORES.lista(us.id, eq.id, 'DESENVOLVIMENTO_INFANTIL');
            c2 = INDICADORES.agregar(criancas, INDICADORES.c2, ref, op);
            linhas.push(Object.assign(base(eq), { codigo: 'C2', denominador: c2.denominador, somaPontos: c2.somaPontos, itens: c2.itens, excluidos: c2.excluidos }));
          }
          if (T.c4) {
            dm = await COLETORES.lista(us.id, eq.id, 'DIABETES');
            const c4 = INDICADORES.agregar(dm, INDICADORES.c4, ref, op);
            linhas.push(Object.assign(base(eq), { codigo: 'C4', denominador: c4.denominador, somaPontos: c4.somaPontos, itens: c4.itens }));
          }
          if (T.c5) {
            has = await COLETORES.lista(us.id, eq.id, 'HIPERTENSAO_ARTERIAL');
            const c5 = INDICADORES.agregar(has, INDICADORES.c5, ref, op);
            linhas.push(Object.assign(base(eq), { codigo: 'C5', denominador: c5.denominador, somaPontos: c5.somaPontos, itens: c5.itens }));
          }

          // C7: um item por linha (C7-A..D); a nota C7 é montada depois de agregar.
          if (T.c7) try {
            const c7 = await COLETORES.c7(us.id, eq.id, ref, opcoes.c7ItemC !== false);
            for (const k of ['A', 'B', 'C', 'D']) {
              const l = Object.assign(base(eq), { codigo: 'C7-' + k, numerador: c7[k][0], denominador: c7[k][1], fonte: 'Condições de saúde · Saúde da mulher' });
              if (k === 'C') Object.assign(l, { itemColetado: c7.itemCColetado, consultaPec: c7.cPec });
              linhas.push(l);
            }
            if (!c7.itemCColetado) avisos.push(`${eq.nome}: C7 item C não coletado (opção desligada); a nota C7 sai sem os 30 pontos do item C.`);
          } catch (e) { avisos.push(`${eq.nome}: C7 não coletada (${e.message}).`); }

          progresso && progresso(`${unidade} · ${eq.nome}: ${gest.length} gestantes/puérperas, ${idosos.length} idosos, ${c2.denominador} crianças < 2 anos, ${dm.length} com diabetes, ${has.length} com hipertensão.`);
        } else {
          // eCR — CR1: identificadas nos últimos 12 meses; atendidas por médico/enfermeiro/dentista em 6 meses
          const ini12 = UTIL.mesesAntes(ref, 12);
          const periodo = { startDate: new Date(ini12.getFullYear(), ini12.getMonth(), ini12.getDate()).toISOString(), endDate: ref.toISOString() };
          const geral = await COLETORES.lista(us.id, eq.id, 'GERAL', { periodo });
          const cr1 = INDICADORES.agregar(geral, INDICADORES.cr1, ref);
          linhas.push(Object.assign(base(eq), { codigo: 'CR1', numerador: cr1.somaPontos, denominador: cr1.denominador }));
          // CR2: gestantes da eCR.
          try {
            const gest = await COLETORES.lista(us.id, eq.id, 'GESTANTE_PUERPERA');
            const cr2 = INDICADORES.agregar(gest, INDICADORES.cr2, ref, op);
            linhas.push(Object.assign(base(eq), { codigo: 'CR2', denominador: cr2.denominador, somaPontos: cr2.somaPontos, itens: cr2.itens, excluidos: cr2.excluidos }));
          } catch (e) { avisos.push(`${eq.nome}: CR2 não coletada (${e.message}).`); }
          // CR3: pessoas identificadas em 12 meses e as datas dos testes de IST.
          let ist = [];
          try {
            ist = await COLETORES.lista(us.id, eq.id, 'SAUDE_MULHER', { periodo });
            const cr3 = INDICADORES.agregar(ist, INDICADORES.cr3, ref, op);
            linhas.push(Object.assign(base(eq), { codigo: 'CR3', denominador: cr3.denominador, somaPontos: cr3.somaPontos, itens: cr3.itens }));
          } catch (e) { avisos.push(`${eq.nome}: CR3 não coletada (${e.message}).`); }
          // CR4: pessoas com tuberculose (CID A15 a A17) em 6 meses. Só o item D (teste de HIV) tem fonte no PEC.
          try {
            const ini6 = UTIL.mesesAntes(ref, 6);
            const tb = new Set();
            for (const cid of CONFIG.cr4.cid10) {
              const l = await COLETORES.lista(us.id, eq.id, 'GERAL_CODIGO', { cid10: [cid], periodo: { startDate: ini6.toISOString(), endDate: ref.toISOString() } });
              l.forEach(p => tb.add(String(p.cidadaoId)));
            }
            const comTb = ist.filter(p => tb.has(String(p.cidadaoId)));
            const hiv = comTb.filter(p => UTIL.dentroDe((INDICADORES._cons(p).saudeMulher || {}).hiv, ref, 6)).length;
            linhas.push(Object.assign(base(eq), { codigo: 'CR4', denominador: tb.size, somaPontos: 25 * hiv, itens: { D: hiv }, parcial: true }));
          } catch (e) { avisos.push(`${eq.nome}: CR4 não coletada (${e.message}).`); }
          progresso && progresso(`${unidade} · ${eq.nome}: ${geral.length} pessoas identificadas em 12 meses.`);
        }
      } catch (e) {
        avisos.push(`${eq.nome}: ${e.message}`);
        progresso && progresso(`${unidade} · ${eq.nome}: ${e.message}`, 'erro');
      }
    }
    if (!(CONFIG.esquemaVacinalC2 || []).length) avisos.push('C2 item E (vacinas): esquema vacinal ainda não configurado; o item conta como não cumprido.');
    // Vínculo oficial eSB/eMulti → eSF/eAP (divisor de B1 e B4; base para a M1).
    for (const e of equipes) {
      if (!['ESB', 'EMULTI'].includes(String(e.tipo).toUpperCase())) continue;
      try { e.vinculadas = await COLETORES.equipesVinculadas(e.id); }
      catch (err) { avisos.push(`${e.nome}: equipes vinculadas não lidas (${err.message}).`); }
    }
    // Carga horária da eSB pela agenda dos dentistas (regra: 40 h de eSB por eSF).
    if (equipes.some(e => String(e.tipo).toUpperCase() === 'ESB')) {
      try {
        const h = await COLETORES.horasSaudeBucal();
        equipes.forEach(e => { if (String(e.tipo).toUpperCase() === 'ESB' && h[e.ine] !== undefined) e.horas = h[e.ine]; });
      } catch (err) { avisos.push(`Horas das eSB não lidas na agenda (${err.message}).`); }
    }
    return { linhas, avisos, observacoes, equipes: equipes.map(e => ({ nome: e.nome, ine: e.ine, tipo: e.tipo, vinculadas: e.vinculadas, horas: e.horas })) };
  }
};
