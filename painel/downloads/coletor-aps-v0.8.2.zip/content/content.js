// Ponte entre o painel lateral e a página do PEC.
(function () {
  const progresso = (texto, classe) => { try { chrome.runtime.sendMessage({ tipo: 'progresso', texto, classe }); } catch (_) {} };

  const acoes = {
    async ping() {
      let logado = false, acesso = null, acessoId = null;
      try {
        const s = await COLETORES.sessao();
        logado = !!(s && s.profissional);
        acesso = s && s.acesso && s.acesso.unidadeSaude ? s.acesso.unidadeSaude.nome : null;
        acessoId = s && s.acesso ? s.acesso.id : null;
      } catch (_) { /* sem sessão */ }
      return { pronto: document.readyState === 'complete', logado, acesso, acessoId, caminho: location.pathname };
    },

    // Volta ao acesso que o usuário usava antes da coleta.
    async restaurarAcesso({ acessoId }) {
      if (!acessoId) return {};
      const q = QUERIES.selecionarAcesso;
      await PEC.gql(q.op, q.query, { input: { id: acessoId } });
      return { ok: true };
    },

    async municipal({ comp }) {
      const avisos = [];
      let atendimentos = [], absenteismo = [];
      try { atendimentos = await COLETORES.atendimentos(comp, progresso); } catch (e) { avisos.push('Atendimentos: ' + e.message); progresso('Atendimentos: ' + e.message, 'erro'); }
      try { absenteismo = await COLETORES.absenteismo(comp, progresso); } catch (e) { avisos.push('Absenteísmo: ' + e.message); progresso('Absenteísmo: ' + e.message, 'erro'); }
      return { atendimentos, absenteismo, avisos };
    },

    // Atividades coletivas do município (B4, M1 e M2). Pode levar alguns minutos.
    async coletivas({ comp }) { return COLETORES.atividadesColetivas(comp, progresso); },

    // Abre o relatório clássico de atendimento odontológico (saúde bucal).
    async abrirRelatorioOdonto() {
      setTimeout(() => location.assign(CLASSICO.ROTA_ODONTO), 300);
      return { recarregando: true };
    },

    async odontologico({ comp, unidade, equipes }) { return CLASSICO.odontologico(comp, unidade, equipes, progresso);
    },

    async trocarAcesso({ unidade }) { return COLETORES.trocarAcesso(unidade, progresso); },

    async unidade({ comp, unidade, opcoes }) { return COLETORES.porUnidade(comp, unidade, progresso, opcoes || {}); },

    // Abre o relatório clássico de atendimento individual (recarrega a página para usar o acesso atual).
    async abrirRelatorioClassico() {
      setTimeout(() => location.assign(CLASSICO.ROTA_ATENDIMENTO), 300);
      return { recarregando: true };
    },

    // eMulti (M1 e M2). Os resumos (com sal) só servem para contar pessoas no painel; não são salvos.
    async emultiMunicipal({ comp, sal }) {
      const equipes = await COLETORES.equipesEmulti();
      const compartilhado = await COLETORES.compartilhadoEmulti(comp);
      const atendQuad = await COLETORES.atendimentosEmultiQuad(comp);
      const col = await COLETORES.coletivasEmultiQuad(comp, sal, equipes.map(e => e.ine), progresso);
      return { equipes, compartilhado, atendQuad, coletivasQuad: col };
    },
    async emultiUnidade({ comp, sal, equipes }) { return COLETORES.pessoasEmultiUnidade(comp, sal, equipes); },

    async tuberculose({ comp, unidade, equipe }) { return CLASSICO.tuberculose(comp, unidade, equipe, progresso); },

    async lotacoes() { return CLASSICO.lotacoes(); },

    async escutaInicial({ comp, unidade, equipes }) { return CLASSICO.escutaInicial(comp, unidade, equipes, progresso); }
  };

  chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
    const fn = msg && acoes[msg.acao];
    if (!fn) return false;
    Promise.resolve(fn(msg)).then(r => responder(r || {}), e => responder({ erro: e.message || String(e) }));
    return true; // resposta assíncrona
  });
})();
