// Acesso às interfaces do PEC usando a sessão já aberta no navegador.
// Não guarda nem envia credenciais: usa o cookie de sessão e o token XSRF que a própria página usa.
var PEC = {
  xsrf() {
    const m = document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : null;
  },

  _headers() {
    const h = { 'Content-Type': 'application/json' };
    const t = PEC.xsrf();
    if (t) h['X-XSRF-TOKEN'] = t;
    return h;
  },

  async gql(operationName, query, variables, tentativas = 2) {
    for (let i = 0; i < tentativas; i++) {
      const r = await fetch('/api/graphql', {
        method: 'POST', credentials: 'include', headers: PEC._headers(),
        body: JSON.stringify([{ operationName, variables, query }])
      });
      if (r.status === 401 || r.status === 403) throw new Error('Sessão do PEC expirada ou sem permissão (HTTP ' + r.status + '). Faça login novamente.');
      if (!r.ok) { if (i + 1 < tentativas) { await UTIL.dormir(1500); continue; } throw new Error(`${operationName}: HTTP ${r.status}`); }
      let j = await r.json();
      if (Array.isArray(j)) j = j[0];
      if (j.errors && j.errors.length) throw new Error(`${operationName}: ${j.errors.map(e => e.message).join('; ')}`);
      return j.data;
    }
  },

  async gerencial(caminho, corpo) {
    const r = await fetch('/api/gerenciais/' + caminho, {
      method: 'POST', credentials: 'include', headers: PEC._headers(), body: JSON.stringify(corpo)
    });
    if (r.status === 401 || r.status === 403) throw new Error('Sessão do PEC expirada ou sem permissão (HTTP ' + r.status + ').');
    if (!r.ok) throw new Error(`gerencial ${caminho}: HTTP ${r.status}`);
    return r.json();
  },

  // Percorre todas as páginas de uma consulta paginada.
  // montarVars(page, size) -> variables ; extrair(data) -> { content, pageInfo }
  async paginar(operationName, query, montarVars, extrair, aoProgredir, tamanho) {
    const size = tamanho || CONFIG.tamanhoPagina;
    let page = 0, total = null, todos = [];
    while (true) {
      const data = await PEC.gql(operationName, query, montarVars(page, size));
      const { content, pageInfo } = extrair(data);
      todos = todos.concat(content || []);
      total = pageInfo ? pageInfo.totalPages : 1;
      if (aoProgredir) aoProgredir(page + 1, total, pageInfo && pageInfo.totalElements);
      if (!pageInfo || pageInfo.last || page + 1 >= total) break;
      page++;
    }
    return todos;
  }
};
