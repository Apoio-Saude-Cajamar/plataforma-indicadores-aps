// Roda DENTRO do quadro dos relatórios clássicos do PEC (/esus/...), no contexto da página,
// onde estão os componentes ExtJS. Recebe pedidos da extensão por postMessage e responde ao quadro pai.
// Não lê dados de pacientes: só seleciona filtros, exporta e lê CSVs agregados da fila de relatórios.
(function () {
  if (window.__coletorClassico) return;
  window.__coletorClassico = true;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toUpperCase();
  const doc = document;

  const cmp = peid => {
    const inp = doc.querySelector(`[peid="${peid}"] input`);
    return inp && window.Ext ? window.Ext.getCmp(inp.id) : null;
  };
  const clicar = el => {
    const r = el.getBoundingClientRect();
    ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(t =>
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window, clientX: r.x + 4, clientY: r.y + 4 })));
  };
  async function iniciarStore(peid) {
    let c = cmp(peid);
    if (c && !c.store) {
      const trig = [...doc.querySelector(`[peid="${peid}"]`).querySelectorAll('.x-form-trigger')].find(t => !t.classList.contains('x-combo-clear-trigger'));
      if (trig) { clicar(trig); await sleep(2000); if (c.collapse) c.collapse(); }
      c = cmp(peid);
    }
    if (!c || !c.store) throw new Error('Campo ' + peid + ' indisponível');
    return c;
  }
  async function carregar(c, q) {
    await new Promise(res => { c.store.load({ params: { start: 0, limit: 100, query: q || '' }, callback: () => res() }); setTimeout(res, 6000); });
    return c.store.getRange();
  }
  const botao = rotulo => [...doc.querySelectorAll('button')].find(b => b.textContent.trim().startsWith(rotulo));
  const icones = () => [...doc.querySelectorAll('div')].filter(e => /ic_baixar/.test(e.style.backgroundImage || ''));

  // DD/MM/AAAA
  const fmt = d => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
  async function definirPeriodo(inicio, fim) {
    const inputs = [...doc.querySelectorAll('[peid="RelatorioFichaSeletor.periodo"] input')];
    if (inputs.length < 2) return;
    const [a, b] = [inicio, fim].map(s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); });
    if (inputs[0].value === fmt(a) && inputs[1].value === fmt(b)) return;
    [[inputs[0], a], [inputs[1], b]].forEach(([inp, d]) => {
      const c = window.Ext.getCmp(inp.id);
      if (c) { c.setValue(d); c.fireEvent('select', c, d); c.fireEvent('change', c, d); }
    });
    await sleep(800);
  }

  // Clique "de verdade" no elemento visível (os botões GWT ignoram eventos disparados no contêiner).
  function clicarCentro(el) {
    el.scrollIntoView({ block: 'center' });
    const r = el.getBoundingClientRect();
    const alvo = doc.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2) || el;
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.x + r.width / 2, clientY: r.y + r.height / 2, button: 0 };
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => alvo.dispatchEvent(t.startsWith('pointer') ? new PointerEvent(t, o) : new MouseEvent(t, o)));
  }

  // Filtro personalizado: um campo e um ou mais valores (ex.: "Problemas / Condições avaliadas - Outros CID10",
  // valores ["A15", "A150", ...]). Cada valor é procurado pelo código no início do texto.
  async function filtroPersonalizado(campo, valores) {
    const cf = await iniciarStore('FiltrosPersonalizados.ComboCampoFiltro');
    const rc = await carregar(cf, '');
    const ic = rc.findIndex(r => norm(r.get(cf.displayField)) === norm(campo));
    if (ic < 0) throw new Error(`Filtro "${campo}" não existe neste relatório`);
    cf.onSelect(rc[ic], ic);
    await sleep(900);
    let cv = null;
    for (let i = 0; i < 6 && !cv; i++) { clicarCentro(doc.querySelector('[peid="FiltrosPersonalizados.BotaoAdicionar"]')); await sleep(1200); cv = cmp('FiltroPersonalizado.' + campo); }
    if (!cv) throw new Error(`Não consegui abrir o filtro "${campo}"`);
    cv = await iniciarStore('FiltroPersonalizado.' + campo);
    const faltam = [];
    for (const v of [].concat(valores)) {
      const rv = await carregar(cv, v);
      const iv = rv.findIndex(r => { const t = norm(r.get(cv.displayField)); return t === norm(v) || t.startsWith(norm(v) + ' -'); });
      if (iv < 0) { faltam.push(v); continue; }
      cv.onSelect(rv[iv], iv);
      await sleep(500);
    }
    if (faltam.length === [].concat(valores).length) throw new Error(`Nenhum valor encontrado no filtro "${campo}"`);
  }

  const acoes = {
    async pronto() {
      return { pronto: !!(window.Ext && cmp('RelatorioFichaSeletor.idDimEquipe') && botao('Exportar CSV')) };
    },

    async equipes() {
      const c = await iniciarStore('RelatorioFichaSeletor.idDimEquipe');
      return (await carregar(c, '')).map(r => String(r.get(c.displayField)));
    },

    // Seleciona equipe (pelo INE) e categoria profissional, ajusta o período e clica em Exportar CSV.
    // Quadro de lotação da unidade do acesso atual: profissional, CBO e equipe (lista "Profissional" do relatório).
    // O CNS que o PEC mostra antes do nome é descartado aqui; só saem nome, CBO, INE e nome da equipe.
    async lotacoes() {
      const c = await iniciarStore('RelatorioFichaSeletor.idDimCbo');
      await new Promise(res => { c.store.load({ params: { start: 0, limit: 2000, query: '' }, callback: () => res() }); setTimeout(res, 10000); });
      return c.store.getRange().map(r => ({
        nome: String(r.get('text') || '').replace(/^\s*\d{6,}\s*-\s*/, '').trim(),
        cbo: String(r.get('cbo') || '').trim(),
        ine: /^\d+$/.test(String(r.get('ine') || '')) ? String(r.get('ine')) : null,
        equipe: String(r.get('nomeIne') || '').trim()
      }));
    },

    // Dentistas lotados numa equipe, pelo CBO, sem nomes: { permitidos: n, proibidos: [código interno da lotação] }.
    async dentistasEquipe({ ine, cbosNomes }) {
      const c = await iniciarStore('RelatorioFichaSeletor.idDimCbo');
      await new Promise(res => { c.store.load({ params: { start: 0, limit: 1000, query: '' }, callback: () => res() }); setTimeout(res, 8000); });
      const ok = (cbosNomes || []).map(norm);
      const out = { permitidos: 0, proibidos: [], cbosProibidos: [] };
      c.store.getRange().forEach(r => {
        if (String(r.get('ine')) !== ine) return;
        const cbo = norm(r.get('cbo')).replace(/\s*-\s*/g, ' - ');
        if (!/DENTISTA/.test(cbo)) return;
        if (ok.some(o => o.replace(/\s*-\s*/g, ' - ') === cbo)) out.permitidos++;
        else { out.proibidos.push(String(r.get('code'))); out.cbosProibidos.push(String(r.get('cbo'))); }
      });
      return out;
    },

    async exportar({ ine, categoria, inicio, fim, filtro, profissional }) {
      const ce = await iniciarStore('RelatorioFichaSeletor.idDimEquipe');
      const re = await carregar(ce, '');
      const ie = re.findIndex(r => String(r.get(ce.displayField)).startsWith(ine));
      if (ie < 0) throw new Error(`Equipe ${ine} não encontrada no relatório`);
      ce.onSelect(re[ie], ie);
      await sleep(800);

      if (profissional !== undefined && profissional !== null) {
        // Um profissional (índice na lista "Profissional"); a categoria fica vazia, como pede a tela.
        const cc = cmp('RelatorioFichaSeletor.grupoCboDescricao');
        if (cc && cc.getValue && cc.getValue()) { cc.clearValue(); await sleep(400); }
        const cp = await iniciarStore('RelatorioFichaSeletor.idDimCbo');
        await new Promise(res => { cp.store.load({ params: { start: 0, limit: 1000, query: '' }, callback: () => res() }); setTimeout(res, 8000); });
        const rp = cp.store.getRange();
        const ip = rp.findIndex(r => String(r.get('code')) === String(profissional) && String(r.get('ine')) === ine);
        if (ip < 0) throw new Error('Profissional não encontrado na equipe');
        cp.onSelect(rp[ip], ip);
        await sleep(800);
      } else if (categoria) {
        const cc = await iniciarStore('RelatorioFichaSeletor.grupoCboDescricao');
        cc.doQuery(categoria, true);
        for (let i = 0; i < 25; i++) { await sleep(300); if (cc.store.getCount()) break; }
        const rc = cc.store.getRange();
        const ic = rc.findIndex(r => norm(r.get(cc.displayField)) === norm(categoria));
        if (ic < 0) throw new Error(`Categoria "${categoria}" não encontrada (opções: ${rc.map(r => r.get(cc.displayField)).join(', ')})`);
        cc.onSelect(rc[ic], ic);
        await sleep(800);
      } else {
        // Sem categoria: todas as categorias profissionais (limpa o campo se estiver preenchido).
        const cc = cmp('RelatorioFichaSeletor.grupoCboDescricao');
        if (cc && cc.getValue && cc.getValue()) { cc.clearValue(); cc.fireEvent && cc.fireEvent('change', cc, ''); await sleep(500); }
      }

      if (inicio && fim) await definirPeriodo(inicio, fim);
      if (filtro) await filtroPersonalizado(filtro.campo, filtro.valores || filtro.valor);

      const b = botao('Exportar CSV');
      if (!b) throw new Error('Botão Exportar CSV não encontrado');
      clicar(b);
      for (let i = 0; i < 20; i++) { await sleep(500); if (/Exportando/.test(b.textContent)) return { ok: true }; }
      throw new Error('A exportação não iniciou');
    },

    // Lista a fila "Relatórios em processamento/processados (7 dias)".
    async fila() {
      return icones().map((el, indice) => {
        let p = el;
        for (let k = 0; k < 6 && p; k++) { p = p.parentElement; if (/\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}/.test(p.innerText || '')) break; }
        const t = (p && p.innerText || '').replace(/\s+/g, ' ').trim();
        const m = t.match(/(\d{2})\/(\d{2})\/(\d{4}) (\d{2}):(\d{2})/);
        return { indice, data: m ? new Date(+m[3], +m[2] - 1, +m[1], +m[4], +m[5]).getTime() : null, pronto: /Pronto/i.test(t), texto: t.slice(0, 60) };
      });
    },

    // Obtém o arquivo de um item da fila SEM baixá-lo no computador e devolve o texto do CSV.
    async baixar({ indice }) {
      const el = icones()[indice];
      if (!el) throw new Error('Item da fila não encontrado');
      let url = null;
      const proto = HTMLIFrameElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto, 'src');
      const abrir = window.open;
      Object.defineProperty(proto, 'src', { configurable: true, get() { return desc.get.call(this); },
        set(v) { if (/\/esus\/(download|writer)/.test(v)) { url = v; return; } desc.set.call(this, v); } });
      window.open = function (u) { if (/\/esus\/(download|writer)/.test(String(u))) { url = String(u); return null; } return abrir.apply(this, arguments); };
      try {
        clicar(el);
        for (let i = 0; i < 40 && !url; i++) await sleep(250);
      } finally {
        Object.defineProperty(proto, 'src', desc);
        window.open = abrir;
      }
      if (!url) throw new Error('O PEC não liberou o arquivo');
      const resp = await fetch(url, { credentials: 'include' });
      const ct = resp.headers.get('content-type') || '';
      const buf = await resp.arrayBuffer();
      if (!/csv|text/.test(ct)) return { tipo: ct, texto: null };
      return { tipo: ct, texto: new TextDecoder('iso-8859-1').decode(buf) };
    }
  };

  window.addEventListener('message', async e => {
    const m = e.data;
    if (!m || m.coletorAPS !== 'req' || e.source !== window.parent) return;
    const responder = obj => window.parent.postMessage(Object.assign({ coletorAPS: 'resp', id: m.id }, obj), location.origin);
    try {
      const fn = acoes[m.acao];
      if (!fn) throw new Error('Ação desconhecida: ' + m.acao);
      responder({ ok: true, dados: await fn(m.args || {}) });
    } catch (err) {
      responder({ ok: false, erro: err.message || String(err) });
    }
  });
})();
