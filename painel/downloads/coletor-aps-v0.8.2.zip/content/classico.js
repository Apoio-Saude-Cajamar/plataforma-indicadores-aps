// Orquestra os relatórios clássicos (ExtJS) a partir da página principal do PEC.
// Conversa com content/classico-main.js, que roda dentro do quadro do relatório.
var CLASSICO = {
  ROTA_ATENDIMENTO: '/relatorios/producao/atendimento-individual',
  _seq: 0,

  quadro() { return document.querySelector('iframe[title="e-sus"]') || document.querySelector('iframe'); },

  chamar(acao, args, limite = 60000) {
    return new Promise((resolve, reject) => {
      const fr = CLASSICO.quadro();
      if (!fr || !fr.contentWindow) return reject(new Error('Quadro do relatório não encontrado'));
      const id = `c${++CLASSICO._seq}-${Date.now()}`;
      const t = setTimeout(() => { window.removeEventListener('message', h); reject(new Error('Tempo esgotado: ' + acao)); }, limite);
      const h = e => {
        const m = e.data;
        if (!m || m.coletorAPS !== 'resp' || m.id !== id) return;
        clearTimeout(t); window.removeEventListener('message', h);
        m.ok ? resolve(m.dados) : reject(new Error(m.erro));
      };
      window.addEventListener('message', h);
      fr.contentWindow.postMessage({ coletorAPS: 'req', id, acao, args }, location.origin);
    });
  },

  async aguardarQuadro(limiteMs = 90000) {
    const ini = Date.now();
    while (Date.now() - ini < limiteMs) {
      try { const r = await CLASSICO.chamar('pronto', {}, 3000); if (r && r.pronto) return true; } catch (_) { /* carregando */ }
      await UTIL.dormir(1000);
    }
    throw new Error('O relatório de atendimento individual não carregou a tempo.');
  },

  async recarregarQuadro() {
    const fr = CLASSICO.quadro();
    fr.contentWindow.location.reload();
    await UTIL.dormir(2500);
    await CLASSICO.aguardarQuadro();
  },

  // Lê um CSV de relatório de produção: cabeçalho (unidade e filtros) e seções "Descrição;Quantidade".
  lerCSV(texto) {
    const L = texto.split(/\r?\n/);
    const filtros = {};
    const fi = L.findIndex(l => l.trim() === 'FILTROS');
    if (fi >= 0) for (let i = fi + 1; i < L.length && L[i].trim(); i++) { const [k, ...v] = L[i].split(';'); filtros[k.trim()] = v.join(';').trim(); }
    const linhaUn = L.find(l => /^UNIDADE DE SA.DE /i.test(l)) || '';
    const unidade = linhaUn.replace(/^UNIDADE DE SA.DE /i, '').trim();
    const secoes = {};
    for (let i = 0; i < L.length; i++) {
      if (L[i] && !L[i].includes(';') && L[i + 1] && L[i + 1].startsWith('Descri')) {
        const m = {};
        let j = i + 2;
        for (; j < L.length && L[j].trim(); j++) { const c = L[j].split(';'); m[c[0].trim()] = Number(c[1]) || 0; }
        secoes[L[i].trim()] = m;
        i = j;
      }
    }
    return { unidade, filtros, secoes };
  },

  // Escuta inicial por equipe e categoria (médico e enfermeiro), para o denominador da C1.
  // equipes: [{ ine, nome }]. Devolve linhas agregadas por equipe e categoria.
  async escutaInicial(comp, unidade, equipes, progresso) {
    const avisos = [];
    const c = UTIL.competencia(comp);
    const periodoEsperado = `${c.inicio.split('-').reverse().join('/')} a ${c.fim.split('-').reverse().join('/')}`;
    await CLASSICO.aguardarQuadro();
    const disponiveis = await CLASSICO.chamar('equipes');
    const alvos = [];
    for (const eq of equipes) {
      if (!disponiveis.some(r => r.startsWith(eq.ine))) { avisos.push(`Escuta inicial: equipe ${eq.nome} (${eq.ine}) não aparece no relatório.`); continue; }
      for (const categoria of CONFIG.c1.categoriasEscuta) alvos.push({ ine: eq.ine, equipe: eq.nome, categoria });
    }
    if (!alvos.length) return { linhas: [], avisos };

    const inicio = Date.now() - 60000;
    for (const [i, a] of alvos.entries()) {
      progresso && progresso(`${unidade} · escuta inicial ${i + 1}/${alvos.length}: ${a.equipe} (${a.categoria.toLowerCase()})…`);
      await CLASSICO.chamar('exportar', { ine: a.ine, categoria: a.categoria, inicio: c.inicio, fim: c.fim }, 90000);
      await CLASSICO.recarregarQuadro();
    }

    // Aguarda os arquivos ficarem prontos e lê cada um, identificando pelo cabeçalho do CSV.
    const chave = (ine, cat) => `${ine}|${UTIL.normalizar(cat)}`;
    const faltam = new Map(alvos.map(a => [chave(a.ine, a.categoria), a]));
    const linhas = [];
    const lidos = new Set();
    const limite = Date.now() + 6 * 60000;
    while (faltam.size && Date.now() < limite) {
      const fila = await CLASSICO.chamar('fila');
      let pendentes = 0;
      for (const it of fila) {
        if (!it.data || it.data < inicio) continue;
        if (!it.pronto) { pendentes++; continue; }
        const id = `${it.data}|${it.indice}`;
        if (lidos.has(id)) continue;
        lidos.add(id);
        const arq = await CLASSICO.chamar('baixar', { indice: it.indice }, 60000);
        if (!arq.texto) continue;
        const csv = CLASSICO.lerCSV(arq.texto);
        const ine = (csv.filtros['Equipe'] || '').split(' - ')[0].trim();
        const cat = csv.filtros['Categoria profissional'] || '';
        const k = chave(ine, cat);
        const alvo = faltam.get(k);
        if (!alvo) continue; // arquivo de outra equipe/unidade ou gerado por outra pessoa
        if (UTIL.normalizar(csv.unidade) !== UTIL.normalizar(unidade)) continue;
        const tipos = csv.secoes['Tipo de atendimento'] || {};
        const escuta = Object.entries(tipos).filter(([t]) => UTIL.normalizar(t).startsWith('escuta inicial')).reduce((s, [, n]) => s + n, 0);
        linhas.push({ unidade, ine, equipe: alvo.equipe, categoria: alvo.categoria, escuta, tipos,
          periodoOk: (csv.filtros['Período'] || '') === periodoEsperado });
        if ((csv.filtros['Período'] || '') !== periodoEsperado) avisos.push(`Escuta inicial: o relatório de ${alvo.equipe} saiu com período "${csv.filtros['Período']}", diferente de ${periodoEsperado}.`);
        faltam.delete(k);
      }
      if (!faltam.size) break;
      if (!pendentes && fila.every(it => !it.data || it.data < inicio || lidos.has(`${it.data}|${it.indice}`))) {
        await UTIL.dormir(4000);
      }
      await CLASSICO.recarregarQuadro();
    }
    for (const a of faltam.values()) avisos.push(`Escuta inicial: relatório de ${a.equipe} (${a.categoria.toLowerCase()}) não ficou pronto a tempo.`);
    progresso && progresso(`${unidade}: escuta inicial lida em ${linhas.length} de ${alvos.length} relatórios.`);
    return { linhas, avisos };
  },

  // Quadro de lotação da unidade (composição das equipes).
  async lotacoes() {
    await CLASSICO.aguardarQuadro();
    return { lotacoes: await CLASSICO.chamar('lotacoes', {}, 40000) };
  },

  // Seção "Exames solicitados e avaliados" (duas colunas: avaliada e solicitada) e "Outros exames (SIGTAP)".
  _exames(texto) {
    const L = texto.split(/\r?\n/);
    const out = [];
    for (const titulo of [/^Exames solicitados e avaliados/, /^Outros exames solicitados e avaliados/]) {
      const i = L.findIndex(l => titulo.test(l.trim()));
      if (i < 0) continue;
      for (let j = i + 2; j < L.length && L[j].trim(); j++) {
        const c = L[j].split(';');
        out.push({ descricao: c[0].trim(), avaliada: Number(c[1]) || 0, solicitada: Number(c[2]) || 0 });
      }
    }
    return out;
  },

  // CR4: relatório de atendimento individual da eCR em 6 meses, só atendimentos com "Tuberculose" avaliada.
  async tuberculose(comp, unidade, equipe, progresso) {
    const c = UTIL.competencia(comp);
    const ini = UTIL.mesesAntes(c.referencia, 6);
    const inicio = `${ini.getFullYear()}-${String(ini.getMonth() + 1).padStart(2, '0')}-01`;
    await CLASSICO.aguardarQuadro();
    const t0 = Date.now() - 60000;
    progresso && progresso(`${unidade} · CR4: relatório de atendimentos com tuberculose (6 meses)…`);
    await CLASSICO.chamar('exportar', { ine: equipe.ine, categoria: null, inicio, fim: c.fim, filtro: CONFIG.cr4.filtroRelatorio }, 90000);
    await CLASSICO.recarregarQuadro();
    const periodoEsperado = `${inicio.split('-').reverse().join('/')} a ${c.fim.split('-').reverse().join('/')}`;
    const lidos = new Set();
    const limite = Date.now() + (CONFIG.cr4.esperaSemArquivoMin || 3) * 60000;
    while (Date.now() < limite) {
      for (const it of await CLASSICO.chamar('fila')) {
        if (!it.data || it.data < t0 || !it.pronto) continue;
        const id = `${it.data}|${it.indice}`;
        if (lidos.has(id)) continue;
        lidos.add(id);
        const arq = await CLASSICO.chamar('baixar', { indice: it.indice }, 60000);
        if (!arq.texto || !/atendimento individual/i.test(arq.texto.slice(0, 400))) continue;
        const csv = CLASSICO.lerCSV(arq.texto);
        if ((csv.filtros['Equipe'] || '').split(' - ')[0].trim() !== equipe.ine) continue;
        if (/^nenhum/i.test(csv.filtros['Filtros personalizados'] || 'Nenhum') || (csv.filtros['Período'] || '') !== periodoEsperado) continue;
        const resumo = csv.secoes['Resumo de produção'] || {};
        const registros = (resumo['Registros identificados'] || 0) + (resumo['Registros não identificados'] || 0);
        const ex = CLASSICO._exames(arq.texto);
        const soma = (re, campo) => ex.filter(e => re.test(UTIL.normalizar(e.descricao))).reduce((s, e) => s + (campo ? e[campo] : e.avaliada + e.solicitada), 0);
        return { registros, periodo: csv.filtros['Período'] || '',
          bacilo: soma(/bacilosc|baar|micobact|molecular.*tuberc|tuberculose/),
          raioX: soma(/radiografia.*torax|rx.*torax/, 'avaliada') + soma(/radiografia.*torax|rx.*torax/, 'solicitada'),
          hiv: soma(/hiv/) };
      }
      await UTIL.dormir(4000);
      await CLASSICO.recarregarQuadro();
    }
    // Sem arquivo: o PEC não gera o relatório quando nenhum atendimento tem os CIDs de tuberculose.
    return { registros: 0, bacilo: 0, raioX: 0, hiv: 0, periodo: periodoEsperado, semArquivo: true };
  },

  // Saúde bucal (B1, B2, B3, B5 e B6): relatório de atendimento odontológico por equipe eSB,
  // só com os cirurgiões-dentistas da APS (CBO 223293 e 223208).
  // O relatório filtra pela categoria "Cirurgião dentista", que também inclui dentistas de outros CBOs
  // (ex.: saúde coletiva). Quando a equipe tem algum, o relatório desse profissional é exportado à parte
  // e descontado. Os nomes dos profissionais não são lidos nem guardados.
  ROTA_ODONTO: '/relatorios/producao/atendimento-odontologico',

  _descontar(a, b) {
    const out = { registros: a.registros - b.registros, primeiraConsulta: a.primeiraConsulta - b.primeiraConsulta,
      tratamentoConcluido: a.tratamentoConcluido - b.tratamentoConcluido, procedimentos: Object.assign({}, a.procedimentos), semCodigo: Object.assign({}, a.semCodigo) };
    for (const [k, v] of Object.entries(b.procedimentos || {})) out.procedimentos[k] = Math.max(0, (out.procedimentos[k] || 0) - v);
    for (const [k, v] of Object.entries(b.semCodigo || {})) { out.semCodigo[k] = Math.max(0, (out.semCodigo[k] || 0) - v); if (!out.semCodigo[k]) delete out.semCodigo[k]; }
    ['registros', 'primeiraConsulta', 'tratamentoConcluido'].forEach(k => { out[k] = Math.max(0, out[k]); });
    return out;
  },

  async odontologico(comp, unidade, equipes, progresso) {
    const avisos = [];
    const sb = CONFIG.saudeBucal;
    const c = UTIL.competencia(comp);
    const periodoEsperado = `${c.inicio.split('-').reverse().join('/')} a ${c.fim.split('-').reverse().join('/')}`;
    await CLASSICO.aguardarQuadro();
    const disponiveis = await CLASSICO.chamar('equipes');
    const alvos = [];
    for (const eq of equipes) {
      if (!disponiveis.some(r => r.startsWith(eq.ine))) { avisos.push(`Saúde bucal: equipe ${eq.nome} (${eq.ine}) não aparece no relatório odontológico.`); continue; }
      const d = await CLASSICO.chamar('dentistasEquipe', { ine: eq.ine, cbosNomes: sb.cbosNomes }, 30000);
      if (!d.permitidos) { avisos.push(`Saúde bucal: ${eq.nome} não tem cirurgião-dentista da APS (CBO 223293 ou 223208) lotado; fica sem B1 a B6.`); continue; }
      if (d.proibidos.length) avisos.push(`Saúde bucal: ${eq.nome} tem ${d.proibidos.length} dentista(s) de outro CBO (${[...new Set(d.cbosProibidos)].join('; ')}); a produção dele(s) foi descontada.`);
      alvos.push(Object.assign({}, eq, { proibidos: d.proibidos }));
    }
    if (!alvos.length) return { linhas: [], avisos };

    const inicio = Date.now() - 60000;
    let n = 0;
    const total = alvos.reduce((s, a) => s + 1 + a.proibidos.length, 0);
    for (const a of alvos) {
      progresso && progresso(`${unidade} · saúde bucal ${++n}/${total}: ${a.nome} (cirurgiões-dentistas)…`);
      await CLASSICO.chamar('exportar', { ine: a.ine, categoria: sb.categoriaRelatorio, inicio: c.inicio, fim: c.fim }, 90000);
      await CLASSICO.recarregarQuadro();
      for (const codigo of a.proibidos) {
        progresso && progresso(`${unidade} · saúde bucal ${++n}/${total}: ${a.nome} (dentista de outro CBO, para descontar)…`);
        await CLASSICO.chamar('exportar', { ine: a.ine, profissional: codigo, inicio: c.inicio, fim: c.fim }, 90000);
        await CLASSICO.recarregarQuadro();
      }
    }
    // Lê os arquivos: o da categoria (um por equipe) e os de cada profissional a descontar.
    const principal = new Map(), descontos = new Map();
    const lidos = new Set();
    const limite = Date.now() + 6 * 60000;
    let fimEspera = null, semDados = 0;
    while (Date.now() < limite) {
      const fila = await CLASSICO.chamar('fila');
      // "Dados insuficientes" = relatório sem nenhum registro (o dentista a descontar não produziu): conta como zero.
      semDados = fila.filter(it => it.data && it.data >= inicio && /insuficientes/i.test(it.texto || '')).length;
      for (const it of fila) {
        if (!it.data || it.data < inicio || !it.pronto) continue;
        const id = `${it.data}|${it.indice}`;
        if (lidos.has(id)) continue;
        lidos.add(id);
        const arq = await CLASSICO.chamar('baixar', { indice: it.indice }, 60000);
        if (!arq.texto || !/atendimento odontol/i.test(arq.texto.slice(0, 400))) continue;
        const csv = CLASSICO.lerCSV(arq.texto);
        const ine = (csv.filtros['Equipe'] || '').split(' - ')[0].trim();
        const alvo = alvos.find(x => x.ine === ine);
        if (!alvo || UTIL.normalizar(csv.unidade) !== UTIL.normalizar(unidade)) continue;
        if ((csv.filtros['Período'] || '') !== periodoEsperado) { avisos.push(`Saúde bucal: o relatório de ${alvo.nome} saiu com período "${csv.filtros['Período']}", diferente de ${periodoEsperado}.`); continue; }
        const od = INDICADORES.lerOdontologico(csv, sb.nomes);
        const prof = csv.filtros['Profissional'] || 'Todos';
        if (!/^todos$/i.test(prof.trim())) {
          (descontos.get(ine) || descontos.set(ine, []).get(ine)).push(od);
        } else if (/dentist/i.test(Object.values(csv.filtros).join(' '))) {
          principal.set(ine, od);
        }
      }
      const faltaPrincipal = alvos.some(a => !principal.has(a.ine));
      const lidosDesc = alvos.reduce((t, a) => t + (descontos.get(a.ine) || []).length, 0);
      const faltaDesconto = lidosDesc + semDados < alvos.reduce((t, a) => t + a.proibidos.length, 0);
      if (!faltaPrincipal && !faltaDesconto) break;
      // Sem registro, o PEC não gera o arquivo: depois de 2 minutos com os principais lidos, desconto ausente = zero.
      if (!faltaPrincipal) { fimEspera = fimEspera || Date.now() + 120000; if (Date.now() > fimEspera) break; }
      await UTIL.dormir(4000);
      await CLASSICO.recarregarQuadro();
    }
    const linhas = [];
    for (const a of alvos) {
      let od = principal.get(a.ine);
      if (!od) { avisos.push(`Saúde bucal: relatório de ${a.nome} não ficou pronto a tempo.`); continue; }
      for (const d of descontos.get(a.ine) || []) od = CLASSICO._descontar(od, d);
      if (Object.keys(od.semCodigo).length) avisos.push(`Saúde bucal (${a.nome}): procedimentos sem código conhecido, fora das notas: ${Object.keys(od.semCodigo).join('; ')}.`);
      linhas.push(Object.assign({ unidade, ine: a.ine, equipe: a.nome, periodoOk: true, cbos: sb.cbos, descontados: (descontos.get(a.ine) || []).length }, od));
    }
    progresso && progresso(`${unidade}: saúde bucal lida em ${linhas.length} de ${alvos.length} equipes.`);
    return { linhas, avisos };
  }
};
