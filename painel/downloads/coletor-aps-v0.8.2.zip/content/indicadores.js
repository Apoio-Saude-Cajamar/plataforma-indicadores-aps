// Regras de pontuação por pessoa, conforme as Notas Metodológicas (C2, C3, C4, C5, C6) e CR1.
// Cada função recebe um registro da lista de Condições de saúde, a data de referência
// (último dia da competência) e opções { tipoEquipe, esquema, agora }, e devolve
// { pontos, itens: {A: bool, ...}, excluir }.
// As consultas pedem só datas, contagens e marcadores: nenhum nome, CPF, CNS, endereço ou telefone.

var INDICADORES = {

  _cons(reg) { return (reg.cidadao && reg.cidadao.cidadaoConsolidado) || {}; },
  _sim(v) { return String(v || '').toUpperCase() === 'SIM'; },
  _eAP(op) { return String((op && op.tipoEquipe) || '').toUpperCase() === 'EAP'; },

  // ---------- C3 / S20 - Cuidado na gestação e puerpério ----------
  // Pontuação: 10*A + 9*(B..K), máximo 100.
  // Nota C3: gestação sem desfecho é encerrada aos 294 dias; o puerpério vai até 42 dias depois
  // (até 336 dias). Fora disso a pessoa não é mais gestante nem puérpera e sai do denominador.
  // Em eAP, as práticas E e J (visitas) recebem pontuação integral.
  c3(reg, ref, op = {}) {
    const pn = INDICADORES._cons(reg).preNatalPuerperio || {};
    const at = pn.atendimentosPreNatalPuerperio || {};
    const med = pn.medicoesPreNatal || {};
    const vis = pn.visitasDomiciliares || {};
    const ex = pn.examesRealizadosPreNatal || {};
    const sim = INDICADORES._sim;
    const eap = INDICADORES._eAP(op);
    const dum = UTIL.data(pn.ultimaDum);
    const dtpa = (pn.vacinasAplicadas || []).some(v => {
      const sig = UTIL.normalizar(v.dimensaoImunobiologico && v.dimensaoImunobiologico.sigla);
      const nome = UTIL.normalizar(v.dimensaoImunobiologico && v.dimensaoImunobiologico.nome);
      const eDtpa = sig === 'dtpa' || nome.includes('dtpa') || (nome.includes('acelular') && nome.includes('difteria'));
      const d = UTIL.data(v.dataRegistroVacinaAplicada);
      return eDtpa && d && dum && UTIL.dias(dum, d) >= 140; // a partir da 20ª semana
    });
    const itens = {
      A: (at.consultasPrimeirasDozeSemanas || 0) >= 1,
      B: (at.consultasPreNatalGestacao || 0) >= 7,
      C: (med.qtdMedicoesPressaoArterial || 0) >= 7,
      D: (med.qtdMedicoesPesoAltura || 0) >= 7,
      E: eap || (vis.visitasDomiciliaresPreNatal || 0) >= 3,
      F: dtpa,
      G: sim(ex.sifilisPrimeiroTrimestre) && sim(ex.hivPrimeiroTrimestre) && sim(ex.hepatiteBPrimeiroTrimestre) && sim(ex.hepatiteCPrimeiroTrimestre),
      H: sim(ex.sifilisTerceiroTrimestre) && sim(ex.hivTerceiroTrimestre),
      I: (at.consultasPuerperio || 0) >= 1,
      J: eap || (vis.visitasDomiciliaresPuerperio || 0) >= 1,
      K: (at.consultasOdontologicasGestacao || 0) >= 1
    };
    let pontos = itens.A ? 10 : 0;
    for (const k of 'BCDEFGHIJK') if (itens[k]) pontos += 9;
    // A idade gestacional vem calculada no dia da coleta; ajusta para a data de referência.
    const agora = op.agora || new Date();
    const ig = pn.idadeGestacionalCronologicaEmDias;
    const igRef = typeof ig === 'number' ? ig - Math.max(0, Math.floor(UTIL.dias(ref, agora))) : null;
    const excluir = igRef !== null && igRef > 336;
    const extras = {
      S3_7consultas: itens.B,
      S4_sifilis1e3: sim(ex.sifilisPrimeiroTrimestre) && sim(ex.sifilisTerceiroTrimestre),
      altoRisco: !!pn.altoRiscoGestacional,
      puerperaPor294: igRef !== null && igRef > 294 && igRef <= 336
    };
    return { pontos, itens, excluir, extras };
  },

  // ---------- CR2 - Cuidado na gestação (eCR) ----------
  // A 30: 3 ou mais consultas (o PEC não separa por trimestre: exige ao menos 1 nas primeiras 12 semanas);
  // B 20: sífilis, HIV, hepatite B e C na gestação; C 20: dTpa a partir da 20ª semana;
  // D 20: 3 ou mais aferições de pressão; E 10: atendimento odontológico. Puérperas (após 294 dias) saem.
  cr2(reg, ref, op = {}) {
    const pn = INDICADORES._cons(reg).preNatalPuerperio || {};
    const at = pn.atendimentosPreNatalPuerperio || {};
    const ex = pn.examesRealizadosPreNatal || {};
    const sim = INDICADORES._sim;
    const base = INDICADORES.c3(reg, ref, op);
    const agora = op.agora || new Date();
    const ig = pn.idadeGestacionalCronologicaEmDias;
    const igRef = typeof ig === 'number' ? ig - Math.max(0, Math.floor(UTIL.dias(ref, agora))) : null;
    const tri = k => sim(ex[k + 'PrimeiroTrimestre']) || sim(ex[k + 'TerceiroTrimestre']);
    const itens = {
      A: (at.consultasPreNatalGestacao || 0) >= 3 && (at.consultasPrimeirasDozeSemanas || 0) >= 1,
      B: tri('sifilis') && tri('hiv') && sim(ex.hepatiteBPrimeiroTrimestre) && sim(ex.hepatiteCPrimeiroTrimestre),
      C: base.itens.F,
      D: ((pn.medicoesPreNatal || {}).qtdMedicoesPressaoArterial || 0) >= 3,
      E: (at.consultasOdontologicasGestacao || 0) >= 1
    };
    const pesos = { A: 30, B: 20, C: 20, D: 20, E: 10 };
    const pontos = Object.keys(itens).reduce((s, k) => s + (itens[k] ? pesos[k] : 0), 0);
    return { pontos, itens, excluir: igRef !== null && igRef > 294 };
  },

  // ---------- CR3 - Rastreio de IST (eCR) ----------
  // 25 pontos por teste (sífilis, HIV, hepatite B, hepatite C) com data nos últimos 12 meses.
  // As datas vêm do consolidado "saúde da mulher", que o PEC preenche para qualquer sexo.
  cr3(reg, ref) {
    const sm = INDICADORES._cons(reg).saudeMulher || {};
    const itens = { A: UTIL.dentroDe(sm.sifilis, ref, 12), B: UTIL.dentroDe(sm.hiv, ref, 12), C: UTIL.dentroDe(sm.hepatiteB, ref, 12), D: UTIL.dentroDe(sm.hepatiteC, ref, 12) };
    return { pontos: 25 * Object.values(itens).filter(Boolean).length, itens };
  },

  // ---------- C6 - Cuidado da pessoa idosa (25 pontos cada) ----------
  // Em eAP, a prática C (visitas) não condiciona a pontuação.
  c6(reg, ref, op = {}) {
    const pi = INDICADORES._cons(reg).pessoaIdosa || {};
    const visitas = (pi.visitaDomiciliar && pi.visitaDomiciliar.dataUltimasVisitasDomiciliares) || [];
    const itens = {
      A: UTIL.dentroDe(reg.dataUltimoAtendimentoMedico, ref, 12) || UTIL.dentroDe(reg.dataUltimoAtendimentoEnfermagem, ref, 12),
      B: UTIL.dentroDe(reg.dataUltimaMedicaoPesoAltura, ref, 12),
      C: INDICADORES._eAP(op) || INDICADORES._duasVisitas30d(visitas, ref, 12),
      D: (pi.vacinasAplicadas || []).some(v => INDICADORES._eInfluenza(v) && UTIL.dentroDe(v.dataRegistroVacinaAplicada, ref, 12))
    };
    const pontos = Object.values(itens).filter(Boolean).length * 25;
    return { pontos, itens, excluir: false };
  },

  // ---------- C4 - Cuidado da pessoa com diabetes ----------
  // 20*(A+D) + 15*(B+C+E+F). Em eAP, D (visitas) não pontua como exigência.
  c4(reg, ref, op = {}) {
    const db = INDICADORES._cons(reg).diabetes || {};
    const visitas = (db.visitaDomiciliar && db.visitaDomiciliar.dataUltimasVisitasDomiciliares) || [];
    const ex = db.exames || {};
    const itens = {
      A: UTIL.dentroDe(db.dataUltimaConsulta, ref, 6),
      B: UTIL.dentroDe(reg.dataUltimaMedicaoPressaoArterial, ref, 6),
      C: UTIL.dentroDe(reg.dataUltimaMedicaoPesoAltura, ref, 12),
      D: INDICADORES._eAP(op) || INDICADORES._duasVisitas30d(visitas, ref, 12),
      // hemoglobina glicada solicitada ou avaliada nos últimos 12 meses
      E: UTIL.dentroDe(ex.dataUltimaSolicitacaoHemoglobinaGlicada, ref, 12) ||
         UTIL.dentroDe(ex.hemoglobinaGlicada && ex.hemoglobinaGlicada.dataRealizacao, ref, 12),
      F: UTIL.dentroDe(ex.dataAvaliacaoPes, ref, 12)
    };
    const pontos = (itens.A ? 20 : 0) + (itens.D ? 20 : 0) + ['B', 'C', 'E', 'F'].filter(k => itens[k]).length * 15;
    return { pontos, itens, excluir: false };
  },

  // ---------- C5 - Cuidado da pessoa com hipertensão (25 cada) ----------
  c5(reg, ref, op = {}) {
    const ha = INDICADORES._cons(reg).hipertensao || {};
    const visitas = (ha.visitaDomiciliar && ha.visitaDomiciliar.dataUltimasVisitasDomiciliares) || [];
    const itens = {
      A: UTIL.dentroDe(ha.dataUltimaConsulta, ref, 6),
      B: UTIL.dentroDe(reg.dataUltimaMedicaoPressaoArterial, ref, 6),
      C: UTIL.dentroDe(reg.dataUltimaMedicaoPesoAltura, ref, 12),
      D: INDICADORES._eAP(op) || INDICADORES._duasVisitas30d(visitas, ref, 12)
    };
    const pontos = Object.values(itens).filter(Boolean).length * 25;
    return { pontos, itens, excluir: false };
  },

  // ---------- C2 - Desenvolvimento infantil (20 cada), crianças com até 2 anos ----------
  c2(reg, ref, op = {}) {
    const di = INDICADORES._cons(reg).desenvolvimentoInfantil || {};
    const dn = UTIL.data(reg.dataNascimentoCidadao);
    if (!dn || UTIL.dias(dn, ref) >= 730 || dn > ref) return { pontos: 0, itens: {}, excluir: true };
    const cons = di.consultas || {};
    const vis = di.visitasDomiciliares || {};
    const p1 = UTIL.data(cons.dataPrimeiraConsulta);
    const v1 = UTIL.data(vis.dataPrimeiraVisita);
    const v2 = UTIL.data(vis.dataSegundaVisita);
    const itens = {
      A: !!(p1 && UTIL.dias(dn, p1) <= 30),
      B: (cons.qtdConsultas || 0) >= 9,
      C: (di.qtdMedicoesPesoAltura || 0) >= 9,
      D: INDICADORES._eAP(op) || !!(v1 && v2 && UTIL.dias(dn, v1) <= 30 && UTIL.dias(dn, v2) <= 180),
      E: INDICADORES._esquemaCompleto(di.vacinasAplicadas || [], op.esquema, dn, ref)
    };
    const pontos = Object.values(itens).filter(Boolean).length * 20;
    return { pontos, itens, excluir: false };
  },

  // ---------- CR1 - Mais acesso à eCR ----------
  cr1(reg, ref) {
    const ok = UTIL.dentroDe(reg.dataUltimoAtendimentoMedico, ref, 6) ||
               UTIL.dentroDe(reg.dataUltimoAtendimentoEnfermagem, ref, 6) ||
               UTIL.dentroDe(reg.dataUltimoAtendimentoOdontologico, ref, 6);
    return { pontos: ok ? 1 : 0, itens: { A: ok }, excluir: false };
  },

  // ---------- auxiliares ----------
  _duasVisitas30d(datas, ref, meses) {
    const ds = (datas || []).map(UTIL.data).filter(d => d && d <= ref && d >= UTIL.mesesAntes(ref, meses)).sort((a, b) => a - b);
    for (let i = 1; i < ds.length; i++) if (UTIL.dias(ds[i - 1], ds[i]) >= 30) return true;
    return false;
  },

  _eInfluenza(v) {
    const s = UTIL.normalizar(((v.dimensaoImunobiologico && v.dimensaoImunobiologico.nome) || '') + ' ' + ((v.dimensaoImunobiologico && v.dimensaoImunobiologico.sigla) || ''));
    return s.includes('influenza') || /\binf\b|\bflu\b/.test(s);
  },

  // Verifica o esquema da Nota C2 usando o grupo do imunobiológico informado pelo PEC.
  // regra: { grupo, doses, dosesValidas?, excluirDoses?, intervaloDias?, idadeMinimaMeses? }
  _esquemaCompleto(vacinas, esquema, dn, ref) {
    if (!esquema || !esquema.length) return false;
    return esquema.every(regra => {
      const datas = vacinas.filter(v => {
        const grupos = (v.dimensaoImunobiologico && v.dimensaoImunobiologico.grupo) || [];
        if (!grupos.some(g => String(g).toUpperCase().startsWith(regra.grupo))) return false;
        const dose = String((v.dimensaoDoseImunobiologico && v.dimensaoDoseImunobiologico.sigla) || '').toUpperCase();
        if (regra.dosesValidas && !regra.dosesValidas.includes(dose)) return false;
        if (regra.excluirDoses && regra.excluirDoses.includes(dose)) return false;
        const d = UTIL.data(v.dataRegistroVacinaAplicada);
        if (!d || (ref && d > ref)) return false;
        if (regra.idadeMinimaMeses && dn) {
          const limite = new Date(dn); limite.setMonth(limite.getMonth() + regra.idadeMinimaMeses);
          if (d < limite) return false;
        }
        return true;
      }).map(v => UTIL.data(v.dataRegistroVacinaAplicada)).sort((a, b) => a - b);
      // conta doses respeitando o intervalo mínimo entre elas
      let n = 0, ultima = null;
      for (const d of datas) {
        if (!ultima || !regra.intervaloDias || UTIL.dias(ultima, d) >= regra.intervaloDias) { n++; ultima = d; }
      }
      return n >= regra.doses;
    });
  },

  // ---------- Atividades coletivas (B4, M1 e M2) ----------
  // Recebe os detalhes das atividades do mês e devolve totais por equipe (INE).
  // Cada atividade conta para todas as equipes dos profissionais envolvidos (responsável e demais).
  // Os identificadores dos participantes servem só para não contar a mesma pessoa duas vezes
  // e são descartados aqui: a saída tem apenas números.
  agregarAtividades(atividades, tiposPorIne, regraB4) {
    const r = regraB4 || { pratica: 'ESCOVACAO_DENTAL_SUPERVISIONADA', idadeMin: 6, idadeMax: 12 };
    const porIne = new Map();
    const idade = (dn, ref) => {
      const d = UTIL.data(dn), a = UTIL.data(ref);
      if (!d || !a) return null;
      let y = a.getFullYear() - d.getFullYear();
      if (a.getMonth() < d.getMonth() || (a.getMonth() === d.getMonth() && a.getDate() < d.getDate())) y--;
      return y;
    };
    for (const at of atividades) {
      const lots = [at.lotacaoResponsavel].concat(at.lotacoesEnvolvidas || []).filter(l => l && l.equipe && l.equipe.ine);
      const profissionais = [at.lotacaoResponsavel].concat(at.lotacoesEnvolvidas || []).filter(Boolean).length;
      const participantes = (at.participantes || []).map(p => p.cidadao || p.cidadaoParticipante || {});
      const escovacao = (at.praticasSaude || []).includes(r.pratica);
      const ines = [...new Set(lots.map(l => l.equipe.ine))];
      for (const ine of ines) {
        const lot = lots.find(l => l.equipe.ine === ine);
        let o = porIne.get(ine);
        if (!o) {
          o = { ine, equipe: lot.equipe.nome || ine, tipoEquipe: tiposPorIne[ine] || '', unidade: (lot.unidadeSaude && lot.unidadeSaude.nome) || '',
                atividades: 0, compartilhadas: 0, participacoes: 0, _pessoas: new Set(),
                escovacao: { atividades: 0, participacoes: 0, faixa: 0, _faixa: new Set() } };
          porIne.set(ine, o);
        }
        o.atividades++;
        if (profissionais >= 2) o.compartilhadas++;
        o.participacoes += participantes.length;
        participantes.forEach(p => { if (p.id) o._pessoas.add(String(p.id)); });
        // B4: só conta a escovação com cirurgião-dentista da APS (CBO 223293 ou 223208) da própria equipe.
        const cbosOk = r.cbos && r.cbos.length ? r.cbos : null;
        const comDentista = !cbosOk || lots.some(l => l.equipe.ine === ine && l.cbo && cbosOk.includes(String(l.cbo.cbo2002)));
        if (escovacao && !comDentista) o.escovacao.semDentista = (o.escovacao.semDentista || 0) + 1;
        if (escovacao && comDentista) {
          o.escovacao.atividades++;
          o.escovacao.participacoes += participantes.length;
          for (const p of participantes) {
            const y = idade(p.dataNascimento, at.dataAtividade);
            if (y !== null && y >= r.idadeMin && y <= r.idadeMax) { o.escovacao.faixa++; if (p.id) o.escovacao._faixa.add(String(p.id)); }
          }
        }
      }
    }
    return [...porIne.values()].map(o => ({
      ine: o.ine, equipe: o.equipe, tipoEquipe: o.tipoEquipe, unidade: o.unidade,
      atividades: o.atividades, compartilhadas: o.compartilhadas, participacoes: o.participacoes, pessoas: o._pessoas.size,
      escovacao: { atividades: o.escovacao.atividades, participacoes: o.escovacao.participacoes, participacoesFaixa: o.escovacao.faixa, criancasFaixa: o.escovacao._faixa.size, semDentista: o.escovacao.semDentista || 0 }
    }));
  },

  // ---------- Relatório de atendimento odontológico (B1, B2, B3, B5 e B6) ----------
  // csv: resultado de CLASSICO.lerCSV. Devolve contagens por código SIGTAP e os campos de B1 e B2.
  lerOdontologico(csv, nomes) {
    const n = s => UTIL.normalizar(s).replace(/\.$/, '');
    const sec = csv.secoes || {};
    const pega = (secao, rotulo) => Object.entries(sec[secao] || {}).filter(([k]) => n(k) === n(rotulo)).reduce((s, [, v]) => s + v, 0);
    const procedimentos = {}, semCodigo = {};
    for (const [nome, qtd] of Object.entries(sec['Procedimentos'] || {})) {
      const cod = nomes[n(nome)];
      if (cod) procedimentos[cod] = (procedimentos[cod] || 0) + qtd; else if (qtd) semCodigo[nome] = qtd;
    }
    for (const [nome, qtd] of Object.entries(sec['Outros procedimentos (SIGTAP)'] || {})) {
      const m = String(nome).match(/^(\d{10})\b/);
      if (m) procedimentos[m[1]] = (procedimentos[m[1]] || 0) + qtd;
    }
    return {
      registros: pega('Resumo de produção', 'Registros identificados') + pega('Resumo de produção', 'Registros não identificados'),
      primeiraConsulta: pega('Tipo de consulta', 'Primeira consulta odontológica programática'),
      tratamentoConcluido: pega('Conduta / Desfecho', 'Tratamento concluído'),
      procedimentos, semCodigo
    };
  },

  // ---------- C7 - Cuidado da mulher na prevenção do câncer ----------
  // Cada item tem seu próprio denominador (pessoas na faixa do item). Devolve só totais.
  // idsItemC: conjunto (em memória) de quem teve atendimento com código de saúde sexual e reprodutiva.
  c7(pessoas, ref, idsItemC) {
    const cf = CONFIG.c7;
    const out = { A: [0, 0], B: [0, 0], C: [0, 0], D: [0, 0], cPec: 0, excluidos: 0 };
    const idade = dn => { const d = UTIL.data(dn); if (!d) return null; let a = ref.getFullYear() - d.getFullYear(); if (ref.getMonth() < d.getMonth() || (ref.getMonth() === d.getMonth() && ref.getDate() < d.getDate())) a--; return a; };
    const na = (k, i) => i !== null && i >= cf.faixas[k][0] && i <= cf.faixas[k][1];
    const qualquer = (lista, meses) => lista.some(d => UTIL.dentroDe(d, ref, meses));
    for (const p of pessoas) {
      const sexo = String(p.sexoCidadao || '').toUpperCase(), ig = String(p.identidadeGeneroCidadao || '').toUpperCase();
      const elegivel = (sexo === 'FEMININO' && ig !== 'MULHER_TRANS') || (sexo === 'MASCULINO' && ig === 'HOMEM_TRANS');
      const i = idade(p.dataNascimentoCidadao);
      if (!elegivel || i === null) { out.excluidos++; continue; }
      const sm = INDICADORES._cons(p).saudeMulher || {};
      if (na('A', i)) {
        out.A[1]++;
        const av = sm.ultimaAvaliacaoCancerColoUtero || {}, so = sm.ultimaSolicitacaoCancerColoUtero || {};
        const desc = UTIL.normalizar([((av.exameRequisitado || {}).exame || {}).descricao, ((so.exameRequisitado || {}).exame || {}).descricao].join(' '));
        const meses = /hpv|molecular/.test(desc) ? cf.janelaHpvMolecularMeses : cf.janelaColoMeses;
        if (qualquer([av.dataAvaliacao, (av.exameRequisitado || {}).dataResultado, (so.exameRequisitado || {}).dataSolicitacao], meses)) out.A[0]++;
      }
      if (na('B', i)) {
        out.B[1]++;
        if ((sm.vacinasAplicadas || []).some(v => /hpv/.test(UTIL.normalizar(((v.dimensaoImunobiologico || {}).sigla || '') + ' ' + ((v.dimensaoImunobiologico || {}).nome || '')))
          && UTIL.data(v.dataRegistroVacinaAplicada) && UTIL.data(v.dataRegistroVacinaAplicada) <= ref)) out.B[0]++;
      }
      if (na('C', i)) {
        out.C[1]++;
        if (idsItemC && idsItemC.has(String(p.cidadaoId))) out.C[0]++;
        if (UTIL.dentroDe(sm.ultimaConsulta && sm.ultimaConsulta.iniciadoEm, ref, cf.janelaConsultaMeses)) out.cPec++;
      }
      if (na('D', i)) {
        out.D[1]++;
        if (qualquer([(sm.ultimaAvaliacaoCancerMama || {}).dataAvaliacao, ((sm.ultimaRealizacaoCancerMama || {}).exameRequisitado || {}).dataRealizacao,
          ((sm.ultimaSolicitacaoCancerMama || {}).exameRequisitado || {}).dataSolicitacao], cf.janelaMamaMeses)) out.D[0]++;
      }
    }
    return out;
  },

  // Nota C7 a partir dos totais dos itens: Σ (cumpridas ÷ faixa) × peso.
  notaC7(itens) {
    const pesos = CONFIG.c7.pesos;
    let nota = 0, completo = true;
    for (const k of Object.keys(pesos)) {
      const [n, d] = itens[k] || [0, 0];
      if (d) nota += (n / d) * pesos[k]; else if (itens[k] === undefined) completo = false;
    }
    return { nota: +nota.toFixed(2), completo };
  },

  // ---------- CVAT - Cadastro e acompanhamento territorial (NT 30/2025) ----------
  // vinculados: { dataNascimentoCidadao, dataUltimaAtualizacaoCidadao, microarea, origem }
  // geral:      { dataNascimentoCidadao, microarea, datas dos últimos atendimentos e visita, cidadao.beneficiarioBolsaFamilia }
  // partes:     { microarea: fração de imóveis com cadastro atualizado } (do acompanhamento do território)
  // Devolve só totais. Fica de fora quem está na microárea "Fora da área".
  _foraDeArea(m) { return /^fa$|fora/i.test(String(m || '').trim()); },
  cvat(vinculados, geral, ref, partes) {
    const cf = CONFIG.cvat;
    const out = { cadastro: { ponderado: 0, mici: 0, miciVencido: 0, origemPec: 0, foraDeArea: 0, semMicroarea: 0, estimativaDomiciliar: 0 },
      acompanhamento: { ponderado: 0, pessoas: 0, umTipo: 0, nenhum: 0, foraDeArea: 0, porPeso: { '1,0': 0, '1,2': 0, '1,3': 0, '2,5': 0 } } };
    const c = out.cadastro;
    for (const p of vinculados) {
      if (INDICADORES._foraDeArea(p.microarea)) { c.foraDeArea++; continue; }
      // MICI = ficha de cadastro individual (origem CDS). Cadastro feito só no PEC não conta.
      if (String(p.origem || '').toUpperCase() !== 'CDS') { c.origemPec++; continue; }
      if (!UTIL.dentroDe(p.dataUltimaAtualizacaoCidadao, ref, cf.mesesCadastro)) { c.miciVencido++; continue; }
      c.mici++;
      const m = String(p.microarea || '').trim();
      const fr = Object.prototype.hasOwnProperty.call(partes || {}, m) ? partes[m] : null;
      if (fr === null) c.semMicroarea++;
      // 0,75 pelo MICI + 0,75 a mais quando o domicílio também está atualizado (estimado pela fração da microárea).
      c.ponderado += 0.75 + 0.75 * (fr || 0);
      c.estimativaDomiciliar += fr || 0;
    }
    const a = out.acompanhamento;
    const idade = dn => { const d = UTIL.data(dn); return d ? (ref - d) / 31557600000 : null; };
    for (const p of geral) {
      if (INDICADORES._foraDeArea(p.microarea)) { a.foraDeArea++; continue; }
      // Contatos em 12 meses: o PEC informa a data do último de cada tipo. Dois tipos diferentes = acompanhada.
      const n = [p.dataUltimoAtendimentoMedico, p.dataUltimoAtendimentoEnfermagem, p.dataUltimoAtendimentoOdontologico, p.dataUltimaVisitaDomiciliar]
        .filter(d => UTIL.dentroDe(d, ref, cf.mesesAcompanhamento)).length;
      if (n === 0) { a.nenhum++; continue; }
      if (n === 1) { a.umTipo++; continue; }
      a.pessoas++;
      const i = idade(p.dataNascimentoCidadao);
      const etario = i !== null && (i < 5 || i >= 60);
      const pbf = !!(p.cidadao && p.cidadao.beneficiarioBolsaFamilia && p.cidadao.beneficiarioBolsaFamilia.isBeneficiario);
      const k = etario && pbf ? '2,5' : pbf ? '1,3' : etario ? '1,2' : '1,0';
      a.porPeso[k]++;
      a.ponderado += Number(k.replace(',', '.'));
    }
    c.ponderado = +c.ponderado.toFixed(2); c.estimativaDomiciliar = +c.estimativaDomiciliar.toFixed(1); a.ponderado = +a.ponderado.toFixed(2);
    return out;
  },

  // Agrega a pontuação de uma lista: devolve totais por item, sem dados pessoais.
  agregar(registros, fn, ref, op) {
    const res = { denominador: 0, somaPontos: 0, itens: {}, extras: {}, excluidos: 0 };
    for (const r of registros) {
      const p = fn(r, ref, op || {});
      if (p.excluir) { res.excluidos++; continue; }
      res.denominador++;
      res.somaPontos += p.pontos;
      for (const [k, v] of Object.entries(p.itens)) res.itens[k] = (res.itens[k] || 0) + (v ? 1 : 0);
      for (const [k, v] of Object.entries(p.extras || {})) res.extras[k] = (res.extras[k] || 0) + (v ? 1 : 0);
    }
    res.resultado = res.denominador ? +(res.somaPontos / res.denominador).toFixed(2) : null;
    return res;
  }
};
