// Nota C7 a partir dos itens agregados: Σ (cumpridas ÷ pessoas da faixa) × peso (A 20, B 30, C 30, D 20).
var INDICADORES_C7 = {
  nota(itens) {
    const pesos = (CONFIG.c7 && CONFIG.c7.pesos) || { A: 20, B: 30, C: 30, D: 20 };
    let nota = 0;
    for (const k of Object.keys(pesos)) { const [n, d] = itens[k] || [0, 0]; if (d) nota += (n / d) * pesos[k]; }
    return { nota: +nota.toFixed(2) };
  }
};

// Cálculo das notas de saúde bucal (B1 a B6) e das partes já disponíveis da eMulti (M1 e M2).
// Entrada: a coleta salva (só totais). Saída: linhas { codigo, unidade, equipe, numerador, denominador, valor }.
var CALCULO = {

  // CVAT (NT 30/2025): índice = ponderado ÷ divisor × 100; faixas >85 / 65 / 45.
  notaCvat(cad, aco) {
    const faixa = (v, f) => v > 85 ? f[0] : v >= 65 ? f[1] : v >= 45 ? f[2] : f[3];
    const iCad = cad.denominador ? 100 * cad.numerador / cad.denominador : 0;
    const iAco = aco.denominador ? 100 * aco.numerador / aco.denominador : 0;
    const eCad = faixa(iCad, [3, 2.25, 1.5, 0.75]), eAco = faixa(iAco, [7, 5.25, 3.5, 1.75]);
    const nota = eCad + eAco;
    return { indiceCadastro: +iCad.toFixed(1), indiceAcompanhamento: +iAco.toFixed(1), escoreCadastro: eCad, escoreAcompanhamento: eAco, nota,
      classificacao: nota > 8.5 ? 'Ótimo' : nota >= 7 ? 'Bom' : nota >= 5 ? 'Suficiente' : 'Regular' };
  },

  // eSF/eAP de referência de cada eSB e a parte da população que cabe a ela.
  // Ordem: (1) correção em CONFIG.saudeBucal.referencia; (2) vínculo oficial lido do PEC ("Equipes vinculadas");
  // (3) sem vínculo: as eSF/eAP da unidade que nenhuma eSB usa. Uma eSF ligada a duas eSB é repartida.
  _referencias(coleta) {
    const eqs = (coleta.cubos && coleta.cubos.equipes) || [];
    const linhas = coleta.linhas || [];
    const tipo = t => String(t || '').toUpperCase();
    const N = UTIL.normalizar;
    const fixa = {};
    Object.entries((CONFIG.saudeBucal && CONFIG.saudeBucal.referencia) || {}).forEach(([k, v]) => { fixa[N(k)] = v.map(N); });
    const vinc = (codigo, ine) => linhas.filter(l => l.codigo === codigo && l.ine === ine).reduce((s, l) => s + (l.valor || 0), 0);
    const territoriais = eqs.filter(e => ['ESF', 'EAP'].includes(tipo(e.tipo)) && e.ine);
    const porChave = chave => territoriais.find(e => N(e.nome) === chave || N(e.ine) === chave);
    const esb = eqs.filter(e => tipo(e.tipo) === 'ESB' && e.ine);
    const alvos = {};
    for (const b of esb) {
      const f = fixa[N(b.nome)] || fixa[N(b.ine)];
      if (f) alvos[b.ine] = { lista: f.map(porChave).filter(Boolean), regra: 'correcao' };
      else if ((b.vinculadas || []).length) alvos[b.ine] = { lista: b.vinculadas.map(i => territoriais.find(e => e.ine === i)).filter(Boolean), regra: 'pec' };
    }
    for (const u of [...new Set(esb.map(b => b.unidade))]) {
      const usadas = new Set(Object.values(alvos).flatMap(a => a.lista.map(e => e.ine)));
      const daUn = territoriais.filter(e => e.unidade === u);
      const sobram = daUn.filter(e => !usadas.has(e.ine));
      for (const b of esb.filter(x => x.unidade === u && !alvos[x.ine])) alvos[b.ine] = { lista: sobram.length ? sobram : daUn, regra: 'unidade' };
    }
    // Parte de cada eSF que cabe a cada eSB: horas da eSB ÷ max(40, horas de todas as eSB dessa eSF).
    // Sem as horas (agenda não lida), reparte igualmente entre as eSB da eSF.
    const ligadas = {};
    for (const b of esb) alvos[b.ine].lista.forEach(e => { (ligadas[e.ine] = ligadas[e.ine] || []).push(b); });
    const fracao = (b, f) => {
      const lst = ligadas[f.ine] || [b];
      if (lst.every(x => typeof x.horas === 'number' && x.horas > 0)) return b.horas / Math.max(40, lst.reduce((s, x) => s + x.horas, 0));
      return 1 / lst.length;
    };
    const ref = {};
    for (const b of esb) {
      const a = alvos[b.ine];
      const soma = cod => a.lista.reduce((s, e) => s + vinc(cod, e.ine) * fracao(b, e), 0);
      ref[b.ine] = { unidade: b.unidade, equipe: b.nome, horas: b.horas, alvos: a.lista.map(e => e.nome), regra: a.regra, vinculados: soma('Q12.2'), vinculados6a12: soma('VINC6A12') };
    }
    return ref;
  },

  // Composição: monta a árvore município → unidade → equipe → profissionais e avalia cada nível.
  // Entrada: cubos.equipes (unidade, nome, ine, tipo, vinculadas, horas) e cubos.lotacoes (unidade, nome, cbo, ine, equipe).
  composicao(coleta) {
    const cf = CONFIG.composicao, N = UTIL.normalizar;
    const eqs = (coleta.cubos && coleta.cubos.equipes) || [], lots = (coleta.cubos && coleta.cubos.lotacoes) || [];
    const nomeIne = new Map(eqs.map(e => [e.ine, e.nome]));
    const prof = l => (cf.guardarNomes ? { nome: l.nome, cbo: l.cbo } : { cbo: l.cbo });
    const alertasGerais = [];
    // Mesmo profissional em mais de uma equipe (pelo nome; homônimos podem aparecer).
    const porNome = new Map();
    lots.filter(l => l.ine && l.nome).forEach(l => { const k = N(l.nome); (porNome.get(k) || porNome.set(k, new Set()).get(k)).add(l.unidade + ' · ' + (nomeIne.get(l.ine) || l.equipe || l.ine)); });
    const emVarias = [...porNome.values()].filter(s => s.size > 1).length;
    if (emVarias) alertasGerais.push(`${emVarias} profissional(is) aparecem em mais de uma equipe (pode ser homônimo ou lotação dupla).`);
    const unidades = [...new Set(eqs.map(e => e.unidade).concat(lots.map(l => l.unidade)))].sort().map(u => {
      const lu = lots.filter(l => l.unidade === u);
      const alertas = [];
      const equipes = eqs.filter(e => e.unidade === u).map(e => {
        const le = lu.filter(l => l.ine === e.ine);
        const al = [];
        const tipo = String(e.tipo || '').toUpperCase();
        if (lu.length) for (const [rotulo, re] of cf.minimo[tipo] || []) if (!le.some(l => re.test(N(l.cbo)))) al.push(`Sem ${rotulo} lotado.`);
        if (tipo === 'ESB' && !(e.vinculadas || []).length) al.push('Sem eSF/eAP vinculada no PEC.');
        if (tipo === 'ESB' && typeof e.horas === 'number' && e.horas < 38 && e.horas !== 20) al.push(`Agenda dos dentistas soma ${String(Math.round(e.horas * 10) / 10).replace('.', ',')} h.`);
        if (tipo === 'EMULTI' && (e.vinculadas || []).length && (e.vinculadas || []).length < 5) al.push(`Só ${(e.vinculadas || []).length} equipe(s) vinculada(s).`);
        return { nome: e.nome, ine: e.ine, tipo, horas: e.horas, vinculadas: (e.vinculadas || []).map(i => nomeIne.get(i) || i), profissionais: le.map(prof), alertas: al };
      });
      const conhecidos = new Set(equipes.map(e => e.ine));
      const fora = lu.filter(l => l.ine && !conhecidos.has(l.ine));
      if (fora.length) alertas.push(`${fora.length} lotação(ões) em equipe que não está ativa nesta unidade (${[...new Set(fora.map(l => l.equipe || l.ine))].slice(0, 4).join('; ')}).`);
      const semEquipe = lu.filter(l => !l.ine);
      const deviam = semEquipe.filter(l => cf.devemTerEquipe.some(re => re.test(N(l.cbo))));
      if (deviam.length) {
        const cont = {}; deviam.forEach(l => { cont[l.cbo] = (cont[l.cbo] || 0) + 1; });
        alertas.push('Sem equipe: ' + Object.entries(cont).map(([k, v]) => `${v} ${k.toLowerCase()}`).join('; ') + '.');
      }
      return { nome: u, equipes, semEquipe: semEquipe.map(prof), foraDaUnidade: fora.map(l => Object.assign(prof(l), { equipe: l.equipe || l.ine })), alertas, lotacoesLidas: lu.length };
    });
    const total = a => unidades.reduce((s, u) => s + a(u), 0);
    return { competencia: coleta.competencia, coletadoEm: coleta.concluidoEm || new Date().toISOString(), versaoExtensao: CONFIG.versao,
      resumo: { unidades: unidades.length, equipes: total(u => u.equipes.length), lotacoes: total(u => u.lotacoesLidas),
        alertas: alertasGerais.length + total(u => u.alertas.length + u.equipes.reduce((s, e) => s + e.alertas.length, 0)) },
      alertas: alertasGerais, unidades };
  },

  // Escovações sem cirurgião-dentista da APS (ex.: só ASB ou TSB): não contam na B4, mas ficam como observação.
  observacoesBucal(coleta) {
    return ((coleta.cubos && coleta.cubos.coletivas) || []).filter(c => c.escovacao && c.escovacao.semDentista)
      .map(c => ({ unidade: c.unidade, equipe: c.equipe, ine: c.ine, tipo: 'escovacao-sem-dentista', valor: c.escovacao.semDentista,
        texto: 'Escovações supervisionadas sem cirurgião-dentista da APS (CBO 223293 ou 223208) entre os profissionais: não contam na B4.' }));
  },

  // Conferência da regra de carga horária: cada eSF precisa de 40 h de eSB
  // (uma eSB de 40 h ou duas de 20 h). Devolve avisos para revisão; o PEC não informa a carga horária.
  conferirSaudeBucal(coleta) {
    const eqs = (coleta.cubos && coleta.cubos.equipes) || [];
    const tipo = t => String(t || '').toUpperCase();
    const ref = CALCULO._referencias(coleta);
    const porEsf = {};
    for (const r of Object.values(ref)) r.alvos.forEach(n => { (porEsf[n] = porEsf[n] || []).push(r); });
    const avisos = [];
    const fh = h => (typeof h === 'number' ? String(Math.round(h * 10) / 10).replace('.', ',') + ' h' : 'horas não lidas');
    for (const [esf, lst] of Object.entries(porEsf)) {
      const desc = lst.map(r => `${r.equipe} (${fh(r.horas)})`).join(' + ');
      if (lst.length > 2) avisos.push(`${esf} está ligada a ${lst.length} eSB: ${desc}. O esperado é 1 de 40 h ou 2 de 20 h.`);
      if (lst.every(r => typeof r.horas === 'number')) {
        const tot = lst.reduce((s, r) => s + r.horas, 0);
        if (tot < 38) avisos.push(`${esf} tem só ${fh(tot)} de eSB na agenda (${desc}); a nota pede 40 h. O divisor de B1 e B4 usa a parte proporcional.`);
        if (tot > 45) avisos.push(`${esf} soma ${fh(tot)} de eSB na agenda (${desc}); acima de 40 h, as eSB repartem a população.`);
      }
    }
    for (const e of eqs.filter(x => tipo(x.tipo) === 'ESF' && !porEsf[x.nome])) avisos.push(`${e.nome} (${e.unidade}) não tem eSB vinculada.`);
    for (const r of Object.values(ref)) if (r.regra === 'unidade') avisos.push(`${r.equipe} não tem equipe vinculada no PEC; usei as eSF/eAP livres da unidade.`);
    return avisos;
  },

  saudeBucal(coleta) {
    const out = [];
    const sb = CONFIG.saudeBucal;
    const ref = CALCULO._referencias(coleta);
    const soma = (proc, lista) => lista.reduce((s, c) => s + (proc[c] || 0), 0);
    for (const o of (coleta.cubos && coleta.cubos.odonto) || []) {
      const r = ref[o.ine];
      const base = { unidade: o.unidade, equipe: o.equipe, ine: o.ine };
      const p = o.procedimentos || {};
      if (r) out.push(Object.assign({}, base, { codigo: 'B1', numerador: o.primeiraConsulta, denominador: Math.round(r.vinculados), regraReferencia: r.regra, referencia: r.alvos.join(', ') }));
      out.push(Object.assign({}, base, { codigo: 'B2', numerador: o.tratamentoConcluido, denominador: o.primeiraConsulta }));
      out.push(Object.assign({}, base, { codigo: 'B3', numerador: soma(p, sb.b3.numerador), denominador: soma(p, sb.b3.denominador) }));
      out.push(Object.assign({}, base, { codigo: 'B5', numerador: soma(p, sb.b5.numerador), denominador: soma(p, sb.b5.denominador) }));
      out.push(Object.assign({}, base, { codigo: 'B6', numerador: soma(p, sb.b6.numerador), denominador: soma(p, sb.b6.denominador) }));
    }
    // B4: crianças de 6 a 12 anos nas escovações supervisionadas da eSB ÷ crianças de 6 a 12 anos vinculadas à eSF de referência.
    for (const c of (coleta.cubos && coleta.cubos.coletivas) || []) {
      if (String(c.tipoEquipe).toUpperCase() !== 'ESB') continue;
      const r = ref[c.ine];
      out.push({ codigo: 'B4', unidade: (r && r.unidade) || c.unidade, equipe: (r && r.equipe) || c.equipe, ine: c.ine,
        numerador: c.escovacao ? c.escovacao.criancasFaixa : 0, denominador: r ? Math.round(r.vinculados6a12) : 0 });
    }
    return out;
  },

  // eMulti: o que já sai da coleta.
  // M2 (parte coletiva): atividades coletivas com 2 ou mais profissionais ÷ atividades coletivas da eMulti.
  // M1: só o numerador por enquanto (atendimentos individuais + participações em atividades coletivas);
  //     o divisor (pessoas diferentes atendidas) ainda não tem fonte agregada no PEC.
  // eMulti.
  // M2 = (atendimentos individuais compartilhados + atividades coletivas com 2 ou mais profissionais)
  //      ÷ (atendimentos individuais + atividades coletivas), no mês, por equipe eMulti.
  emulti(coleta) {
    const out = [];
    const ines = (CONFIG.emulti && CONFIG.emulti.ines) || {};
    const N = UTIL.normalizar;
    const ehEmulti = c => String(c.tipoEquipe).toUpperCase() === 'EMULTI' || !!ines[c.ine];
    const indiv = new Map(((coleta.cubos && coleta.cubos.compartilhado) || []).map(c => [N(c.equipe), c]));
    const temIndiv = indiv.size > 0;
    const vistos = new Set();
    for (const c of ((coleta.cubos && coleta.cubos.coletivas) || []).filter(ehEmulti)) {
      const i = indiv.get(N(c.equipe)) || { total: 0, compartilhados: 0 };
      vistos.add(N(c.equipe));
      out.push({ codigo: 'M2', unidade: c.unidade, equipe: c.equipe, ine: c.ine,
        numerador: c.compartilhadas + i.compartilhados, denominador: c.atividades + i.total, parcial: !temIndiv,
        individuais: { total: i.total, compartilhados: i.compartilhados }, coletivas: { total: c.atividades, compartilhadas: c.compartilhadas } });
    }
    // eMulti sem atividade coletiva no mês, mas com atendimento individual.
    for (const [k, i] of indiv) {
      if (vistos.has(k) || !Object.values(ines).some(n => N(n) === k)) continue;
      const eq = ((coleta.cubos && coleta.cubos.equipes) || []).find(e => N(e.nome) === k) || {};
      out.push({ codigo: 'M2', unidade: eq.unidade || '', equipe: i.equipe, ine: eq.ine, numerador: i.compartilhados, denominador: i.total,
        individuais: { total: i.total, compartilhados: i.compartilhados }, coletivas: { total: 0, compartilhadas: 0 } });
    }
    return out;
  },

  // CR4: completa os itens A (4 ou mais consultas), B (baciloscopia, teste molecular ou cultura) e C (raio X de tórax)
  // com os totais do relatório filtrado por tuberculose. O relatório não diz de quem é cada registro,
  // então cada item é estimado (teto) e vem com faixa mínima e máxima. O item D é exato (data do teste de HIV).
  cr4(linha, tb) {
    const n = linha.denominador || 0;
    const d = ((linha.itens || {}).D) || 0;
    const est = { A: Math.min(n, Math.floor((tb.registros || 0) / 4)), B: Math.min(n, tb.bacilo || 0), C: Math.min(n, tb.raioX || 0) };
    const min = { A: (tb.registros || 0) >= 4 ? 1 : 0, B: tb.bacilo ? 1 : 0, C: tb.raioX ? 1 : 0 };
    const pts = o => 25 * (o.A + o.B + o.C + d);
    return { itens: Object.assign({}, est, { D: d }), somaPontos: pts(est), parcial: false, aproximado: true,
      faixa: n ? [+(pts(min) / n).toFixed(1), +(pts(est) / n).toFixed(1)] : null,
      detalhe: { registros: tb.registros, bacilo: tb.bacilo, raioX: tb.raioX, hivNoRelatorio: tb.hiv, periodo: tb.periodo, semArquivo: !!tb.semArquivo } };
  },

  // M1 (quadrimestre até o mês da coleta) = (atendimentos individuais + participações em atividades coletivas)
  //      ÷ pessoas diferentes atendidas. As pessoas vêm da lista de atendimentos do PEC (sem as fichas CDS)
  //      e dos participantes das atividades; os atendimentos só em ficha CDS entram como estimativa, com faixa.
  //      Recebe os resumos (com sal) na memória e devolve só contagens.
  m1(dados, coleta) {
    const out = [];
    const N = UTIL.normalizar;
    const eqs = (coleta.cubos && coleta.cubos.equipes) || [];
    const atendNome = new Map(Object.entries(dados.atendQuad || {}).map(([k, v]) => [N(k), v]));
    for (const e of dados.equipes || []) {
      const ind = (dados.ind || {})[e.ine] || { atendimentos: 0, resumos: new Set() };
      const col = ((dados.coletivasQuad || {}).porIne || {})[e.ine] || { atividades: 0, participacoes: 0, resumos: [] };
      const atendTotal = atendNome.get(N(e.nome)) || 0;
      const numerador = atendTotal + col.participacoes;
      if (!numerador) continue;
      const pessoasInd = ind.resumos.size;
      const uniao = new Set([...ind.resumos, ...col.resumos]);
      const extra = Math.max(0, atendTotal - ind.atendimentos);
      const razao = ind.atendimentos ? pessoasInd / ind.atendimentos : 1;
      const min = uniao.size, max = uniao.size + extra, est = Math.round(uniao.size + extra * razao);
      const un = (eqs.find(x => x.ine === e.ine) || {}).unidade || '';
      out.push({ codigo: 'M1', unidade: un, equipe: e.nome, ine: e.ine, numerador, denominador: est || 0,
        quadrimestre: dados.quad, aproximado: extra > 0,
        faixa: est ? [+(numerador / Math.max(max, 1)).toFixed(2), +(numerador / Math.max(min, 1)).toFixed(2)] : null,
        detalhe: { atendimentosIndividuais: atendTotal, atendimentosNaLista: ind.atendimentos, soEmFichaCds: extra,
          participacoesColetivas: col.participacoes, pessoasNaLista: pessoasInd, pessoasDiferentes: uniao.size,
          pessoasMin: min, pessoasMax: max } });
    }
    return out;
  }
};
