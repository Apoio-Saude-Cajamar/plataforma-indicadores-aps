// Criptografia do cofre: senha-mestra -> PBKDF2-SHA256 (310 mil iterações) -> AES-256-GCM.
// Funciona no navegador e no Node (globalThis.crypto).
const ITER = 310000;
const enc = new TextEncoder(), dec = new TextDecoder();
const b64 = b => btoa(String.fromCharCode(...new Uint8Array(b)));
const des64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));

async function chave(senha, sal, iter) {
  const base = await crypto.subtle.importKey('raw', enc.encode(senha), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: sal, iterations: iter, hash: 'SHA-256' }, base,
    { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
export async function cifrar(obj, senha) {
  const sal = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const k = await chave(senha, sal, ITER);
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, k, enc.encode(JSON.stringify(obj)));
  return { formato: 'cofre-painelaps', v: 1, iter: ITER, sal: b64(sal), iv: b64(iv), dados: b64(ct) };
}
export async function decifrar(pacote, senha) {
  if (!pacote || pacote.formato !== 'cofre-painelaps' || pacote.v !== 1) throw new Error('Arquivo não é de um cofre do Painel APS.');
  try {
    const k = await chave(senha, des64(pacote.sal), pacote.iter);
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: des64(pacote.iv) }, k, des64(pacote.dados));
    return JSON.parse(dec.decode(pt));
  } catch { throw new Error('Senha-mestra incorreta ou arquivo danificado.'); }
}
export function gerarValor(bytes = 32) {
  return Array.from(crypto.getRandomValues(new Uint8Array(bytes)), b => b.toString(16).padStart(2, '0')).join('');
}
