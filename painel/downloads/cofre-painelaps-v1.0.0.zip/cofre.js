import { cifrar, decifrar, gerarValor } from './cripto.js';
const $ = id => document.getElementById(id);
const PADRAO = ['TOKEN_COLETA', 'TOKEN_BACKUP', 'TOKEN_ADMIN', 'APOIO_CHAVE'];
let senhaMestra = null, itens = null, existe = false;

const aviso = (t, tipo) => { $('aviso').textContent = t || ''; $('aviso').className = 'aviso ' + (tipo || ''); };
const ler = () => new Promise(r => chrome.storage.local.get('cofre', d => r(d.cofre || null)));
const gravar = async () => { await chrome.storage.local.set({ cofre: await cifrar({ itens }, senhaMestra) }); };

async function iniciar() {
  existe = !!(await ler());
  $('txt-senha').textContent = existe ? 'Digite a senha-mestra para abrir o cofre.' : 'Primeiro uso: crie uma senha-mestra para o cofre.';
  $('l-conf').hidden = existe;
}
$('entrar').onclick = async () => {
  const s = $('senha').value;
  if (s.length < 12) return aviso('Use pelo menos 12 caracteres.', 'erro');
  try {
    if (existe) {
      itens = (await decifrar(await ler(), s)).itens;
    } else {
      if (s !== $('conf').value) return aviso('As senhas não são iguais.', 'erro');
      itens = PADRAO.map(nome => ({ nome, valor: '' }));
      senhaMestra = s; await gravar();
    }
    senhaMestra = s; $('senha').value = $('conf').value = '';
    $('tela-senha').hidden = true; $('tela-cofre').hidden = false; aviso(''); desenhar();
  } catch (e) { aviso(e.message, 'erro'); }
};
$('senha').addEventListener('keydown', e => { if (e.key === 'Enter') $('entrar').click(); });

function desenhar() {
  const box = $('lista'); box.textContent = '';
  itens.forEach((it, i) => {
    const d = document.createElement('div'); d.className = 'item';
    const t = document.createElement('b'); t.textContent = it.nome; d.append(t);
    const l = document.createElement('div'); l.className = 'linha';
    const inp = document.createElement('input'); inp.type = 'password'; inp.value = it.valor; inp.placeholder = '(vazio)';
    inp.onchange = async () => { it.valor = inp.value.trim(); await gravar(); aviso('Salvo.', 'ok'); };
    const bt = (txt, fn) => { const b = document.createElement('button'); b.textContent = txt; b.onclick = fn; return b; };
    l.append(inp,
      bt('Ver', e => { inp.type = inp.type === 'password' ? 'text' : 'password'; e.target.textContent = inp.type === 'password' ? 'Ver' : 'Ocultar'; }),
      bt('Gerar', async () => { if (it.valor && !confirm('Já existe um valor. Substituir por um novo?')) return; it.valor = gerarValor(); await gravar(); desenhar(); aviso('Valor gerado e salvo. Copie para o Cloudflare.', 'ok'); }),
      bt('Copiar', async () => { if (!it.valor) return aviso('Sem valor.', 'erro'); await navigator.clipboard.writeText(it.valor); aviso('Copiado.', 'ok'); }));
    d.append(l);
    if (!PADRAO.includes(it.nome)) d.append(bt('Remover', async () => { if (!confirm('Remover ' + it.nome + '?')) return; itens.splice(i, 1); await gravar(); desenhar(); }));
    box.append(d);
  });
}
$('add').onclick = async () => {
  const n = $('novo-nome').value.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_');
  if (!n) return; if (itens.some(x => x.nome === n)) return aviso('Esse nome já existe.', 'erro');
  itens.push({ nome: n, valor: '' }); $('novo-nome').value = ''; await gravar(); desenhar();
};
$('exportar').onclick = async () => {
  const pac = await cifrar({ itens }, senhaMestra);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(pac)], { type: 'application/json' }));
  a.download = 'cofre-painelaps-' + new Date().toISOString().slice(0, 10) + '.json'; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000); aviso('Arquivo exportado (criptografado).', 'ok');
};
$('importar').onclick = () => $('arq').click();
$('arq').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  const s = prompt('Senha-mestra do arquivo importado:'); if (!s) return;
  try {
    const dados = await decifrar(JSON.parse(await f.text()), s);
    if (!Array.isArray(dados.itens)) throw new Error('Arquivo sem itens.');
    let n = 0;
    for (const novo of dados.itens) {
      if (!novo || typeof novo.nome !== 'string' || typeof novo.valor !== 'string') continue;
      const ex = itens.find(x => x.nome === novo.nome);
      if (ex) { if (novo.valor && ex.valor !== novo.valor) { if (!ex.valor || confirm('Substituir ' + novo.nome + ' pelo valor do arquivo?')) { ex.valor = novo.valor; n++; } } }
      else { itens.push({ nome: novo.nome, valor: novo.valor }); n++; }
    }
    await gravar(); desenhar(); aviso(n + ' item(ns) importado(s).', 'ok');
  } catch (er) { aviso(er.message, 'erro'); }
};
$('travar').onclick = () => { senhaMestra = null; itens = null; $('tela-cofre').hidden = true; $('tela-senha').hidden = false; iniciar(); aviso('Cofre travado.', 'ok'); };
iniciar();
