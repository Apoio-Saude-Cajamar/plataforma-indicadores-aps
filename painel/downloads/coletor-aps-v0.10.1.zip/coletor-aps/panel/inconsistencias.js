// Relatório de inconsistências da coleta: lê o resumo gravado pelo painel e monta a página para imprimir ou salvar em PDF.
// Só contagens e totais por unidade; nenhum nome de paciente ou de profissional.
(async () => {
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const NOME = { erro: 'Erro', atencao: 'Atenção', info: 'Informação' };
  const { relInconsistencias: r } = await chrome.storage.local.get('relInconsistencias');
  const doc = document.getElementById('doc');
  document.getElementById('imprimir').onclick = () => window.print();
  if (!r) { doc.innerHTML = '<p>Não há relatório para mostrar. Volte ao painel da extensão e clique em “Inconsistências (PDF)”.</p>'; return; }
  const dt = s => (s ? new Date(s).toLocaleString('pt-BR') : '—');
  const [a, m] = r.competencia.split('-');
  const secoes = new Map();
  for (const x of r.achados) { if (!secoes.has(x.unidade)) secoes.set(x.unidade, []); secoes.get(x.unidade).push(x); }
  let h = `<h1>Inconsistências da coleta · ${esc(m + '/' + a)}</h1>
    <p class="meta">Coletor APS v${esc(r.versao)} · coleta iniciada em ${esc(dt(r.iniciadoEm))}${r.concluidoEm ? ' e concluída em ' + esc(dt(r.concluidoEm)) : ''} · relatório gerado em ${esc(dt(r.geradoEm))}</p>
    <div class="cards">
      <div class="card"><small>Unidades na coleta</small><b>${r.unidadesPlanejadas}</b></div>
      <div class="card erro"><small>Erros</small><b>${r.totais.erro}</b></div>
      <div class="card atencao"><small>Atenção</small><b>${r.totais.atencao}</b></div>
      <div class="card info"><small>Informações</small><b>${r.totais.info}</b></div>
    </div>`;
  if (r.semCobertura) h += '<p class="aviso">Esta coleta foi feita por uma versão anterior da extensão e não guardou a cobertura por unidade. As verificações de unidades com falha, filas, horários e composição não puderam ser feitas; vale refazer a coleta para um relatório completo.</p>';
  if (!r.achados.length) h += '<p class="ok">Nenhuma inconsistência encontrada nesta coleta.</p>';
  for (const [un, lista] of secoes) {
    h += `<h2>${esc(un)}</h2><table><thead><tr><th style="width:92px">Nível</th><th style="width:150px">Tema</th><th>O que foi encontrado</th></tr></thead><tbody>`
      + lista.map(x => `<tr><td><span class="n ${x.nivel}">${NOME[x.nivel]}</span></td><td>${esc(x.tema)}</td><td>${esc(x.texto)}</td></tr>`).join('') + '</tbody></table>';
  }
  h += '<p class="meta" style="margin-top:18px">Como ler: <b>Erro</b> é coleta que não terminou; <b>Atenção</b> é dado que parece faltar ou estar inconsistente e merece conferência; <b>Informação</b> é algo que pode ser normal (por exemplo, indicadores de odontologia em unidade sem equipe de saúde bucal). O relatório compara cada unidade com as demais da mesma coleta e não tem acesso a dados de pacientes.</p>';
  doc.innerHTML = h;
  document.title = `Inconsistências ${m}-${a} · Coletor APS`;
})();
