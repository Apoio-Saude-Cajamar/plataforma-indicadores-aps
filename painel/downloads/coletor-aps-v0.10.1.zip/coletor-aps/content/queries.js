// Consultas GraphQL do PEC usadas pelo coletor (versão do PEC observada em nov/2026).
// As consultas de listas pedem SOMENTE datas, contagens, marcadores e identificadores internos necessários ao cálculo:
// nenhum nome, CPF, CNS, telefone ou número de casa é solicitado ao servidor.
// Exceção declarada: a CVAT lê o nome das ruas da microárea, porque o PEC lista os imóveis rua a rua;
// o nome da rua só é usado como filtro da consulta seguinte e não é guardado nem enviado.
// Se uma atualização do PEC mudar algum nome de campo, é aqui que se ajusta.
var QUERIES = (function () {
  const VAC = 'vacinasAplicadas { dimensaoImunobiologico { nome sigla grupo } dimensaoDoseImunobiologico { sigla ordem } dataRegistroVacinaAplicada }';
  const VISITAS = 'visitaDomiciliar { dataUltimasVisitasDomiciliares qtdVisitasDomiciliares }';

  const CONSOLIDADO = {
    GESTANTE_PUERPERA: `preNatalPuerperio { altoRiscoGestacional idadeGestacionalCronologicaEmDias ultimaDum dppCronologica
      medicoesPreNatal { qtdMedicoesPressaoArterial qtdMedicoesPesoAltura }
      atendimentosPreNatalPuerperio { consultasPrimeirasDozeSemanas consultasPreNatalGestacao consultasOdontologicasGestacao consultasPuerperio dataUltimaConsultaPreNatal dataUltimaConsultaPuerperio }
      examesRealizadosPreNatal { sifilisPrimeiroTrimestre sifilisTerceiroTrimestre hivPrimeiroTrimestre hivTerceiroTrimestre hepatiteBPrimeiroTrimestre hepatiteCPrimeiroTrimestre }
      visitasDomiciliares { visitasDomiciliaresPreNatal visitasDomiciliaresPuerperio } ${VAC} }`,
    PESSOA_IDOSA: `pessoaIdosa { ${VISITAS} quantidadeMedicoesSimultaneasPesoAltura ${VAC} }`,
    DESENVOLVIMENTO_INFANTIL: `desenvolvimentoInfantil { qtdMedicoesPesoAltura visitasDomiciliares { dataPrimeiraVisita dataSegundaVisita qtdVisitasDomiciliares } consultas { qtdConsultas dataPrimeiraConsulta } ${VAC} }`,
    DIABETES: `diabetes { ${VISITAS} dataUltimaConsulta qtdConsultas exames { hemoglobinaGlicada { dataRealizacao } dataUltimaSolicitacaoHemoglobinaGlicada dataAvaliacaoPes } }`,
    HIPERTENSAO_ARTERIAL: `hipertensao { ${VISITAS} qtdPressaoArterial qtdConsulta dataUltimaConsulta }`,
    // C7: datas dos exames de colo e mama (com a descrição do exame, para separar o HPV molecular) e vacinas.
    SAUDE_MULHER: `saudeMulher { hiv sifilis hepatiteB hepatiteC ultimaConsulta { iniciadoEm }
      ultimaAvaliacaoCancerMama { dataAvaliacao } ultimaRealizacaoCancerMama { exameRequisitado { dataRealizacao } }
      ultimaSolicitacaoCancerMama { exameRequisitado { dataSolicitacao } }
      ultimaAvaliacaoCancerColoUtero { dataAvaliacao exameRequisitado { dataResultado exame { descricao } } }
      ultimaSolicitacaoCancerColoUtero { exameRequisitado { dataSolicitacao exame { descricao } } }
      ${VAC} }`,
    GERAL: ''
  };
  // Listas em que o identificador interno é pedido (só para juntar listas na memória; não é guardado).
  const COM_ID = { SAUDE_MULHER: true, GERAL_CODIGO: true };

  function lista(tematica) {
    const cons = CONSOLIDADO[tematica];
    return `query ColetorCondicaoSaude($input: AcompanhamentoCondicaoSaudeQueryInput!) {
  acompanhamentoCondicaoSaude(input: $input) {
    content {
      ${COM_ID[tematica] ? 'cidadaoId' : ''} sexoCidadao identidadeGeneroCidadao
      dataNascimentoCidadao dataUltimoAtendimentoMedico dataUltimoAtendimentoEnfermagem dataUltimoAtendimentoOdontologico
      dataUltimaMedicaoPesoAltura dataUltimaMedicaoPressaoArterial
      ${cons ? `cidadao { cidadaoConsolidado { ${cons} } }` : ''}
    }
    pageInfo { number size totalPages totalElements last }
  }
}`;
  }

  return {
    sessao: {
      op: 'ColetorSessao',
      query: `query ColetorSessao {
  sessao { id
    acesso { id tipo ... on Lotacao { unidadeSaude { id nome cnes } cbo { nome cbo2002 } } }
    profissional { id acessos { id tipo ... on Lotacao { cbo { nome cbo2002 } equipe { id nome ine } unidadeSaude { id nome cnes } } } }
  }
}`
    },
    selecionarAcesso: {
      op: 'SelecionarAcesso',
      query: `mutation SelecionarAcesso($input: SelecionarAcessoInput!) { selecionarAcesso(input: $input) { id acesso { id } } }`
    },
    equipes: {
      op: 'EquipeSelectField',
      query: `query EquipeSelectField($input: EquipesQueryInput!) { equipes(input: $input) { content { id nome ine ativo tipoEquipe { sigla nome } } } }`
    },
    // Equipes vinculadas a uma equipe principal (eSB → eSF/eAP; eMulti → eSF/eAP), como no cadastro do PEC.
    equipesVinculadas: {
      op: 'EquipesVinculadasTable',
      query: `query EquipesVinculadasTable($input: EquipesQueryInput!) { equipesVinculadas(input: $input) { content { ine ativo } } }`
    },
    // Profissionais com agenda na unidade do acesso atual e a grade semanal de cada um (horas da eSB).
    lotacoesAgenda: {
      op: 'ColetorLotacoesAgenda',
      query: `query ColetorLotacoesAgenda($input: LotacoesAgendaInput!) { lotacoesAgenda(input: $input) { content { id ativo hasConfiguracaoAgenda cbo { cbo2002 } equipe { ine } } } }`
    },
    gradeAgenda: {
      op: 'ColetorGradeAgenda',
      query: `query ColetorGradeAgenda($lotacaoId: ID!) { lotacao(id: $lotacaoId) { configuracaoAgenda { configuracaoHorarioAgenda { configuracaoDiasSemana { diaSemana periodos { horarioInicial horarioFinal } } } } } }`
    },
    vinculados: {
      op: 'ColetorVinculados',
      query: `query ColetorVinculados($input: AcompanhamentoCidadaosVinculadosFilterInput!) { acompanhamentoCidadaosVinculados(input: $input) { pageInfo { totalElements } } }`
    },
    absenteismos: {
      op: 'Absenteismos',
      query: `query Absenteismos($input: RelatorioGerencialAbsenteismoInput!) { absenteismos(input: $input) { unidadeSaude equipe nomeSituacaoAgendamento cbo } }`
    },
    // Filas e faltas: faltas com o nome do profissional (médicos e enfermeiros da APS).
    absenteismosProfissional: {
      op: 'AbsenteismosProfissional',
      query: `query AbsenteismosProfissional($input: RelatorioGerencialAbsenteismoInput!) { absenteismos(input: $input) { unidadeSaude equipe nomeSituacaoAgendamento cbo nomeProfissional } }`
    },
    // Agendas da unidade atual e a situação de cada dia do mês (disponível ou não). Nada de paciente.
    lotacoesAgenda: {
      op: 'ColetorLotacoesAgenda',
      query: `query ColetorLotacoesAgenda($input: LotacoesAgendaInput!) { lotacoesAgenda(input: $input) { content { id ativo hasConfiguracaoAgenda profissional { nome } cbo { nome cbo2002 } equipe { ine nome } } } }`
    },
    // Faltas por horário: agendamentos do mês de uma lotação. Só horário, situação e tipo; nenhum dado do cidadão.
    agendaFaltas: {
      op: 'ColetorAgendaFaltas',
      query: `query ColetorAgendaFaltas($input: AgendadosQueryInput!) { agendados(input: $input) { content { horarioInicial situacao tipoAgendamento } } }`
    },
    mesAgenda: {
      op: 'ColetorMesAgenda',
      query: `query ColetorMesAgenda($input: MesAgendaQueryInput!) { mesAgenda(input: $input) { id dias { data status } } }`
    },
    // Atividades coletivas do município no período (só os identificadores).
    atividadesLista: {
      op: 'ColetorAtividades',
      query: `query ColetorAtividades($input: AtividadeColetivaQueryInput!) {
  atividadesColetivas(input: $input) { content { id } pageInfo { totalPages totalElements last } }
}`
    },
    // Detalhe de uma atividade: tipo, tema da reunião, práticas, equipe e CBO dos profissionais e, dos participantes,
    // o identificador interno, a data de nascimento e CPF/CNS (só para conferir se são válidos, na memória).
    // Dos profissionais, CPF/CNS servem só para saber se são pessoas diferentes (regra do M2). Nada disso é guardado nem enviado.
    atividadeDetalhe: {
      op: 'ColetorAtividade',
      query: `query ColetorAtividade($id: Long!) {
  atividadeColetiva(atividadeColetivaId: $id) {
    dataAtividade tipoAtividade temasReuniao praticasSaude numeroParticipantes
    lotacaoResponsavel { cbo { cbo2002 nome } equipe { ine nome } unidadeSaude { nome } profissional { nome cns cpf } }
    lotacoesEnvolvidas { cbo { cbo2002 nome } equipe { ine nome } unidadeSaude { nome } profissional { nome cns cpf } }
    participantes { cidadao { id dataNascimento cpf cns } cidadaoParticipante { id dataNascimento cpf cns } }
  }
}`
    },
    // M2: solicitações de Compartilhamento do Cuidado respondidas no período. Só o executante (equipe e CBO);
    // nenhum dado do cidadão ou do prontuário é pedido.
    cuidadosCompartilhado: {
      op: 'ColetorCuidadosCompartilhado',
      query: `query ColetorCuidadosCompartilhado($input: CuidadosCompartilhadoQueryInput!) {
  cuidadosCompartilhado(input: $input) { content { id status lotacaoExecutanteAtual { equipe { ine nome } unidadeSaude { nome } cbo { cbo2002 } } cboExecutanteAtual { cbo2002 } } pageInfo { totalPages totalElements last } }
}`
    },
    // Acompanhamento do território: microáreas da equipe e, de cada uma, só os índices (totais de imóveis).
    // Funciona para qualquer unidade (pelo CNES), sem trocar o acesso. Nenhum endereço ou morador é pedido.
    territorioEquipe: {
      op: 'ColetorTerritorioEquipe',
      query: `query ColetorTerritorioEquipe($input: TerritorioEquipeQueryInput!) { territorioEquipe(input: $input) { microareas } }`
    },
    territorioMicroarea: {
      op: 'ColetorTerritorioMicroarea',
      query: `query ColetorTerritorioMicroarea($input: TerritorioMicroareaQueryInput!) {
  territorioMicroarea(input: $input) { indices { quantidadeImoveisCadastroCompleto totalImoveisNaoRecusados quantidadeImoveisAtualizados totalImoveisAtualizados quantidadeDomiciliosAvaliados quantidadeDomiciliosVisitados } }
}`
    },
    // CVAT · cadastro: dos vinculados, só data de nascimento, data da última atualização, microárea, origem (CDS/PEC)
    // e o identificador interno da pessoa (usado só na memória, para ligar a pessoa ao domicílio e às visitas).
    vinculadosLista: {
      op: 'ColetorVinculadosLista',
      query: `query ColetorVinculadosLista($input: AcompanhamentoCidadaosVinculadosFilterInput!) {
  acompanhamentoCidadaosVinculados(input: $input) { content { dataNascimentoCidadao dataUltimaAtualizacaoCidadao microarea origem cidadao { id } } pageInfo { totalPages totalElements last } }
}`
    },
    // CVAT pela NT 30/2025, sem abrir casa por casa: ruas da microárea, imóveis de cada rua e visitas de cada imóvel.
    // Pedem só datas, marcadores e identificadores internos. Não pedem nome, CPF, CNS, telefone nem número da casa;
    // o nome da rua serve apenas de filtro para a consulta seguinte e não é guardado.
    territorioRuas: {
      op: 'ColetorTerritorioRuas',
      query: `query ColetorTerritorioRuas($input: TerritorioMicroareaQueryInput!) {
  territorioMicroarea(input: $input) { id logradouros { content { id logradouro tipoLogradouroId bairro cep numeroImoveis } pageInfo { totalPages totalElements last } } }
}`
    },
    territorioImoveis: {
      op: 'ColetorTerritorioImoveis',
      query: `query ColetorTerritorioImoveis($input: TerritorioMicroareaQueryInput!) {
  territorioLogradouro(input: $input) { id tipoImovel dataUltimaVisita dataUltimaAtualizacao statusRecusa stAtivo
    validas: familias(input: {isDomicilioAtivo: true, isFamiliaAindaReside: true, isInformacaoSuficiente: true, isResponsavelAindaReside: true, isResponsavelCadastrado: true, isResponsavelDeclarado: true, isResponsavelUnico: true, isResponsavelVivo: true}) { id cidadaosTerritorioBasico { id } }
    todas: familias { id cidadaosTerritorioBasico { id } } }
}`
    },
    visitasImovel: {
      op: 'ColetorVisitasImovel',
      query: `query ColetorVisitasImovel($input: VisitasQueryInput!) {
  visitas(input: $input) { content { dataVisita dimensaoDesfechoVisita { descricao } cidadaoPec { id dataNascimento } } pageInfo { totalPages totalElements last } }
}`
    },
    // CVAT · acompanhamento: datas dos últimos contatos por tipo, microárea e o marcador de Bolsa Família.
    listaCvat: {
      op: 'ColetorCvat',
      query: `query ColetorCvat($input: AcompanhamentoCondicaoSaudeQueryInput!) {
  acompanhamentoCondicaoSaude(input: $input) {
    content { dataNascimentoCidadao microarea dataUltimoAtendimentoMedico dataUltimoAtendimentoEnfermagem dataUltimoAtendimentoOdontologico dataUltimaVisitaDomiciliar
      cidadao { id beneficiarioBolsaFamilia { isBeneficiario } } }
    pageInfo { number size totalPages totalElements last }
  }
}`
    },
    // Lista de atendimentos da unidade (só status e o identificador interno do cidadão, para contar pessoas).
    listaAtendimentos: {
      op: 'ColetorListaAtendimentos',
      query: `query ColetorListaAtendimentos($input: AtendimentosQueryInput!) { atendimentos(input: $input) { content { statusAtendimento cidadao { id } } pageInfo { totalPages totalElements last } } }`
    },
    equipesEmulti: {
      op: 'ColetorEquipesEmulti',
      query: `query ColetorEquipesEmulti($input: EquipesQueryInput!) { equipes(input: $input) { content { id nome ine ativo tipoEquipe { sigla } } } }`
    },
    lista: tematica => ({ op: 'ColetorCondicaoSaude', query: lista(tematica) })
  };
})();
