// Acesso às interfaces do PEC usando a sessão já aberta no navegador.
// Não guarda nem envia credenciais: usa o cookie de sessão e o token XSRF que a própria página usa.
var PEC = {
  xsrf() {
    const m = document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : null;
  },

  // "Cancelar" no painel liga este sinal: o próximo pedido ao PEC é recusado e a etapa em curso para logo.
  // A leitura da sessão e a troca de acesso continuam liberadas, para devolver o acesso original.
  cancelado: false,
  checarCancelamento(op) {
    if (PEC.cancelado && op !== 'ColetorSessao' && op !== 'SelecionarAcesso') throw new Error('Coleta cancelada.');
  },

  _headers() {
    const h = { 'Content-Type': 'application/json' };
    const t = PEC.xsrf();
    if (t) h['X-XSRF-TOKEN'] = t;
    return h;
  },

  // Falhas passageiras (rede caiu, servidor ocupado ou com erro HTTP) são repetidas com espera crescente.
  // Não se repete: sessão caída (401/403), cancelamento, nem erro devolvido pelo próprio PEC (ex.: "Acesso não permitido").
  ESPERAS: [1500, 4000],
  async _pedir(rotulo, url, corpo, tentativas, op) {
    for (let i = 0; ; i++) {
      PEC.checarCancelamento(op);
      const ultima = i + 1 >= tentativas;
      let r;
      try {
        r = await fetch(url, { method: 'POST', credentials: 'include', headers: PEC._headers(), body: JSON.stringify(corpo) });
      } catch (e) {
        if (!ultima) { await UTIL.dormir(PEC.ESPERAS[Math.min(i, PEC.ESPERAS.length - 1)]); continue; }
        throw new Error(`${rotulo}: sem resposta do PEC (${e.message})`);
      }
      if (r.status === 401 || r.status === 403) throw new Error('Sessão do PEC expirada ou sem permissão (HTTP ' + r.status + '). Faça login novamente.');
      if (!r.ok) {
        if (!ultima) { await UTIL.dormir(PEC.ESPERAS[Math.min(i, PEC.ESPERAS.length - 1)]); continue; }
        throw new Error(`${rotulo}: HTTP ${r.status}`);
      }
      return r;
    }
  },

  async gql(operationName, query, variables, tentativas = 3) {
    const r = await PEC._pedir(operationName, '/api/graphql', [{ operationName, variables, query }], tentativas, operationName);
    let j = await r.json();
    if (Array.isArray(j)) j = j[0];
    if (j.errors && j.errors.length) throw new Error(`${operationName}: ${j.errors.map(e => e.message).join('; ')}`);
    return j.data;
  },

  async gerencial(caminho, corpo) {
    const r = await PEC._pedir('gerencial ' + caminho, '/api/gerenciais/' + caminho, corpo, 3);
    return r.json();
  },

  // Percorre todas as páginas de uma consulta paginada.
  // montarVars(page, size) -> variables ; extrair(data) -> { content, pageInfo }
  async paginar(operationName, query, montarVars, extrair, aoProgredir, tamanho) {
    const size = tamanho || CONFIG.tamanhoPagina;
    let page = 0, total = null, todos = [];
    while (true) {
      const data = await PEC.gql(operationName, query, montarVars(page, size));
      const { content, pageInfo } = extrair(data);
      todos = todos.concat(content || []);
      total = pageInfo ? pageInfo.totalPages : 1;
      if (aoProgredir) aoProgredir(page + 1, total, pageInfo && pageInfo.totalElements);
      if (!pageInfo || pageInfo.last || page + 1 >= total) break;
      page++;
    }
    return todos;
  }
};
