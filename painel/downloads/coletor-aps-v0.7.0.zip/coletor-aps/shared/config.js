// Configuração do coletor. Tudo que depende de decisão da gestão fica aqui.
var CONFIG = {
  versao: '0.7.0',
  host: 'https://esus.cajamar.sp.gov.br',

  // As 11 unidades de Atenção Primária incluídas no acompanhamento.
  // Os nomes são comparados sem acento e sem diferença de maiúsculas.
  unidadesAPS: [
    'ESF Carlos dos Santos',
    'Posto de Saude Nadilia de Oliveira Santos',
    'Psf Belo Planalto',
    'Psf Dra Maria de Lourdes Mendonca Bravo',
    'Psf Edivaldo Soares Massagardi',
    'UBS Dra Izabel Gratieri',
    'UBS Enf Leontina Martins Franca',
    'UBS Enfermeiro Carlos Moreira da Silva',
    'Usf Manoel Inacio da Silva',
    'Usf Maria Aparecida Misse',
    'Usf Vereador Joaquim Alves de Castro'
  ],

  // Perfil usado em cada unidade na tela "Trocar acesso".
  perfilAcesso: 'Assistente administrativo',

  // Grupos de CBO para o Q14.2.1 (absenteísmo de consultas).
  // "padrao: true" define o cálculo oficial; o painel permite ligar e desligar.
  gruposCBO: {
    medicos:     { rotulo: 'Médicos',              prefixos: ['2251', '2252', '2253'], padrao: true },
    enfermeiros: { rotulo: 'Enfermeiros',          prefixos: ['2235'],                 padrao: true },
    dentistas:   { rotulo: 'Cirurgiões-dentistas da APS', prefixos: ['223293', '223208'],                 padrao: true },
    emulti:      { rotulo: 'eMulti (psicologia, nutrição, fisioterapia, fono, serviço social, farmácia)',
                   prefixos: ['2515', '2237', '2236', '2238', '2516', '2234'],        padrao: false },
    tecnicos:    { rotulo: 'Técnicos e auxiliares de enfermagem', prefixos: ['3222'],  padrao: false }
  },

  // Tipos de falta do relatório de absenteísmo (ambos entram por padrão).
  tiposFalta: ['NÃO COMPARECEU', 'NÃO AGUARDOU'],

  // Esquema vacinal da C2 (item E), conforme a Nota Metodológica C2.
  // "grupo" é o grupo de imunobiológico informado pelo próprio PEC.
  esquemaVacinalC2: [
    { nome: 'Pentavalente (difteria, tétano, coqueluche, hepatite B, Hib)', grupo: 'DIFTERIA_TETANO_PERTUSIS', doses: 3, dosesValidas: ['D1', 'D2', 'D3'], intervaloDias: 30 },
    { nome: 'Poliomielite (VIP)', grupo: 'POLIOMELITE', doses: 3, dosesValidas: ['D1', 'D2', 'D3'], intervaloDias: 30 },
    { nome: 'Sarampo, caxumba e rubéola (SCR/SCRV)', grupo: 'SARAMPO_CACHUMBA_RUBEOLA', doses: 2, idadeMinimaMeses: 12, excluirDoses: ['D0'] },
    { nome: 'Pneumocócica', grupo: 'PNEUMOCOCICA', doses: 2, dosesValidas: ['D1', 'D2'], intervaloDias: 30 }
  ],

  // C1: CBOs e tipos de equipe definidos na Nota Metodológica C1.
  // A escuta inicial (demanda espontânea) não aparece no relatório gerencial; ela é lida do
  // relatório de produção "Atendimento individual", por equipe e por estas categorias profissionais.
  c1: {
    cbos: ['225142', '225170', '225130', '225125', '225250', '223565', '223505'],
    tiposEquipe: ['ESF', 'EAP'],
    categoriasEscuta: ['ENFERMEIRO', 'MÉDICO']
  },

  // Saúde bucal (Notas B1 a B6). Os procedimentos vêm do relatório de produção "Atendimento odontológico",
  // exportado por equipe de saúde bucal (eSB). Códigos SIGTAP com 10 dígitos, sem pontos.
  saudeBucal: {
    // eSB → eSF/eAP de referência (divisor de B1 e B4). A coleta lê o vínculo oficial do PEC
    // (Unidades de saúde → equipe → "Equipes vinculadas"). Este campo só serve para corrigir algum caso,
    // pelo nome ou INE: { 'NOME DA ESB': ['NOME DA ESF'] }. Uma eSF ligada a duas eSB (duas de 20h)
    // tem a população repartida entre elas.
    referencia: {},
    // Nome do procedimento no relatório → código SIGTAP (a seção "Outros procedimentos" já traz o código).
    nomes: {
      'acesso a polpa dentaria e medicacao (por dente)': '0307020010',
      'aplicacao de cariostatico (por dente)': '0101020058',
      'aplicacao de selante (por dente)': '0101020066',
      'aplicacao topica de fluor (individual por sessao)': '0101020074',
      'capeamento pulpar': '0307010015',
      'curativo de demora com ou sem preparo biomecanico': '0307020029',
      'evidenciacao de placa bacteriana': '0101020082',
      'exodontia de dente deciduo': '0414020120',
      'exodontia de dente permanente': '0414020138',
      'orientacao de higiene bucal': '0101020104',
      'profilaxia / remocao da placa bacteriana': '0307030040',
      'pulpotomia dentaria': '0307020070',
      'raspagem alisamento e polimento supragengivais (por sextante)': '0307030059',
      'raspagem alisamento subgengivais (por sextante)': '0307030024',
      'restauracao de dente permanente anterior com resina composta': '0307010031',
      'restauracao de dente permanente posterior com resina composta': '0307010120',
      'selamento provisorio de cavidade dentaria': '0101020090'
    },
    // Nota B3: exodontias ÷ procedimentos preventivos, curativos e exodontias.
    b3: {
      numerador: ['0414020138', '0414020146'],
      denominador: ['0101020058', '0101020066', '0101020074', '0101020082', '0101020090', '0101020120', '0307010015', '0307010031',
        '0307010066', '0307010074', '0307010082', '0307010104', '0307010112', '0307010120', '0307020010', '0307020029', '0307020070',
        '0307030024', '0307030040', '0307030059', '0307030067', '0307030075', '0307030083', '0307050017', '0414020138', '0414020146']
    },
    // Nota B5: procedimentos preventivos ÷ todos os procedimentos individuais da lista.
    b5: {
      numerador: ['0101020058', '0101020066', '0101020074', '0101020082', '0101020104', '0101020120', '0307030040'],
      denominador: ['0101020058', '0101020066', '0101020074', '0101020082', '0101020090', '0101020104', '0101020120', '0414020138',
        '0307010015', '0307010031', '0307010066', '0307010074', '0307010082', '0307010104', '0307010112', '0307010120', '0307010147',
        '0307010155', '0307020010', '0307020029', '0307020070', '0307030024', '0307030040', '0307030059', '0307030067', '0307030075',
        '0307030083', '0307050017']
    },
    // Nota B6: TRA ÷ procedimentos restauradores (sem amálgama).
    b6: {
      numerador: ['0307010074'],
      denominador: ['0307010031', '0307010082', '0307010104', '0307010112', '0307010120', '0307010074']
    },
    // Nota B4: prática "Escovação dental supervisionada" com crianças de 6 a 12 anos.
    b4: { pratica: 'ESCOVACAO_DENTAL_SUPERVISIONADA', idadeMin: 6, idadeMax: 12, cbos: ['223293', '223208'] },
    // As notas valem só para os profissionais da Atenção Primária. Em odontologia contam apenas:
    //   223293 Cirurgião-dentista da Estratégia de Saúde da Família
    //   223208 Cirurgião-dentista - clínico geral
    // (ficam de fora ASB, TSB, dentistas especialistas e de saúde coletiva).
    cbos: ['223293', '223208'],
    cbosNomes: ['CIRURGIAO-DENTISTA DA ESTRATEGIA DE SAUDE DA FAMILIA', 'CIRURGIAO DENTISTA - CLINICO GERAL'],
    categoriaRelatorio: 'CIRURGIÃO DENTISTA'
  },

  // eMulti de Cajamar (Notas M1 e M2). São reconhecidas pelo tipo de equipe no PEC; os INEs servem de conferência.
  emulti: {
    ines: { '0002525925': 'COMPLEMENTAR 1', '0002525933': 'COMPLEMENTAR 2', '0002526255': 'COMPLEMENTAR 3', '0002525763': 'ESTRATEGICA 1' }
  },

  // Atividades coletivas: quantas consultas de detalhe ao mesmo tempo.
  atividadesParalelas: 6,

  // Acompanhamento do território (CVAT, cadastro domiciliar). A microárea FA (fora de área)
  // fica fora do indicador e é guardada em linha própria (TERR-FA) para planejamento.
  coletarTerritorio: true,

  // Composição das equipes (quadro de lotação por unidade) e a avaliação dela.
  composicao: {
    guardarNomes: true,   // false = guarda só a categoria (CBO) de cada lotação, sem o nome do profissional
    // Mínimo esperado por tipo de equipe; cada regra testa o nome do CBO (sem acento, minúsculas).
    minimo: {
      ESF: [['médico', /^medico/], ['enfermeiro', /^enfermeiro/], ['técnico ou auxiliar de enfermagem', /^(tecnico|auxiliar) de enfermagem/], ['agente comunitário de saúde', /agente comunitario de saude/]],
      EAP: [['médico', /^medico/], ['enfermeiro', /^enfermeiro/]],
      ESB: [['cirurgião-dentista da APS (ESF ou clínico geral)', /^cirurgiao[ -]dentista (da estrategia de saude da familia|- clinico geral)/], ['auxiliar ou técnico de saúde bucal', /^(auxiliar|tecnico) em saude bucal/]],
      ECR: [['enfermeiro ou médico', /^(enfermeiro|medico)/]]
    },
    // Categorias que deveriam estar sempre numa equipe.
    devemTerEquipe: [/agente comunitario de saude/, /^cirurgiao[ -]dentista (da estrategia de saude da familia|- clinico geral)/, /da estrategia de saude da familia/]
  },

  // CVAT · Cadastro e acompanhamento territorial (Nota Técnica 30/2025). Cajamar: porte 50 a 100 mil habitantes.
  cvat: {
    parametros: { ESF: 2750, EAP30: 2063, EAP20: 1375 },
    // Carga horária das eAP (30 ou 20 h). Pode ser corrigida por equipe pelo nome ou INE: { 'EAP JORDANESIA 2': 20 }.
    eapHoras: 20, eapHorasPorEquipe: {}, // Cajamar: uma eAP ativa (Jordanésia), de 20 h
    mesesCadastro: 24, mesesAcompanhamento: 12,
    // Divisor do índice de acompanhamento: 'parametro' (parâmetro da equipe) ou 'cadastrados' (vinculados ponderados).
    // A nota não diz qual; a escolha muda muito o resultado.
    denominadorAcompanhamento: 'parametro',
    faixasCadastro: [[85, 3.00], [65, 2.25], [45, 1.50], [-Infinity, 0.75]],
    faixasAcompanhamento: [[85, 7.00], [65, 5.25], [45, 3.50], [-Infinity, 1.75]],
    tamanhoPagina: 1000
  },

  // CR4 · Cuidado da pessoa com tuberculose (eCR): CID-10 do item 24 f da nota.
  cr4: { cid10: ['A15', 'A150', 'A151', 'A152', 'A153', 'A16', 'A160', 'A161', 'A162', 'A17'],
    // Relatório de atendimento individual filtrado por esta condição (itens A, B e C, aproximados).
    // O relatório não gera arquivo quando não há registro; depois de esperaSemArquivoMin, conta como zero.
    filtroRelatorio: { campo: 'Problemas / Condições avaliadas - Outros CID10', valores: ['A15', 'A150', 'A151', 'A152', 'A153', 'A16', 'A160', 'A161', 'A162', 'A17'] },
    esperaSemArquivoMin: 3 },

  // C7 · Cuidado da mulher na prevenção do câncer (Nota Metodológica C7).
  // Nota final = A×20 + B×30 + C×30 + D×20, cada item = cumpridas ÷ pessoas da faixa do item.
  // Entram pessoas de sexo feminino (menos mulheres trans) e homens trans.
  c7: {
    pesos: { A: 20, B: 30, C: 30, D: 20 },
    faixas: { A: [25, 64], B: [9, 14], C: [14, 69], D: [50, 69] },
    janelaColoMeses: 36, janelaHpvMolecularMeses: 60, janelaMamaMeses: 24, janelaConsultaMeses: 12,
    // Item C: atendimento de médico ou enfermeiro em 12 meses com um destes códigos (item 24 g da nota).
    // O PEC só filtra um código por vez (vários = E), por isso são consultados um a um.
    coletarItemC: true,
    ciaps: 'B25 W02 W10 W11 W12 W13 W14 W15 W79 W82 X01 X02 X03 X04 X05 X06 X07 X08 X09 X10 X11 X12 X13 X23 X24 X82 X89 Y14 ABP003 ABP022 ABP023'.split(' '),
    cid10: ('N80 N800 N801 N802 N803 N804 N805 N806 N808 N809 N91 N910 N911 N912 N913 N914 N915 N92 N920 N921 N922 N923 N924 N925 N926 ' +
      'N93 N930 N938 N939 N94 N940 N941 N942 N943 N944 N945 N946 N948 N949 N95 N950 N951 N952 N953 N958 N959 N96 N97 N970 N971 N972 N973 N974 N978 N979 ' +
      'O03 O04 R102 T742 Y050 Y051 Y052 Y053 Y054 Y055 Y056 Y057 Y058 Y059 Z123 Z124 Z205 Z206 Z30 Z300 Z301 Z302 Z303 Z304 Z305 Z308 Z309 ' +
      'Z31 Z310 Z311 Z312 Z313 Z314 Z315 Z316 Z318 Z319 Z320 Z600 Z630 Z640 Z70 Z700 Z701 Z702 Z703 Z708 Z709 Z717 Z725').split(' ')
  },

  // Tamanho de página nas listas (o PEC aceita até 100).
  tamanhoPagina: 100
};
