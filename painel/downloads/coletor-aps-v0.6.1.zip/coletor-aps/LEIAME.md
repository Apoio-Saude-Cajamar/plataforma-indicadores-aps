# Coletor de Indicadores APS – Cajamar (v0.6.1)

Extensão do Chrome que coleta, uma vez por mês, os indicadores da Atenção Primária a partir do PEC e-SUS APS (esus.cajamar.sp.gov.br), usando a sessão já aberta no navegador.

## Instalação (modo desenvolvedor)

1. Descompacte o arquivo `coletor-aps-v0.6.1.zip` numa pasta fixa (por exemplo, `Documentos\coletor-aps`). Não apague a pasta depois.
2. No Chrome, abra `chrome://extensions`.
3. Ligue **Modo do desenvolvedor** (canto superior direito).
4. Clique em **Carregar sem compactação** e escolha a pasta descompactada.
5. Fixe o ícone da extensão na barra (ícone de quebra-cabeça → alfinete).

## Uso mensal

1. Abra o PEC, faça login e escolha qualquer acesso. Se o PEC já estava aberto antes de instalar, recarregue a aba (F5).
2. Clique no ícone da extensão: o painel lateral abre.
3. Confira a competência (vem sugerido o mês anterior) e clique em **Iniciar coleta**.
4. Mantenha o painel aberto e a aba do PEC aberta até terminar. Leva cerca de 1 minuto por unidade, mais uns 20 segundos por equipe eSF/eAP para a escuta inicial (em torno de 20 minutos no total). Evite usar o PEC nessa aba durante a coleta.
5. Ao final, a coleta fica no **Histórico**. Use **Exportar CSV** ou **Exportar JSON**.

Durante a coleta a extensão troca o acesso entre as 11 unidades e, no fim, volta ao acesso que estava em uso. O cabeçalho do PEC só mostra a unidade correta depois de recarregar a página.

Para a escuta inicial, a extensão abre o relatório de produção *Atendimento individual* em cada unidade e exporta um CSV por equipe e categoria (médico e enfermeiro). Esses arquivos aparecem na fila "Relatórios em processamento/processados" do PEC, mas **não são baixados no computador**: a extensão lê o conteúdo direto do PEC e guarda só os totais.

## O que esta versão coleta

| Indicador | Fonte no PEC | Nível |
|---|---|---|
| C1 – Mais acesso | Gerencial de atendimentos (CBOs exatos) + relatório de produção Atendimento individual (escuta inicial) | município, unidade, equipe |
| Q14.2.1 – Absenteísmo de consultas: faltas ÷ (atendimentos + faltas) | Gerenciais de absenteísmo e de atendimentos | município, unidade, equipe; filtros por grupo de CBO e tipo de falta |
| Q12.2 – Pessoas vinculadas por equipe | Cidadãos vinculados | equipe |
| C2, C3, C4, C5, C6 | Condições de saúde (listas temáticas) | equipe |
| S3, S4, S20 | Condições de saúde – Gestação e puerpério | equipe |
| CR1 – Mais acesso à eCR | Condições de saúde – Geral (equipe eCR) | equipe |
| B1, B2, B3, B5, B6 – Saúde bucal | Relatório de produção *Atendimento odontológico*, exportado por equipe eSB | equipe eSB |
| B4 – Escovação supervisionada (6 a 12 anos) | Atividades coletivas (prática "Escovação dental supervisionada"), idade calculada na data da atividade | equipe eSB |
| M2 – Ações interprofissionais (parte coletiva) | Atividades coletivas com 2 ou mais profissionais, uma eMulti entre eles | equipe eMulti |
| M1 – numerador | Gerencial de atendimentos (equipes eMulti) + participações em atividades coletivas | equipe eMulti |

## Privacidade (LGPD)

- **Atividades coletivas:** para cada atividade a extensão pede só tipo, práticas, equipe e CBO dos profissionais e, dos participantes, o identificador interno do PEC e a data de nascimento. Com isso calcula a idade e evita contar a mesma criança duas vezes no mês; depois descarta tudo e guarda apenas totais por equipe. Nome, CPF e CNS não são pedidos.

- As consultas às listas pedem ao PEC **somente datas, contagens e marcadores** (por exemplo, "consultas no pré-natal: 7"). Nome, CPF, CNS, endereço e telefone **não são solicitados**.
- A pontuação de cada pessoa é calculada na memória do navegador e descartada; ficam guardados apenas totais por equipe.
- Sem chave de coleta, nada é enviado para fora do computador; com ela, só os totais agregados vão ao Painel APS. O histórico fica no armazenamento local da extensão.
- A extensão não lê nem guarda usuário ou senha: usa a sessão aberta pelo próprio usuário.

## Decisões e pendências

- **Q14.2.1**: entram por padrão médicos (CBO 2251/2252/2253), enfermeiros (2235) e dentistas (2232); eMulti e técnicos podem ser ligados nos filtros. Os dois tipos de falta entram por padrão.
- **C1** (Nota C1): só os CBOs 225142, 225170, 225130, 225125, 225250, 223565 e 223505, em equipes eSF/eAP. A escuta inicial (demanda espontânea), que o relatório gerencial não apresenta, é lida do relatório de produção Atendimento individual por equipe e pelas categorias médico e enfermeiro, e somada ao denominador. Conferência em out/2026 (equipe Ponunduva): os atendimentos de médicos e enfermeiros sem a escuta bateram exatamente nas duas fontes (449). A opção pode ser desligada no painel.
- **C2 item E** (Nota C2): pentavalente 3 doses, VIP 3 doses (intervalo mínimo de 30 dias), tríplice/tetraviral 2 doses aplicadas a partir dos 12 meses e pneumocócica 2 doses. Usa o grupo do imunobiológico informado pelo PEC.
- **C3** (Nota C3): gestação sem desfecho é encerrada aos 294 dias e o puerpério vai até 42 dias depois (336 dias). Só sai do denominador quem passou de 336 dias na data de referência. **Isso difere da planilha**, que desconsiderava toda gestação acima de 42 semanas.
- **eAP**: nas práticas de visita domiciliar (C2-D, C3-E/J, C4-D, C5-D, C6-C), equipes eAP recebem pontuação integral, como determinam as notas.
- **Momento da coleta**: as listas do PEC mostram a situação no dia da coleta (não há data de referência). Por isso a coleta deve ser feita no início de cada mês.
- **Diabetes e hipertensão**: seguem o critério da própria tela (problema ativo na lista de problemas).

## Saúde bucal e eMulti (novos na v0.4.0)

- **B1 a B6** seguem as notas do MS de 02/10/2026; os códigos SIGTAP de cada nota estão em `shared/config.js` (`saudeBucal`).
- **B1 e B2** contam registros do relatório (primeiras consultas e tratamentos concluídos no mês). A nota do MS conta cada pessoa uma vez a cada 12 meses por dentista; a diferença tende a ser pequena.
- **eSF/eAP de referência** (divisor de B1 e B4): a coleta lê o vínculo oficial do PEC (Unidades de saúde → equipe → Equipes vinculadas). A carga horária de cada eSB é a soma das grades de agenda dos seus dentistas; cada eSB fica com horas ÷ máx(40, horas de todas as eSB da eSF) da população (uma eSB de 20 h sozinha conta metade, como manda a nota). Correções pontuais podem ir em `saudeBucal.referencia`. Ao final, a coleta avisa eSF sem eSB, com menos de 40 h ou com mais de 40 h de eSB.
- **B4** conta crianças de 6 a 12 anos diferentes no mês, por eSB responsável ou envolvida na escovação.
- **eMulti**: Complementar 1, 2 e 3 e Estratégica 1, reconhecidas pelo tipo de equipe no PEC (INEs em `emulti.ines`).
- **M2** ainda é parcial: só atividades coletivas. Falta o atendimento individual compartilhado.
- **M1** ainda sem divisor: o PEC não traz, em relatório agregado, o número de pessoas diferentes atendidas.

## Novos na v0.4.1

- **Território** (opção "Território"): por equipe, imóveis com cadastro atualizado há menos de 1 ano, cadastro completo e domicílios visitados no mês, somando as microáreas. A microárea **FA (fora de área)** não entra; fica guardada à parte (TERR-FA), com o detalhe por microárea, para planejamento. O PEC só mostra as visitas do mês corrente: para TERR-VIS, colete no fim do mês.
- **C7** (Nota C7): nota = A×20 + B×30 + C×30 + D×20, cada item com o seu denominador (faixa etária do item). Entram pessoas de sexo feminino (menos mulheres trans) e homens trans.
  - A: exame de colo solicitado ou avaliado em 36 meses (HPV molecular: 60); B: dose de HPV em 9 a 14 anos; D: mamografia em 24 meses.
  - C: o PEC filtra um código por vez (vários códigos = "todos ao mesmo tempo"), por isso cada CIAP/CID da nota é consultado em separado e o resultado é unido. É aproximado: o PEC não informa a data do código, só a do último atendimento médico ou de enfermagem (12 meses). Leva cerca de 1 minuto por equipe; dá para desligar (opção "C7 item C").
- **CVAT** (NT 30/2025, porte 50 a 100 mil): parâmetro eSF 2.750, eAP 30 h 2.063, eAP 20 h 1.375 (`cvat.eapHoras` / `cvat.eapHorasPorEquipe`).
  - Cadastro: cadastro individual de origem CDS atualizado em 24 meses × 0,75, mais 0,75 estimado pela fração de imóveis atualizados da microárea da pessoa. Ficam fora: "Fora da área", cadastro só no PEC e cadastro vencido.
  - Acompanhamento: pessoa com 2 tipos diferentes de contato em 12 meses (médico, enfermagem, odontologia, visita domiciliar), pesos 1,0 / 1,2 (menor de 5 ou 60+) / 1,3 (Bolsa Família) / 2,5. É um piso: o PEC informa só a data do último contato de cada tipo.
  - O divisor do acompanhamento não está escrito na nota; o padrão é o parâmetro da equipe (`cvat.denominadorAcompanhamento`). Sem o bônus de satisfação.
- **CR2** (gestação na eCR), **CR3** (testes de sífilis, HIV e hepatites em 12 meses) e **CR4** parcial (pessoas com tuberculose e o teste de HIV; consultas, baciloscopia e raio X sem fonte).

## Novos na v0.6.1

- **Mais resistente a recarregamentos do PEC:** se o canal com a página cair (troca de acesso, relatório clássico), a extensão espera a página voltar e tenta de novo; antes de cada unidade volta à página inicial do PEC.

## Novos na v0.6.0

- **Composição das equipes** (opção "Composição das equipes"): em cada unidade, lê o quadro de lotação (profissional, categoria e equipe) na lista de profissionais do relatório clássico. O CNS do profissional é descartado na leitura. Monta a árvore município → unidade → equipe → profissionais, com os vínculos entre equipes e as horas das eSB, e avalia: equipe sem a composição mínima (regras em `composicao.minimo`), eSB sem vínculo, eMulti com poucas equipes, ACS, dentistas e profissionais da ESF sem equipe, lotação em equipe que não está ativa na unidade e profissional em mais de uma equipe. Para guardar só as categorias, sem nomes, use `composicao.guardarNomes: false`.
- **Envio ao Painel APS:** com o endereço e a chave de coleta preenchidos no painel da extensão, a composição é enviada para a página "Composição" do Painel APS.

## Novos na v0.4.3

- **Saúde bucal só com dentistas da APS.** B1 a B6 consideram apenas o Cirurgião-dentista da Estratégia de Saúde da Família (CBO 223293) e o Cirurgião-dentista clínico geral (CBO 223208). O relatório odontológico é exportado pela categoria "Cirurgião dentista" (sem ASB e TSB); se a equipe tiver dentista de outro CBO (ex.: saúde coletiva), a produção dele é exportada à parte e descontada. A B4 conta só escovações com um desses dentistas entre os profissionais; as demais viram observação. As horas da eSB somam só as agendas desses dois CBOs.

## Novos na v0.4.2

- **eMulti completa** (opção "eMulti"):
  - **M2**: (atendimentos individuais com "Atendimento compartilhado" + atividades coletivas com 2 ou mais profissionais) ÷ (atendimentos individuais + atividades coletivas), no mês, pelo relatório gerencial de atendimentos.
  - **M1** (quadrimestre até o mês da coleta): (atendimentos individuais + participações em atividades coletivas) ÷ pessoas diferentes. As pessoas vêm da lista de atendimentos de cada unidade e dos participantes das atividades; para contar a mesma pessoa uma vez só entre unidades, a coleta usa resumos com um sal sorteado na hora, que ficam só na memória e são descartados no fim. Atendimentos só em ficha CDS entram por estimativa, com faixa mínima e máxima.
- **CR4**: itens A, B e C pelo relatório de atendimento individual da eCR em 6 meses, filtrado pelos CIDs de tuberculose da nota. O relatório dá totais, então cada item vem como teto, com faixa. Sem nenhum atendimento com esses CIDs, o PEC não gera o arquivo e os itens contam zero.
- **Observações**: o que a nota não conta, mas vale acompanhar (cadastro só no PEC, cadastro vencido, pessoas e imóveis fora de área, sem microárea, contato de um só tipo, sem contato em 12 meses), por equipe, em `observacoes` da coleta, para a futura página de observações.
- **Balão (i)**: indicadores aproximados mostram a precisão e a justificativa ao passar o mouse no "i"; quando há faixa, ela aparece ao lado do resultado.
- eAP: Cajamar tem uma eAP ativa, de 20 h (parâmetro 1.375 na CVAT).

## Ainda não coletados

Bônus de satisfação da CVAT; Bolsa Família/BPC (fonte externa).

## Personalização

- Unidades, grupos de CBO e esquema vacinal: `shared/config.js`.
- Cores e fonte (identidade visual): `panel/tema.css`.
- Consultas ao PEC (se uma atualização do PEC mudar algum campo): `content/queries.js`.
