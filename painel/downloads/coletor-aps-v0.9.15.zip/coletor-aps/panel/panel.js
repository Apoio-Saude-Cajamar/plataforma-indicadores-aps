// Painel lateral: orquestra a coleta, guarda o histórico e calcula os indicadores.
const $ = id => document.getElementById(id);
const estado = { aba: null, cancelar: false, coletaAtual: null, filtros: null };

// ---------------------------------------------------------------- inicialização
document.addEventListener('DOMContentLoaded', async () => {
  $('versao').textContent = 'v' + CONFIG.versao;
  $('competencia').value = UTIL.competenciaAnterior();
  montarUnidades();
  estado.filtros = filtrosPadrao();
  $('btnVerificar').onclick = verificarPEC;
  $('btnColetar').onclick = coletar;
  $('btnRetro').onclick = coletarRetroativo;
  $('retroDe').value = new Date().getFullYear() + '-01'; $('retroAte').value = UTIL.competenciaAnterior();
  $('btnRefazer').onclick = refazerFalhas;
  $('btnCancelar').onclick = () => {
    if (estado.cancelar) return;
    estado.cancelar = true;
    $('btnCancelar').disabled = true; $('btnCancelar').textContent = 'Cancelando…';
    log('Cancelamento solicitado: parando a etapa em curso.');
    if (estado.aba) chrome.tabs.sendMessage(estado.aba.id, { acao: 'cancelar', valor: true }).catch(() => {});
  };
  $('nivel').onchange = renderizar;
  await iniciarSelecao();
  $('btnJSON').onclick = () => exportarJSON(estado.coletaAtual);
  $('btnCSV').onclick = () => exportarCSV(estado.coletaAtual);
  $('btnInconsist').onclick = () => abrirInconsistencias(estado.coletaAtual);
  chrome.runtime.onMessage.addListener(msg => { if (msg && msg.tipo === 'progresso') log(msg.texto, msg.classe); });
  await verificarPEC();
  await renderizarHistorico();
});

function montarUnidades() {
  const div = $('listaUnidades');
  div.innerHTML = '';
  CONFIG.unidadesAPS.forEach((u, i) => {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" checked data-unidade="${i}"> ${u}`;
    div.appendChild(l);
  });
  div.onchange = () => { $('qtdUnidades').textContent = unidadesSelecionadas().length; };
}
const unidadesSelecionadas = () => [...document.querySelectorAll('[data-unidade]')].filter(c => c.checked).map(c => CONFIG.unidadesAPS[+c.dataset.unidade]);

function filtrosPadrao() {
  return {
    grupos: Object.fromEntries(Object.entries(CONFIG.gruposCBO).map(([k, g]) => [k, g.padrao])),
    faltas: Object.fromEntries(CONFIG.tiposFalta.map(t => [t, true]))
  };
}

function log(texto, classe) {
  const li = document.createElement('li');
  li.textContent = `${new Date().toLocaleTimeString('pt-BR')} · ${texto}`;
  if (classe) li.className = classe;
  $('log').appendChild(li);
  $('log').scrollTop = $('log').scrollHeight;
}


// ---------------------------------------------------------------- seleção, estimativa e andamento
const ITENS = () => [...document.querySelectorAll('#secColeta .grupo .corpo input[type=checkbox]')];
const marcar = v => { ITENS().forEach(i => { i.checked = v; }); aoMudarSelecao(); };
function atualizarGrupos() {
  document.querySelectorAll('#secColeta .grupo').forEach(g => {
    const it = [...g.querySelectorAll('.corpo input[type=checkbox]')], n = it.filter(i => i.checked).length, cb = g.querySelector('.gcb');
    cb.checked = n === it.length; cb.indeterminate = n > 0 && n < it.length;
    g.querySelector('.cont').textContent = `${n} de ${it.length}`;
  });
  $('optC7C').disabled = !$('optC7').checked;
}
// Minutos aproximados por item (valores de referência; o tempo real depende do PEC).
const TEMPO = { optMunicipal: [1, 0], optAbsenteismo: [1, 0], optEmulti: [3, 0.3], optB4: [3, 0], optC2: [0, 0.15], optC3: [0, 0.15], optC4: [0, 0.15], optC5: [0, 0.15], optC6: [0, 0.15],
  optC7: [0, 0.3], optC7C: [0, 1.5], optTerritorio: [0, 0.4], optCvat: [0, 1.8], optEscuta: [0, 1], optBucal: [0, 0.8], optCR: [0, 0.2], optComposicao: [0, 0.5], optFilas: [1, 0.3], optFilasHora: [0, 0.2], optVacinas: [0.3, 0], optProducao: [4, 0] };
// Itens que fazem a coleta passar pelas unidades (troca de acesso em cada uma).
const ITENS_UNIDADE = ['optEscuta', 'optC2', 'optC3', 'optC4', 'optC5', 'optC6', 'optC7', 'optTerritorio', 'optCvat', 'optBucal', 'optCR', 'optComposicao', 'optEmulti', 'optB4', 'optFilas', 'optFilasHora'];
// Itens com data no atendimento: o PEC devolve o que aconteceu no período pedido, então valem para meses passados
// (relatórios de produção, atividades coletivas, vacinação e agendas do mês). Os demais (C2 a C7, CR, território,
// CVAT, composição, filas) mostram a situação do cadastro no dia da coleta.
const ITENS_COM_DATA = ['optMunicipal', 'optAbsenteismo', 'optEscuta', 'optBucal', 'optB4', 'optEmulti', 'optVacinas', 'optProducao', 'optFilasHora'];
// Linhas que, mesmo nesse modo, vêm do cadastro de hoje (pessoas vinculadas, divisor de B1 e B4): entram no cálculo,
// mas não vão ao Painel numa coleta retroativa, para não trocar o número do mês pelo de hoje.
const LINHAS_DE_HOJE = ['Q12.2', 'VINC6A12'];
function minutosEstimados(marc, un) {
  const passaUnidades = ITENS_UNIDADE.some(marc);
  let min = 0;
  for (const [id, [fixo, porUn]] of Object.entries(TEMPO)) if (marc(id)) min += fixo + porUn * un;
  min -= 3 * Math.max(0, ['optB4', 'optEmulti', 'optProducao'].filter(marc).length - 1); // a leitura das atividades coletivas é uma só
  if (passaUnidades) min += 0.5 * un; // troca de acesso e recarga da página
  return { min, passaUnidades };
}
function estimar() {
  const marc = id => $(id) && $(id).checked && !$(id).disabled;
  const un = unidadesSelecionadas().length;
  const { min, passaUnidades } = minutosEstimados(marc, un);
  resumirColeta(un, passaUnidades);
  const el = $('estimativa');
  if (!min) { el.textContent = 'Nada marcado.'; return; }
  el.textContent = `${passaUnidades ? un + ' unidades · ' : 'Município inteiro · '}cerca de ${Math.max(1, Math.round(min))} min (estimativa)`;
  lerHistorico().then(h => { const u = h[0]; if (u && u.concluidoEm && u.iniciadoEm) el.textContent += ` · última coleta: ${Math.max(1, Math.round((Date.parse(u.concluidoEm) - Date.parse(u.iniciadoEm)) / 60000))} min`; });
}
// Quadro "o que vai acontecer", logo acima do botão Iniciar coleta.
function resumirColeta(un, passaUnidades) {
  const el = $('resumoColeta'); if (!el) return;
  const marcados = EXTRACAO.ITENS.filter(i => $(i.id) && $(i.id).checked && !$(i.id).disabled);
  if (!marcados.length) { el.textContent = ''; return; }
  const porFin = f => marcados.filter(i => i.finalidade === f).length;
  const unicas = marcados.filter(i => i.escopo === 'municipio').length, porUn = marcados.filter(i => i.escopo !== 'municipio').length;
  const comp = $('competencia').value ? $('competencia').value.split('-').reverse().join('/') : 'competência não escolhida';
  const partes = Object.entries(EXTRACAO.FINALIDADES).map(([f, n]) => porFin(f) ? `${n}: ${porFin(f)}` : '').filter(Boolean).join(' · ');
  const linhas = [`Competência ${comp} · ${passaUnidades ? un + ' unidades' : 'município inteiro'}`, partes,
    `${unicas} ${unicas === 1 ? 'consulta única' : 'consultas únicas'} do município · ${porUn} ${porUn === 1 ? 'item' : 'itens'} com passada por unidade`,
    'Só totais: nenhum nome de paciente, CPF ou prontuário é guardado ou enviado.' + (marcados.some(i => ['optFilas', 'optComposicao', 'optFilasHora', 'optProducao'].includes(i.id)) ? ' Composição, filas e produção levam nome e cargo de profissionais.' : '')];
  el.replaceChildren(...linhas.map(t => { const d = document.createElement('div'); d.textContent = t; return d; }));
  chrome.storage.local.get(['painelUrl', 'painelChave']).then(({ painelUrl, painelChave }) => {
    const d = document.createElement('div'); d.textContent = painelUrl && painelChave ? 'Será enviado ao Painel APS ao terminar.' : 'Sem chave de coleta: o resultado fica só neste computador.'; el.append(d);
  });
}
const id_b4_ou_emulti = () => $('optB4').checked && $('optEmulti').checked;
function aoMudarSelecao() { atualizarGrupos(); estimar(); const sel = {}; ITENS().forEach(i => { sel[i.id] = i.checked; }); chrome.storage.local.set({ selecao: sel }); }
// Selo de modo e custo + ícone ⓘ em cada item, a partir de shared/extracao.js (o mesmo texto da página "Como coletamos" do Painel).
function decorarItens() {
  const ESC = { municipio: 'município', unidade: 'por unidade', ambos: 'município + unidade' };
  for (const it of EXTRACAO.ITENS) {
    const cb = $(it.id); if (!cb) continue;
    const rot = cb.closest('label'), t = TEMPO[it.id] || [0, 0];
    const custo = t[1] > 0 && !t[0] ? `~${String(t[1]).replace('.', ',')} min por unidade` : t[0] && !t[1] ? `~${String(t[0]).replace('.', ',')} min` : t[0] ? `~${String(t[0]).replace('.', ',')} min + ${String(t[1]).replace('.', ',')} por unidade` : '';
    const modo = document.createElement('span'); modo.className = 'modo ' + it.escopo; modo.textContent = ESC[it.escopo] + (custo ? ' · ' + custo : '');
    const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'info'; btn.textContent = 'ⓘ'; btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-label', 'Como é coletado: ' + it.nome);
    const txt = document.createElement('div'); txt.className = 'infotxt'; txt.hidden = true;
    const linha = (r, v) => { const p = document.createElement('p'); const b = document.createElement('b'); b.textContent = r + ': '; p.append(b, v); txt.append(p); };
    linha('Fonte', it.fonte); linha('Como', it.como); linha('Vai ao Painel', it.sai); linha('Dados pessoais', it.pessoal);
    btn.onclick = e => { e.preventDefault(); e.stopPropagation(); txt.hidden = !txt.hidden; btn.setAttribute('aria-expanded', String(!txt.hidden)); };
    rot.append(' ', modo, ' ', btn);
    (rot.closest('.sub') || rot).after(txt);
  }
}

async function iniciarSelecao() {
  decorarItens();
  const { selecao } = await chrome.storage.local.get('selecao');
  if (selecao) ITENS().forEach(i => { if (i.id in selecao) i.checked = selecao[i.id]; });
  document.querySelectorAll('#secColeta .grupo').forEach(g => {
    const corpo = g.querySelector('.corpo'), exp = g.querySelector('.exp');
    exp.onclick = () => { corpo.hidden = !corpo.hidden; exp.setAttribute('aria-expanded', String(!corpo.hidden)); exp.textContent = corpo.hidden ? '▾' : '▴'; };
    g.querySelector('.gcb').onchange = e => { g.querySelectorAll('.corpo input[type=checkbox]').forEach(i => { i.checked = e.target.checked; }); aoMudarSelecao(); };
    corpo.addEventListener('change', aoMudarSelecao);
  });
  $('btnCompleta').onclick = () => marcar(true);
  $('limparTudo').onclick = () => marcar(false);
  $('btnMunicipio').onclick = () => { marcar(false); $('optMunicipal').checked = true; $('optAbsenteismo').checked = true; aoMudarSelecao(); };
  $('btnRecolher').onclick = () => { const abrir = [...document.querySelectorAll('.grupo .corpo')].some(c => c.hidden); document.querySelectorAll('.grupo .exp').forEach(b => { if ((b.getAttribute('aria-expanded') === 'true') !== abrir) b.click(); }); };
  $('listaUnidades').addEventListener('change', estimar); $('competencia').addEventListener('change', estimar);
  atualizarGrupos(); estimar();
}

// Deixa marcadas só as unidades que falharam (e os itens por unidade) para repetir a coleta apenas nelas.
// Ao terminar, devolve as unidades e os itens que estavam marcados antes (a seleção reduzida não fica guardada).
async function refazerFalhas() {
  const falhas = new Set((estado.unidadesErro || []).map(u => UTIL.normalizar(u)));
  const itensAntes = ITENS().map(i => [i, i.checked]);
  const unidadesAntes = [...document.querySelectorAll('[data-unidade]')].map(c => [c, c.checked]);
  const devolver = () => {
    itensAntes.forEach(([i, v]) => { i.checked = v; }); unidadesAntes.forEach(([c, v]) => { c.checked = v; });
    $('qtdUnidades').textContent = unidadesSelecionadas().length; aoMudarSelecao();
  };
  document.querySelectorAll('[data-unidade]').forEach(c => { c.checked = falhas.has(UTIL.normalizar(CONFIG.unidadesAPS[+c.dataset.unidade])); });
  ['optMunicipal', 'optAbsenteismo', 'optColetivas', 'optEmulti', 'optB4', 'optProducao'].forEach(id => { if ($(id)) $(id).checked = false; });
  $('detUnidades').open = true; $('qtdUnidades').textContent = unidadesSelecionadas().length;
  aoMudarSelecao();
  if (!falhas.size) { devolver(); log('Não há unidades com falha para refazer.', 'erro'); return; }
  // O botão já inicia a recoleta (antes só marcava as unidades e esperava um segundo clique em "Iniciar coleta").
  const sel = document.querySelector('input[name="substituir"][value="selecionados"]'); if (sel) sel.checked = true;
  log(`Refazendo só as ${falhas.size} unidades que falharam…`);
  $('btnRefazer').hidden = true;
  try { await coletar(); } finally { devolver(); }
}

// Barra de andamento: cada etapa (consulta municipal, unidade, envio) conta um passo.
const prog = { feito: 0, total: 0, ini: 0 };
function progIniciar(total) {
  Object.assign(prog, { feito: 0, total, ini: Date.now() });
  $('progresso').hidden = false; $('estadoUnidades').innerHTML = ''; $('btnRefazer').hidden = true;
  progAtualizar('Preparando…');
}
function progAtualizar(texto) {
  const pct = prog.total ? Math.round(100 * prog.feito / prog.total) : 0;
  $('barra').value = pct;
  let resto = '';
  if (prog.feito > 0 && prog.feito < prog.total) { const m = Math.max(1, Math.round((Date.now() - prog.ini) / prog.feito * (prog.total - prog.feito) / 60000)); resto = ` · faltam cerca de ${m} min`; }
  $('andamento').textContent = `${pct}% · etapa ${Math.min(prog.feito + 1, prog.total)} de ${prog.total}${resto} — ${texto}`;
}
function progPasso(texto) { prog.feito++; progAtualizar(texto); }
function chipUnidade(unidade, estado) {
  let c = [...$('estadoUnidades').children].find(x => x.dataset.u === unidade);
  if (!c) { c = document.createElement('span'); c.dataset.u = unidade; $('estadoUnidades').appendChild(c); }
  c.className = estado; c.textContent = ({ agora: '⏳ ', ok: '✓ ', aviso: '⚠ ', erro: '✗ ' }[estado] || '') + unidade.replace(/^(ESF|Psf|Usf|UBS|Posto de Saude)\s+/i, '');
  c.title = unidade;
}

// ---------------------------------------------------------------- comunicação com a aba do PEC
async function acharAbaPEC() {
  const abas = await chrome.tabs.query({ url: CONFIG.host + '/*' });
  if (!abas.length) return null;
  return abas.find(a => a.active) || abas[0];
}

function enviarUmaVez(tabId, msg) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, msg, resp => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (resp && resp.erro) return reject(new Error(resp.erro));
      resolve(resp);
    });
  });
}

// A página do PEC recarrega ao trocar de acesso ou abrir relatórios; nesse instante o canal com a extensão cai.
// Nesses casos espera a página voltar (reabrindo o início do PEC se preciso) e tenta de novo, uma vez.
const ERRO_CANAL = /Receiving end does not exist|Could not establish connection|message channel closed|No tab with id/i;
async function enviar(tabId, msg) {
  try { return await enviarUmaVez(tabId, msg); }
  catch (e) {
    if (!ERRO_CANAL.test(e.message) || msg.acao === 'ping') throw e;
    try { await aguardarPronto(tabId, 25000); }
    catch (_) { await voltarAoInicio(tabId); }
    return enviarUmaVez(tabId, msg);
  }
}

// Leva a aba de volta à página inicial do PEC (onde a extensão sempre está ativa) e espera ela ficar pronta.
async function voltarAoInicio(tabId) {
  await chrome.tabs.update(tabId, { url: CONFIG.host + '/' });
  await aguardarPronto(tabId, 90000);
}

async function aguardarPronto(tabId, limiteMs = 90000, caminho) {
  const ini = Date.now();
  await UTIL.dormir(2500);
  while (Date.now() - ini < limiteMs) {
    try {
      const r = await enviar(tabId, { acao: 'ping' });
      if (r && r.pronto && (!caminho || (r.caminho || '').startsWith(caminho))) return r;
    } catch (_) { /* página recarregando */ }
    await UTIL.dormir(1500);
  }
  throw new Error('A página do PEC não respondeu a tempo.');
}

async function verificarPEC() {
  const st = $('status');
  st.className = 'status';
  estado.aba = await acharAbaPEC();
  if (!estado.aba) { st.textContent = 'Abra o PEC (esus.cajamar.sp.gov.br) numa aba e faça login.'; st.classList.add('aviso'); return false; }
  try {
    const r = await enviar(estado.aba.id, { acao: 'ping' });
    if (!r.logado) { st.textContent = 'PEC aberto, mas sem login. Faça login e escolha um acesso.'; st.classList.add('aviso'); return false; }
    st.textContent = `Conectado. Acesso atual: ${r.acesso || 'não identificado'}.`;
    st.classList.add('ok');
    return true;
  } catch (e) {
    st.textContent = 'A aba do PEC precisa ser recarregada (F5) para a extensão funcionar nela.';
    st.classList.add('aviso');
    return false;
  }
}

// ---------------------------------------------------------------- uma coleta por vez
// O PEC tem um só acesso ativo por login. Duas coletas ao mesmo tempo (clique duplo, ou o painel aberto em duas janelas)
// trocam a unidade uma da outra e derrubam as consultas ("Acesso não permitido", "Failed to fetch", canal fechado).
// A trava vale para todos os painéis da extensão: fica em chrome.storage.session, com um sinal de vida a cada 20 s.
// Sem sinal há mais de 3 min, o painel dono foi fechado e a trava pode ser tomada.
const TRAVA = { chave: 'coletaEmAndamento', vidaMs: 20000, validadeMs: 180000, id: null, desde: 0, timer: null };
async function pegarTrava() {
  if (TRAVA.id) { log('Já há uma coleta em andamento neste painel. Espere terminar ou clique em Cancelar.', 'erro'); return false; }
  // Reserva já no clique, antes de qualquer espera: um segundo clique cai na linha acima.
  const id = TRAVA.id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  TRAVA.desde = Date.now();
  $('btnColetar').disabled = true; $('btnRetro').disabled = true;
  const recusar = msg => { TRAVA.id = null; $('btnColetar').disabled = false; $('btnRetro').disabled = false; log(msg, 'erro'); return false; };
  try {
    const { [TRAVA.chave]: t } = await chrome.storage.session.get(TRAVA.chave);
    if (t && t.id !== id && Date.now() - t.batida < TRAVA.validadeMs) {
      const desde = new Date(t.desde).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      return recusar(`Já há uma coleta em andamento em outro painel desta extensão (começou às ${desde}). O PEC só aceita uma unidade por vez: espere terminar ou cancele lá. Se aquele painel foi fechado, a trava se solta sozinha em até 3 minutos.`);
    }
    await chrome.storage.session.set({ [TRAVA.chave]: { id, desde: TRAVA.desde, batida: Date.now() } });
    await UTIL.dormir(150); // dois painéis no mesmo instante: fica quem gravou por último
    const { [TRAVA.chave]: conf } = await chrome.storage.session.get(TRAVA.chave);
    if (!conf || conf.id !== id) return recusar('Outro painel começou uma coleta neste mesmo instante; esta não foi iniciada.');
  } catch (_) { /* sem storage.session: vale ao menos a trava deste painel */ }
  TRAVA.timer = setInterval(() => {
    try { chrome.storage.session.set({ [TRAVA.chave]: { id, desde: TRAVA.desde, batida: Date.now() } }).catch(() => {}); } catch (_) { /* sem storage.session */ }
  }, TRAVA.vidaMs);
  return true;
}
function soltarTrava() {
  const id = TRAVA.id; if (!id) return;
  clearInterval(TRAVA.timer); TRAVA.timer = null; TRAVA.id = null;
  $('btnColetar').disabled = false; $('btnRetro').disabled = false;
  try {
    chrome.storage.session.get(TRAVA.chave).then(({ [TRAVA.chave]: t }) => { if (t && t.id === id) return chrome.storage.session.remove(TRAVA.chave); }).catch(() => {});
  } catch (_) { /* sem storage.session */ }
}
window.addEventListener('pagehide', soltarTrava); // painel fechado no meio: solta a trava na hora

// ---------------------------------------------------------------- nova tentativa
// Repete uma etapa uma vez, depois de uma pausa, quando ela falha por motivo passageiro (rede, página do PEC recarregando,
// relatório que não abriu). "falha" diz se um resultado que voltou sem erro ainda assim falhou (ex.: relatório com aviso).
// Não repete cancelamento nem sessão caída: a segunda tentativa falharia igual.
const NAO_REPETIR = /Sessão do PEC|Coleta cancelada|Você não tem acesso/i;
async function comNovaTentativa(nome, fn, { falha = () => null, esperaMs = 5000 } = {}) {
  let erro;
  try {
    const r = await fn();
    const f = falha(r);
    if (!f) return r;
    erro = Object.assign(new Error(f), { resultado: r });
  } catch (e) {
    if (estado.cancelar || NAO_REPETIR.test(e.message || '')) throw e;
    erro = e;
  }
  log(`${nome}: ${erro.message} Tentando de novo em ${Math.round(esperaMs / 1000)} s…`, 'aviso');
  await UTIL.dormir(esperaMs);
  if (estado.cancelar) { if (erro.resultado) return erro.resultado; throw erro; }
  const r = await fn();
  if (!falha(r)) log(`${nome}: certo na segunda tentativa.`, 'ok');
  return r;
}

// ---------------------------------------------------------------- coleta retroativa
// Meses de "de" a "ate" (AAAA-MM), inclusive.
function mesesEntre(de, ate) {
  const out = []; let [a, m] = de.split('-').map(Number); const [fa, fm] = ate.split('-').map(Number);
  while ((a < fa || (a === fa && m <= fm)) && out.length < 36) { out.push(a + '-' + String(m).padStart(2, '0')); if (++m > 12) { m = 1; a++; } }
  return out;
}
// Coleta um mês por vez: só os itens com data no atendimento (ITENS_COM_DATA) ou tudo o que estiver marcado.
// A trava fica com a retroativa do primeiro ao último mês.
async function coletarRetroativo() {
  if (!(await pegarTrava())) return;
  try { await coletarRetroativoComTrava(); } finally { soltarTrava(); }
}
async function coletarRetroativoComTrava() {
  const de = $('retroDe').value, ate = $('retroAte').value;
  if (!de || !ate || de > ate) { log('Escolha o período retroativo (de ≤ até).', 'erro'); return; }
  if (!(await verificarPEC())) return;
  const meses = mesesEntre(de, ate);
  const modo = (document.querySelector('input[name="retroModo"]:checked') || {}).value || 'producao';
  const subst = (document.querySelector('input[name="substituir"]:checked') || {}).value || 'selecionados';
  if (modo === 'selecao' && !ITENS().some(i => i.checked && !i.disabled)) { log('Marque os itens a coletar (ou escolha "Só dados com data no atendimento").', 'erro'); return; }
  const un = unidadesSelecionadas().length;
  if (modo === 'producao' && !un) { log('Marque ao menos uma unidade: a C1 (escuta inicial), a saúde bucal e as pessoas atendidas pela eMulti são lidas unidade por unidade.', 'erro'); return; }
  const porMes = modo === 'selecao' ? (/cerca de (\d+) min/.exec($('estimativa').textContent) || [])[1]
    : Math.max(1, Math.round(minutosEstimados(id => ITENS_COM_DATA.includes(id), un).min));
  const tempo = porMes ? `\n\nTempo estimado: cerca de ${String(Math.round(porMes * meses.length / 6) / 10).replace('.', ',')} h (${porMes} min por mês, ${un} unidades).` : '';
  const oQue = modo === 'selecao' ? 'todos os itens e unidades marcados'
    : `só os itens com data no atendimento (C1, B1 a B6, M1 e M2, vacinas, produção por profissional, atendimentos, absenteísmo e faltas por horário) em ${un} unidades`;
  const aviso = modo === 'selecao'
    ? '\n\nOs indicadores de situação (C2 a C7, CR, território e CVAT, composição e filas) mostrarão o cadastro do PEC de hoje, não o do mês, e passam por cima do que foi coletado na época.'
    : '\n\nAs pessoas vinculadas (divisor de B1 e B4) vêm do cadastro de hoje: entram só na conta e não trocam o número do mês no Painel.';
  const sub = subst !== 'todos' ? '' : '\n\nModo "substituir todos": em cada mês, só vale o que esta coleta trouxer.'
    + (modo === 'selecao' ? '' : ' Como este modo não traz C2 a C7, CR, território, CVAT, composição e filas, esses itens desses meses saem do Painel. Para mantê-los, cancele e escolha "Atualizar só os itens e unidades marcados".');
  if (!confirm(`Coletar ${meses.length} mês(es), de ${de} a ${ate}, com ${oQue}?${aviso}${sub}${tempo}\n\nCada mês é enviado ao Painel separado. Não feche esta janela nem use a aba do PEC até o fim.`)) return;
  // Guarda a seleção e a competência atuais para devolver depois.
  const guardado = ITENS().map(i => [i, i.checked]);
  const competenciaAntes = $('competencia').value;
  const resultado = [];
  try {
    for (const comp of meses) {
      if (estado.cancelar && resultado.length) break;
      if (modo === 'producao') {
        ITENS().forEach(i => { i.checked = false; });
        ITENS_COM_DATA.forEach(id => { $(id).checked = true; });
        aoMudarSelecao();
      }
      $('competencia').value = comp;
      estado.coletaAtual = null; estado.retro = true; estado.retroModo = modo;
      log(`Retroativo: ${comp} (${resultado.length + 1} de ${meses.length}).`);
      await coletar({ semTrava: true });
      const ok = !!(estado.coletaAtual && estado.coletaAtual.competencia === comp && estado.coletaAtual.concluidoEm) && !(estado.unidadesErro || []).length;
      resultado.push([comp, ok]);
      if (estado.cancelar) break;
    }
  } finally {
    estado.retro = false;
    $('competencia').value = competenciaAntes;
    guardado.forEach(([i, v]) => { i.checked = v; }); aoMudarSelecao();
  }
  const falhas = resultado.filter(r => !r[1]).map(r => r[0]);
  const resumo = `Retroativo: ${resultado.length - falhas.length} de ${meses.length} mês(es) concluído(s).` + (falhas.length ? ` Refazer: ${falhas.join(', ')}.` : '') + (resultado.length < meses.length ? ' Interrompido antes do fim.' : '');
  $('retroInfo').textContent = resumo;
  log(resumo, falhas.length ? 'erro' : 'ok');
}

// ---------------------------------------------------------------- coleta
// "Iniciar coleta" e "Refazer falhas" pegam a trava; a retroativa já a segura e chama com { semTrava: true }.
async function coletar(op) {
  if (op && op.semTrava === true) return coletarCompetencia();
  if (!(await pegarTrava())) return;
  try { await coletarCompetencia(); } finally { soltarTrava(); }
}
async function coletarCompetencia() {
  if (!(await verificarPEC())) return;
  const comp = $('competencia').value;
  if (!comp) { log('Escolha a competência.', 'erro'); return; }
  const tabId = estado.aba.id;
  estado.cancelar = false;
  $('btnColetar').disabled = true; $('btnCancelar').disabled = false;
  $('btnCancelar').textContent = 'Cancelar';
  try { await chrome.tabs.sendMessage(tabId, { acao: 'cancelar', valor: false }); } catch (_) { /* aba ainda carregando */ }
  $('log').innerHTML = '';

  // Substituir todos os dados da competência no Painel: pede confirmação, porque o que esta coleta não trouxer deixa de valer.
  const modoSubst = (document.querySelector('input[name="substituir"]:checked') || {}).value || 'selecionados';
  if (modoSubst === 'todos' && !estado.retro && !confirm(`Substituir todos os dados de ${comp} no Painel APS?\n\nSó vai valer o que esta coleta trouxer. Itens e unidades desmarcados deixam de aparecer para esta competência. Se alguma unidade falhar, os dados anteriores são mantidos.`)) {
    $('btnColetar').disabled = !!TRAVA.id; $('btnCancelar').disabled = true; return;
  }
  const coleta = {
    id: `${comp}-${Date.now()}`, competencia: comp, versao: CONFIG.versao, substituir: modoSubst,
    iniciadoEm: new Date().toISOString(), concluidoEm: null,
    config: { unidadesAPS: CONFIG.unidadesAPS, gruposCBO: CONFIG.gruposCBO, tiposFalta: CONFIG.tiposFalta, substituir: modoSubst },
    cubos: { atendimentos: [], absenteismo: [], escuta: [], coletivas: [], odonto: [], equipes: [] }, linhas: [], avisos: [], observacoes: [],
    escutaUnidades: []
  };
  // Há passagem pelas unidades (troca de acesso) quando algum item "por unidade" está marcado.
  const comUnidades = ITENS_UNIDADE.some(id => $(id).checked);
  const comEscuta = $('optEscuta').checked && comUnidades;
  const comBucal = $('optBucal').checked && comUnidades;
  const comColetivas = $('optB4').checked || $('optEmulti').checked || $('optProducao').checked; // a leitura das atividades serve à B4, à M1/M2 e à produção por profissional
  const temas = { c2: $('optC2').checked, c3: $('optC3').checked, c4: $('optC4').checked, c5: $('optC5').checked, c6: $('optC6').checked, c7: $('optC7').checked, cr: $('optCR').checked };
  // Retroativa só com dados com data: as pessoas vinculadas (cadastro de hoje) servem à conta, mas não vão ao Painel (ver enviarColeta).
  coleta.retroComData = !!(estado.retro && estado.retroModo !== 'selecao');
  if (estado.retro) coleta.observacoes.push(estado.retroModo === 'selecao'
    ? 'Coleta retroativa com todos os itens: os indicadores de situação refletem o cadastro do PEC na data da coleta, não o do mês.'
    : 'Coleta retroativa só com dados com data no atendimento (C1, B1 a B6, M1, M2, vacinas, produção, atendimentos, absenteísmo e faltas por horário). Os divisores de B1 e B4 usam as pessoas vinculadas do cadastro de hoje; os indicadores de situação não foram coletados.');
  log(`Coleta da competência ${comp} iniciada.`);
  estado.unidadesErro = [];
  progIniciar(($('optMunicipal').checked || $('optAbsenteismo').checked ? 1 : 0) + (comColetivas ? 1 : 0) + ($('optEmulti').checked ? 1 : 0) + (comUnidades ? unidadesSelecionadas().length : 0) + 1);

  try {
    // Os relatórios do município só respondem com o acesso de uma unidade de APS ativo
    // (com "Secretaria de Saude" o PEC devolve 403). Troca antes e devolve o acesso original ao final.
    let acessoInicial = null;
    if ($('optMunicipal').checked || $('optAbsenteismo').checked || comColetivas || $('optEmulti').checked || $('optFilas').checked || $('optVacinas').checked || $('optProducao').checked) {
      try {
        acessoInicial = await enviar(tabId, { acao: 'ping' });
        const un = unidadesSelecionadas()[0] || CONFIG.unidadesAPS[0];
        const t = await enviar(tabId, { acao: 'trocarAcesso', unidade: un });
        if (t && t.recarregando) await aguardarPronto(tabId);
        log(`Relatórios do município: usando o acesso de ${un}.`);
      } catch (e) { coleta.avisos.push('Não foi possível selecionar um acesso de unidade para os relatórios do município: ' + e.message); }
    }
    // Atendimentos (C1) e absenteísmo (Q14.2.1) saem dos relatórios gerenciais do município.
    // O absenteísmo também lê os atendimentos, que entram no denominador.
    // coleta.lidos diz o que esta coleta leu: o que não foi lido não vira linha (não passa por cima do Painel).
    const partes = { atendimentos: $('optMunicipal').checked, absenteismo: $('optAbsenteismo').checked };
    coleta.lidos = { atendimentos: false, absenteismo: false };
    if (partes.atendimentos || partes.absenteismo) {
      const nome = partes.atendimentos && partes.absenteismo ? 'Atendimentos e absenteísmo' : partes.atendimentos ? 'Atendimentos (C1)' : 'Absenteísmo (Q14.2.1)';
      progAtualizar(nome.toLowerCase() + ' do município');
      try {
        // O relatório volta com aviso (e não com erro) quando uma das partes falha: o aviso também conta como falha.
        const r = await comNovaTentativa(nome, () => enviar(tabId, { acao: 'municipal', comp, partes }),
          { falha: r => (r.avisos || []).length ? r.avisos.join('; ') + '.' : null });
        coleta.cubos.atendimentos = r.atendimentos || [];
        coleta.cubos.absenteismo = r.absenteismo || [];
        const falhou = p => (r.avisos || []).some(a => a.startsWith(p + ':'));
        coleta.lidos = { atendimentos: !falhou('Atendimentos'), absenteismo: partes.absenteismo && !falhou('Absenteísmo') && !falhou('Atendimentos') };
        (r.avisos || []).forEach(a => coleta.avisos.push(a));
        log(`${nome}: coletado${(r.avisos || []).length ? ' com falha' : ''}.`, (r.avisos || []).length ? 'erro' : 'ok');
      } catch (e) { coleta.avisos.push(`${nome} do município: ${e.message}`); log(`${nome} do município: ${e.message}`, 'erro'); }
      progPasso('município concluído');
    }

    // Filas e faltas: faltas e atendimentos por profissional (médicos e enfermeiros), numa chamada para o município.
    const filas = new Map();
    const chaveFila = p => [UTIL.normalizar(p.unidade), UTIL.normalizar(p.nome), UTIL.codigoCBO(p.cbo)].join('|');
    if ($('optFilas').checked && !estado.cancelar) {
      try {
        const r = await comNovaTentativa('Filas e faltas', () => enviar(tabId, { acao: 'filasMunicipal', comp }));
        (r.profissionais || []).forEach(p => filas.set(chaveFila(p), p));
        log(`Filas e faltas: ${filas.size} profissionais com produção no mês.`, 'ok');
      } catch (e) { coleta.avisos.push('Filas e faltas: ' + e.message); log('Filas e faltas: ' + e.message, 'erro'); }
    }
    // Vacinas (estadual): doses aplicadas do município no mês; vão ao Painel APS como estimativa, separada do lançamento oficial.
    coleta.vacinas = [];
    if ($('optVacinas').checked && !estado.cancelar) {
      try {
        const r = await comNovaTentativa('Vacinas', () => enviar(tabId, { acao: 'vacinas', comp }));
        coleta.vacinas = r.doses || [];
        log(`Vacinas: ${coleta.vacinas.reduce((s, d) => s + d.n, 0)} doses lidas.`, 'ok');
      } catch (e) { coleta.avisos.push('Vacinas: ' + e.message); log('Vacinas: ' + e.message, 'erro'); }
    }
    coleta.filas = filas;
    const filasHorario = [];
    coleta.filasHorario = filasHorario;

    if (comColetivas && !estado.cancelar) {
      progAtualizar('atividades coletivas');
      try {
        log('Atividades coletivas (B4, M1, M2): lendo as atividades do mês; leva alguns minutos…');
        const r = await comNovaTentativa('Atividades coletivas', () => enviar(tabId, { acao: 'coletivas', comp }));
        coleta.cubos.coletivas = r.linhas || [];
        coleta.producaoColetiva = r.porProfissional || [];
        (r.avisos || []).forEach(a => coleta.avisos.push(a));
        log(`Atividades coletivas: ${r.lidas || 0} de ${r.total || 0} lidas.`, 'ok');
      } catch (e) {
        coleta.avisos.push('Atividades coletivas: ' + e.message);
        log('Atividades coletivas: ' + e.message, 'erro');
      }
      progPasso('atividades coletivas concluídas');
    }

    // Produção por profissional (relatório "Produção e notas"): atendimentos individuais do mês, juntados às coletivas.
    coleta.producao = [];
    if ($('optProducao').checked && !estado.cancelar) {
      try {
        const r = await comNovaTentativa('Produção por profissional', () => enviar(tabId, { acao: 'producaoProfissional', comp }));
        coleta.producao = juntarProducao(r.profissionais || [], coleta.producaoColetiva || []);
        log(`Produção por profissional: ${coleta.producao.length} profissionais.`, 'ok');
      } catch (e) { coleta.avisos.push('Produção por profissional: ' + e.message); log('Produção por profissional: ' + e.message, 'erro'); }
    }
    delete coleta.producaoColetiva;

    // eMulti (M1 do quadrimestre e M2 completa). Os resumos ficam só na memória desta coleta.
    let m1 = null;
    if ($('optEmulti').checked && !estado.cancelar) {
      progAtualizar('eMulti (M1 e M2)');
      try {
        log('eMulti (M1 e M2): atendimentos compartilhados e atividades coletivas do quadrimestre; alguns minutos…');
        const sal = [...crypto.getRandomValues(new Uint8Array(16))].map(x => x.toString(16)).join('');
        const r = await comNovaTentativa('eMulti (M1 e M2)', () => enviar(tabId, { acao: 'emultiMunicipal', comp, sal }));
        coleta.cubos.compartilhado = r.compartilhado || [];
        coleta.cubos.cuidado = r.cuidado || [];
        if (r.cuidadoErro) coleta.avisos.push('M2: compartilhamento do cuidado não lido (' + r.cuidadoErro + '); a M2 ficou sem esse componente.');
        coleta.cuidadoLido = !r.cuidadoErro;
        const cq = r.coletivasQuad || {};
        if (cq.documentoNaoLido) coleta.avisos.push('M1: o PEC não devolveu CPF/CNS dos participantes; a conferência de documento ficou desligada e o numerador pode estar acima do real.');
        else if (cq.semDocumento) coleta.observacoes.push(`M1: ${cq.semDocumento} participação(ões) em atividades coletivas sem CPF/CNS válido ficaram de fora, como pede a nota.`);
        m1 = { sal, quad: UTIL.quadrimestreAte(comp).quad, periodo: { inicio: UTIL.quadrimestreAte(comp).inicio, fim: UTIL.quadrimestreAte(comp).fim }, equipes: r.equipes || [], atendQuad: r.atendQuad || {}, coletivasQuad: r.coletivasQuad || {}, ind: {} };
        if (r.coletivasQuad && r.coletivasQuad.falhas) coleta.avisos.push(`M1: ${r.coletivasQuad.falhas} atividades coletivas do quadrimestre não puderam ser lidas.`);
        log(`eMulti: ${(r.coletivasQuad && r.coletivasQuad.total) || 0} atividades coletivas no quadrimestre.`, 'ok');
      } catch (e) {
        coleta.avisos.push('eMulti (M1/M2): ' + e.message);
        log('eMulti (M1/M2): ' + e.message, 'erro');
      }
      progPasso('eMulti concluída');
    }

    if (!comUnidades && acessoInicial && acessoInicial.acessoId) {
      try { await enviar(tabId, { acao: 'restaurarAcesso', acessoId: acessoInicial.acessoId }); } catch (e) {}
    }
    if (comUnidades) {
      const original = acessoInicial || await enviar(tabId, { acao: 'ping' });
      const unidades = unidadesSelecionadas();
      // Uma unidade inteira. Devolve { falhou, sessao } — "sessao" quando o login do PEC caiu (não adianta seguir).
      // Cada passo depois da leitura principal tem sua própria nova tentativa e só grava o resultado se der certo,
      // então uma unidade com ✗ não deixa dados pela metade e pode ser coletada de novo inteira.
      const avisoDaFalha = {};
      const umaUnidade = async (unidade, rotulo, sairDoRelatorio) => {
        log(`${rotulo} ${unidade}: trocando de acesso…`);
        chipUnidade(unidade, 'agora'); progAtualizar(`${unidade} (${rotulo.replace(/[()]/g, '')})`);
        const avisosAntes = coleta.avisos.length;
        try {
          if (sairDoRelatorio) await voltarAoInicio(tabId); // sai do relatório clássico da unidade anterior
          const t = await enviar(tabId, { acao: 'trocarAcesso', unidade });
          if (t && t.recarregando) await aguardarPronto(tabId);
          const r = await enviar(tabId, { acao: 'unidade', comp, unidade, opcoes: { temas, c7ItemC: $('optC7C').checked && $('optC7').checked, territorio: $('optTerritorio').checked, cvat: $('optCvat').checked } });
          coleta.linhas.push(...(r.linhas || []));
          coleta.observacoes.push(...(r.observacoes || []));
          if (m1 && m1.equipes.length) {
            try {
              const p = await comNovaTentativa(`${unidade} · pessoas atendidas pela eMulti`, () => enviar(tabId, { acao: 'emultiUnidade', comp, sal: m1.sal, equipes: m1.equipes }));
              for (const [ine, v] of Object.entries(p)) {
                const o = m1.ind[ine] = m1.ind[ine] || { atendimentos: 0, resumos: new Set() };
                o.atendimentos += v.atendimentos; v.resumos.forEach(x => o.resumos.add(x));
              }
            } catch (err) { coleta.avisos.push(`${unidade}: pessoas atendidas pela eMulti não lidas (${err.message}).`); }
          }
          if ($('optFilas').checked && !estado.cancelar) {
            try {
              const ag = await comNovaTentativa(`${unidade} · agendas`, () => enviar(tabId, { acao: 'agendaUnidade', unidade }));
              (ag.agendas || []).forEach(x => { const k = chaveFila(x); filas.set(k, Object.assign(filas.get(k) || { unidade: x.unidade, equipe: x.equipe, cbo: x.cbo, categoria: x.categoria, nome: x.nome }, { proximaVaga: x.proximaVaga, diasVaga: x.diasVaga, semVaga: x.semVaga, agendaLidaEm: x.agendaLidaEm })); });
            } catch (err) { coleta.avisos.push(`${unidade}: agendas não lidas (${err.message}).`); }
          }
          if ($('optFilasHora').checked && !estado.cancelar) {
            try {
              const fh = await comNovaTentativa(`${unidade} · faltas por horário`, () => enviar(tabId, { acao: 'faltasHorarioUnidade', unidade, comp }));
              (fh.profissionais || []).forEach(x => filasHorario.push(x));
            } catch (err) { coleta.avisos.push(`${unidade}: faltas por horário não lidas (${err.message}).`); }
          }
          (r.avisos || []).forEach(a => coleta.avisos.push(`${unidade}: ${a}`));
          (r.equipes || []).forEach(e => coleta.cubos.equipes.push(Object.assign({ unidade }, e)));

          // Relatórios clássicos: abrir a página do relatório faz parte da tentativa (se ela não abrir, abre de novo).
          const classico = (rota, abrir, acao) => async () => {
            await enviar(tabId, { acao: abrir });
            await aguardarPronto(tabId, 120000, rota);
            return enviar(tabId, acao);
          };
          const ROTA_IND = '/relatorios/producao/atendimento-individual', ROTA_ODONTO = '/relatorios/producao/atendimento-odontologico';
          // Composição: quadro de lotação da unidade (lista de profissionais do relatório clássico).
          if ($('optComposicao').checked && !estado.cancelar) {
            try {
              const lt = await comNovaTentativa(`${unidade} · composição`, classico(ROTA_IND, 'abrirRelatorioClassico', { acao: 'lotacoes' }));
              (coleta.cubos.lotacoes = coleta.cubos.lotacoes || []).push(...(lt.lotacoes || []).map(l => Object.assign({ unidade }, l)));
              log(`${unidade}: ${(lt.lotacoes || []).length} lotações lidas.`);
            } catch (err) { coleta.avisos.push(`${unidade}: composição não lida (${err.message}).`); }
          }
          // CR4 (eCR): itens A, B e C pelo relatório de atendimento individual filtrado por tuberculose.
          const ecr = (r.equipes || []).find(e => String(e.tipo).toUpperCase() === 'ECR' && e.ine);
          const lcr4 = ecr && coleta.linhas.find(l => l.codigo === 'CR4' && l.ine === ecr.ine);
          if (lcr4 && lcr4.denominador > 0 && !estado.cancelar) {
            try {
              const tb = await comNovaTentativa(`${unidade} · CR4`, classico(ROTA_IND, 'abrirRelatorioClassico', { acao: 'tuberculose', comp, unidade, equipe: { ine: ecr.ine, nome: ecr.nome } }));
              Object.assign(lcr4, CALCULO.cr4(lcr4, tb));
            } catch (err) { coleta.avisos.push(`${unidade}: CR4, itens A a C não lidos (${err.message}).`); }
          }
          // Escuta inicial (C1): relatório de atendimento individual por equipe eSF/eAP e categoria.
          if (comEscuta && !estado.cancelar) {
            const equipes = (r.linhas || []).filter(l => l.codigo === 'Q12.2' && CONFIG.c1.tiposEquipe.includes(String(l.tipoEquipe).toUpperCase()) && l.ine)
              .map(l => ({ ine: l.ine, nome: l.equipe }));
            if (equipes.length) {
              try {
                const e = await comNovaTentativa(`${unidade} · escuta inicial`, classico(ROTA_IND, 'abrirRelatorioClassico', { acao: 'escutaInicial', comp, unidade, equipes }));
                coleta.cubos.escuta.push(...(e.linhas || []));
                (coleta.escutaUnidades = coleta.escutaUnidades || []).push(unidade);
                (e.avisos || []).forEach(a => coleta.avisos.push(`${unidade}: ${a}`));
              } catch (err) {
                coleta.avisos.push(`${unidade}: escuta inicial não coletada (${err.message}).`);
                log(`${unidade}: escuta inicial não coletada (${err.message}).`, 'erro');
              }
            }
          }
          // Saúde bucal (B1, B2, B3, B5, B6): relatório de atendimento odontológico por equipe eSB.
          const esb = (r.equipes || []).filter(e => String(e.tipo).toUpperCase() === 'ESB' && e.ine);
          if (comBucal && esb.length && !estado.cancelar) {
            try {
              const o = await comNovaTentativa(`${unidade} · saúde bucal`, classico(ROTA_ODONTO, 'abrirRelatorioOdonto', { acao: 'odontologico', comp, unidade, equipes: esb }));
              coleta.cubos.odonto.push(...(o.linhas || []));
              (o.avisos || []).forEach(a => coleta.avisos.push(`${unidade}: ${a}`));
            } catch (err) {
              coleta.avisos.push(`${unidade}: saúde bucal não coletada (${err.message}).`);
              log(`${unidade}: saúde bucal não coletada (${err.message}).`, 'erro');
            }
          }
          log(`${unidade}: concluída.`, 'ok');
          // Coletada na segunda passada: o aviso da primeira falha passa a dizer isso.
          if (unidade in avisoDaFalha) { coleta.avisos[avisoDaFalha[unidade].i] = `${unidade}: falhou na primeira tentativa (${avisoDaFalha[unidade].msg}) e foi coletada na nova tentativa automática.`; delete avisoDaFalha[unidade]; }
          chipUnidade(unidade, coleta.avisos.length > avisosAntes ? 'aviso' : 'ok');
          return { falhou: false, sessao: false };
        } catch (e) {
          estado.unidadesErro.push(unidade);
          coleta.avisos.push(`${unidade}: ${e.message}`);
          if (!(unidade in avisoDaFalha)) avisoDaFalha[unidade] = { i: coleta.avisos.length - 1, msg: e.message };
          log(`${unidade}: ${e.message}`, 'erro');
          chipUnidade(unidade, 'erro');
          return { falhou: true, sessao: /Sessão do PEC/.test(e.message) };
        }
      };
      const sessaoCaiu = (desde, lista) => {
        const resto = lista.slice(desde);
        resto.forEach(u => { estado.unidadesErro.push(u); chipUnidade(u, 'erro'); });
        if (resto.length) coleta.avisos.push(`Coleta interrompida: sessão do PEC encerrada. Ficaram sem coletar: ${resto.join(', ')}.`);
        log('A sessão do PEC caiu. Entre de novo no PEC e clique em "Refazer falhas" para coletar só o que faltou.', 'erro');
      };
      let caiu = false;
      for (const [i, unidade] of unidades.entries()) {
        if (estado.cancelar) { log('Coleta cancelada.', 'erro'); break; }
        const r = await umaUnidade(unidade, `(${i + 1}/${unidades.length})`, i > 0);
        progPasso(`${unidade} ${r.falhou ? 'com erro' : 'concluída'}`);
        // Sessão caída: as próximas unidades falhariam igual. Para aqui e deixa todas marcadas para refazer.
        if (r.sessao) { sessaoCaiu(i + 1, unidades); caiu = true; break; }
      }
      // Nova tentativa automática: as unidades com ✗ são coletadas de novo, uma vez, antes do envio ao Painel.
      if (!estado.cancelar && !caiu && estado.unidadesErro.length) {
        const refazer = estado.unidadesErro.splice(0);
        prog.total += refazer.length;
        log(`Nova tentativa automática para ${refazer.length} unidade(s) com falha: ${refazer.join(', ')}.`, 'aviso');
        await UTIL.dormir(5000);
        for (const [k, unidade] of refazer.entries()) {
          if (estado.cancelar) { estado.unidadesErro.push(...refazer.slice(k)); log('Coleta cancelada.', 'erro'); break; }
          const r = await umaUnidade(unidade, `(nova tentativa ${k + 1}/${refazer.length})`, true);
          progPasso(`${unidade} ${r.falhou ? 'com erro' : 'concluída'} na nova tentativa`);
          if (r.sessao) { sessaoCaiu(k + 1, refazer); break; }
        }
      }
      if (original && original.acessoId) {
        try {
          await enviar(tabId, { acao: 'restaurarAcesso', acessoId: original.acessoId });
          log(`Acesso original restaurado (${original.acesso || original.acessoId}). Recarregue a página do PEC para o cabeçalho refletir isso.`);
        } catch (e) { log('Não foi possível restaurar o acesso original: ' + e.message, 'erro'); }
      }
    }

    if (m1) {
      try { coleta.linhas.push(...CALCULO.m1(m1, coleta)); } catch (e) { coleta.avisos.push('M1: ' + e.message); }
      m1 = null; // descarta os resumos
    }
    try { coleta.observacoes.push(...CALCULO.observacoesBucal(coleta)); } catch (_) { /* sem atividades */ }
    if ((coleta.cubos.lotacoes || []).length) {
      try {
        coleta.composicao = CALCULO.composicao(coleta);
        coleta.composicao.alertas.forEach(a => coleta.avisos.push('Composição: ' + a));
        for (const u of coleta.composicao.unidades) {
          u.alertas.forEach(a => coleta.avisos.push(`Composição · ${u.nome}: ${a}`));
          u.equipes.forEach(e => e.alertas.forEach(a => coleta.avisos.push(`Composição · ${u.nome} · ${e.nome}: ${a}`)));
        }
        delete coleta.cubos.lotacoes; // a árvore já tem tudo
        await enviarComposicao(coleta);
      } catch (e) { coleta.avisos.push('Composição: ' + e.message); }
    }
    // Conferência dos vínculos eSB → eSF (regra de 40 h de eSB por eSF).
    try { CALCULO.conferirSaudeBucal(coleta).forEach(a => coleta.avisos.push('Saúde bucal: ' + a)); } catch (_) { /* sem dados de equipes */ }
    coleta.concluidoEm = new Date().toISOString();
    registrarCobertura(coleta);
    progAtualizar('enviando ao Painel APS');
    await enviarFilas(coleta);
    await enviarFilasHorario(coleta);
    await enviarVacinas(coleta);
    await enviarProducao(coleta);
    delete coleta.producao; // os nomes dos profissionais não ficam no histórico da extensão
    delete coleta.vacinas;
    delete coleta.filas; // os nomes dos profissionais não ficam no histórico da extensão
    delete coleta.filasHorario;
    await enviarColeta(coleta);
    progPasso('coleta enviada');
    await salvarColeta(coleta);
    if (estado.unidadesErro.length) $('btnRefazer').hidden = false;
    estado.coletaAtual = coleta;
    log('Coleta salva no histórico.', 'ok');
    renderizar();
    await renderizarHistorico();
  } catch (e) {
    log('Erro: ' + e.message, 'erro');
  } finally {
    $('btnColetar').disabled = !!TRAVA.id; $('btnCancelar').disabled = true; $('btnCancelar').textContent = 'Cancelar';
    if (estado.cancelar) chrome.tabs.sendMessage(tabId, { acao: 'cancelar', valor: false }).catch(() => {});
  }
}

// ---------------------------------------------------------------- cálculo
// Gera linhas no nível equipe para todos os indicadores; o nível escolhido é obtido por agregação.
function linhasCalculadas(coleta, filtros) {
  const out = coleta.linhas.map(l => Object.assign({}, l));
  const chaveEq = l => `${l.unidade}|${l.equipe}`;
  const grupoOk = (l, grupos) => !!grupos[l.grupoCBO];

  // Q14.2.1 — faltas ÷ (atendimentos + faltas), com filtros de CBO e tipo de falta.
  // Só com o absenteísmo lido nesta coleta: sem ele, as faltas sairiam zeradas. (Coletas antigas não têm "lidos".)
  const comAbsenteismo = !coleta.lidos || coleta.lidos.absenteismo;
  const acc = new Map();
  for (const a of coleta.cubos.absenteismo) {
    if (!grupoOk(a, filtros.grupos) || !filtros.faltas[a.tipoFalta]) continue;
    const k = chaveEq(a); const o = acc.get(k) || { unidade: a.unidade, equipe: a.equipe, faltas: 0, atend: 0 };
    o.faltas += a.n; acc.set(k, o);
  }
  for (const a of coleta.cubos.atendimentos) {
    if (!grupoOk(a, filtros.grupos)) continue;
    const k = chaveEq(a); const o = acc.get(k) || { unidade: a.unidade, equipe: a.equipe, faltas: 0, atend: 0 };
    o.atend += a.n; acc.set(k, o);
  }
  if (comAbsenteismo) for (const o of acc.values()) out.push({ codigo: 'Q14.2.1', unidade: o.unidade, equipe: o.equipe, numerador: o.faltas, denominador: o.atend + o.faltas });

  // C1 — demanda programada ÷ total, só com os CBOs e tipos de equipe da Nota C1.
  // O tipo de cada equipe vem da coleta por unidade; sem ela, todas as equipes entram.
  const cbosC1 = new Set(CONFIG.c1.cbos);
  const tiposEq = new Map(coleta.linhas.filter(l => l.tipoEquipe).map(l => [UTIL.normalizar(`${l.unidade}|${l.equipe}`), String(l.tipoEquipe).toUpperCase()]));
  // Fica de fora: atendimento sem equipe e equipe cujo tipo conhecido não é eSF/eAP.
  // Equipe de tipo desconhecido entra (os CBOs da nota já excluem ESB e eMulti).
  const equipeOkC1 = a => {
    if (/^sem equipe$/i.test(String(a.equipe || '').trim())) return false;
    const t = tiposEq.get(UTIL.normalizar(`${a.unidade}|${a.equipe}`));
    return !t || CONFIG.c1.tiposEquipe.includes(t);
  };
  const c1 = new Map();
  for (const a of coleta.cubos.atendimentos) {
    if (!cbosC1.has(a.cboCodigo) || !equipeOkC1(a)) continue;
    const k = chaveEq(a); const o = c1.get(k) || { unidade: a.unidade, equipe: a.equipe, prog: 0, total: 0 };
    o.total += a.n;
    const t = UTIL.normalizar(a.tipoAtendimento);
    if (t === 'consulta agendada' || t.startsWith('consulta agendada programada')) o.prog += a.n;
    c1.set(k, o);
  }
  // Escuta inicial (demanda espontânea) lida do relatório de atendimento individual.
  const escuta = coleta.cubos.escuta || [];
  const porNome = new Map([...c1.values()].map(o => [UTIL.normalizar(`${o.unidade}|${o.equipe}`), o]));
  for (const e of escuta) {
    const k = UTIL.normalizar(`${e.unidade}|${e.equipe}`);
    let o = porNome.get(k);
    if (!o) { o = { unidade: e.unidade, equipe: e.equipe, prog: 0, total: 0 }; porNome.set(k, o); c1.set(`${e.unidade}|${e.equipe}`, o); }
    o.total += e.escuta || 0;
    o.escuta = (o.escuta || 0) + (e.escuta || 0);
  }
  // A C1 precisa da escuta inicial (demanda espontânea) da mesma unidade: sem ela, o denominador fica menor e a C1 sai acima do real.
  // Unidade sem escuta lida nesta coleta não gera C1 (no Painel continua a da coleta anterior). Coletas antigas não têm a lista.
  const comEscuta = coleta.escutaUnidades ? new Set(coleta.escutaUnidades.map(u => UTIL.normalizar(u))) : null;
  for (const o of c1.values()) {
    if (comEscuta && !comEscuta.has(UTIL.normalizar(o.unidade))) continue;
    out.push({ codigo: 'C1', unidade: o.unidade, equipe: o.equipe, numerador: o.prog, denominador: o.total, escuta: o.escuta || 0 });
  }
  out.push(...CALCULO.saudeBucal(coleta));
  out.push(...CALCULO.emulti(coleta));
  out.push(...CALCULO.coletivasEquipes(coleta));
  return out;
}

function agregarNivel(linhas, nivel) {
  const grupos = new Map();
  for (const l of linhas) {
    const k = [l.codigo, nivel === 'municipio' ? '' : l.unidade, nivel === 'equipe' ? l.equipe : ''].join('|');
    const g = grupos.get(k) || { codigo: l.codigo, unidade: nivel === 'municipio' ? 'Município' : l.unidade, equipe: nivel === 'equipe' ? l.equipe : '', numerador: 0, denominador: 0, somaPontos: 0, valor: 0 };
    g.numerador += l.numerador || 0;
    g.denominador += l.denominador || 0;
    g.somaPontos += l.somaPontos || 0;
    g.valor += l.valor || 0;
    g.fontes = (g.fontes || 0) + 1; if (l.faixa) g.faixa = l.faixa;
    grupos.set(k, g);
  }
  // C7: a nota sai dos itens já agregados no mesmo nível (Σ cumpridas ÷ faixa × peso).
  const itensC7 = new Map();
  for (const g of grupos.values()) {
    const m = /^C7-([ABCD])$/.exec(g.codigo);
    if (!m) continue;
    const k = `${g.unidade}|${g.equipe}`;
    const o = itensC7.get(k) || { unidade: g.unidade, equipe: g.equipe, itens: {} };
    o.itens[m[1]] = [g.numerador, g.denominador];
    itensC7.set(k, o);
  }
  for (const o of itensC7.values()) {
    const r = INDICADORES_C7.nota(o.itens);
    grupos.set(`C7|${o.unidade}|${o.equipe}`, { codigo: 'C7', unidade: o.unidade, equipe: o.equipe, numerador: 0, denominador: 0, somaPontos: 0, valor: r.nota, resultadoDireto: r.nota });
  }
  // CVAT: escore do cadastro (até 3) + escore do acompanhamento (até 7), pelas faixas da NT 30/2025.
  const cvat = new Map();
  for (const g of grupos.values()) {
    if (g.codigo !== 'CVAT-CAD' && g.codigo !== 'CVAT-ACO') continue;
    const k = `${g.unidade}|${g.equipe}`;
    const o = cvat.get(k) || { unidade: g.unidade, equipe: g.equipe };
    o[g.codigo] = g; cvat.set(k, o);
  }
  for (const o of cvat.values()) {
    if (!o['CVAT-CAD'] || !o['CVAT-ACO']) continue;
    const r = CALCULO.notaCvat(o['CVAT-CAD'], o['CVAT-ACO']);
    grupos.set(`CVAT|${o.unidade}|${o.equipe}`, { codigo: 'CVAT', unidade: o.unidade, equipe: o.equipe, numerador: 0, denominador: 0, somaPontos: 0, valor: r.nota, resultadoDireto: r.nota, escores: r });
  }
  return [...grupos.values()].map(g => {
    if (g.resultadoDireto !== undefined) { g.resultado = g.resultadoDireto; return g; }
    const tipo = (CATALOGO[g.codigo] || {}).tipo;
    if (tipo === 'pontos') g.resultado = g.denominador ? g.somaPontos / g.denominador : null;
    else if (tipo === 'percentual') g.resultado = g.denominador ? 100 * g.numerador / g.denominador : null;
    else if (tipo === 'razao') g.resultado = g.denominador ? g.numerador / g.denominador : null;
    else g.resultado = g.valor;
    return g;
  }).sort((a, b) => a.codigo.localeCompare(b.codigo, 'pt', { numeric: true }) || a.unidade.localeCompare(b.unidade) || a.equipe.localeCompare(b.equipe));
}

const fmt = (n, casas = 1) => n === null || n === undefined || isNaN(n) ? '—' : Number(n).toLocaleString('pt-BR', { maximumFractionDigits: casas, minimumFractionDigits: casas });

// ---------------------------------------------------------------- exibição
function renderizar() {
  const c = estado.coletaAtual;
  if (!c) return;
  $('secResultado').hidden = false;
  $('resComp').textContent = c.competencia;
  montarFiltrosQ14();
  const nivel = $('nivel').value;
  const linhas = agregarNivel(linhasCalculadas(c, estado.filtros), nivel);
  const t = $('tabela');
  const local = nivel === 'municipio' ? 'Abrangência' : nivel === 'equipe' ? 'Unidade · equipe' : 'Unidade';
  let html = `<thead><tr><th>${local}</th><th class="num">Num.</th><th class="num">Den.</th><th class="num">Result.</th></tr></thead><tbody>`;
  // excluídos por indicador (ex.: gestações acima de 42 semanas)
  const excl = {};
  for (const l of c.linhas) if (l.excluidos) excl[l.codigo] = (excl[l.codigo] || 0) + l.excluidos;
  let ultimo = '';
  for (const l of linhas) {
    const cat = CATALOGO[l.codigo] || { nome: l.codigo, tipo: '' };
    if (l.codigo !== ultimo) {
      const notaCat = l.codigo === 'C1' && !((c.cubos && c.cubos.escuta) || []).length ? 'sem escuta inicial no denominador (não coletada)' : (cat.nota || '');
      const nota = [cat.meta ? `meta ${cat.meta}` : '', notaCat,excl[l.codigo] ? `${excl[l.codigo]} registro(s) fora do período desconsiderado(s)` : ''].filter(Boolean).join(' · ');
      const esc = t => String(t).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
      const info = cat.margem ? ` <span class="info" title="${esc((cat.precisao === 'piso' ? 'Piso: o valor real é igual ou maior. ' : cat.precisao === 'aproximado' ? 'Aproximado. ' : '') + cat.margem)}">i</span>` : '';
      html += `<tr class="grupo"><td colspan="4">${l.codigo} · ${cat.nome}${info}${nota ? ` <small>(${nota})</small>` : ''}</td></tr>`;
      ultimo = l.codigo;
    }
    const semNumDen = cat.tipo === 'contagem' || cat.tipo === 'nota';
    const num = cat.tipo === 'pontos' ? fmt(l.somaPontos, 0) : semNumDen ? '' : fmt(l.numerador, 0);
    const res = cat.tipo === 'percentual' ? fmt(l.resultado) + '%' : cat.tipo === 'razao' ? fmt(l.resultado, 2) : (cat.tipo === 'pontos' || cat.tipo === 'nota') ? fmt(l.resultado) : fmt(l.resultado, 0);
    const faixa = l.faixa && l.fontes === 1 ? ` <small>(${fmt(l.faixa[0], cat.tipo === 'razao' ? 2 : 1)} a ${fmt(l.faixa[1], cat.tipo === 'razao' ? 2 : 1)})</small>` : '';
    const onde = nivel === 'municipio' ? 'Município' : nivel === 'equipe' ? `${l.unidade}<br><small>${l.equipe || ''}</small>` : l.unidade;
    html += `<tr><td>${onde}</td><td class="num">${num}</td><td class="num">${semNumDen ? '' : fmt(l.denominador, 0)}</td><td class="num"><strong>${res}</strong>${faixa}</td></tr>`;
  }
  t.innerHTML = html + '</tbody>';
  const av = $('avisos');
  av.innerHTML = (c.avisos || []).map(a => `<li>${a}</li>`).join('');
  av.hidden = !(c.avisos || []).length;
}

function montarFiltrosQ14() {
  const c = $('filtrosCBO'), f = $('filtrosFalta');
  if (c.childElementCount) return;
  c.innerHTML = '<strong>Grupos de CBO</strong>';
  for (const [k, g] of Object.entries(CONFIG.gruposCBO)) {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" ${estado.filtros.grupos[k] ? 'checked' : ''}> ${g.rotulo}`;
    l.querySelector('input').onchange = e => { estado.filtros.grupos[k] = e.target.checked; renderizar(); };
    c.appendChild(l);
  }
  f.innerHTML = '<strong>Tipo de falta</strong>';
  for (const t of CONFIG.tiposFalta) {
    const l = document.createElement('label');
    l.innerHTML = `<input type="checkbox" ${estado.filtros.faltas[t] ? 'checked' : ''}> ${t.charAt(0) + t.slice(1).toLowerCase()}`;
    l.querySelector('input').onchange = e => { estado.filtros.faltas[t] = e.target.checked; renderizar(); };
    f.appendChild(l);
  }
}

// ---------------------------------------------------------------- histórico e exportação
// Envio da composição ao Painel APS (endereço e chave ficam só neste navegador, em chrome.storage).
// Filas e faltas: envia os totais por profissional (médicos e enfermeiros). O Painel junta com o que já tinha do mês.
async function enviarFilas(coleta) {
  const lista = !coleta.filas ? [] : Array.isArray(coleta.filas) ? coleta.filas : [...coleta.filas.values()];
  if (!lista.length) return;
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Filas e faltas: Painel APS não configurado para envio.'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/filas', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave }, body: JSON.stringify({ competencia: coleta.competencia, profissionais: lista }) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    log(`Filas e faltas: ${lista.length} profissionais enviados ao Painel APS.`, 'ok');
  } catch (e) { coleta.avisos.push('Filas e faltas não enviadas ao Painel APS: ' + e.message); log('Filas e faltas não enviadas ao Painel APS: ' + e.message, 'erro'); }
}

// Junta a produção individual (relatório gerencial) com a coletiva (atividades) do mesmo profissional.
// Chave: unidade + equipe + CBO + nome. Se a equipe vier escrita de outro jeito, tenta unidade + CBO + nome (quando único).
function juntarProducao(individuais, coletivas) {
  const N = UTIL.normalizar;
  const chave = p => [N(p.unidade), N(p.equipe), UTIL.codigoCBO(p.cbo), N(p.nome)].join('|');
  const curta = p => [N(p.unidade), UTIL.codigoCBO(p.cbo), N(p.nome)].join('|');
  const out = new Map(), porCurta = new Map();
  const zero = { individuais: 0, compartilhados: 0, porTipo: {}, coletivasResponsavel: 0, coletivasEnvolvido: 0, participacoes: 0 };
  for (const p of individuais) {
    const o = Object.assign({}, zero, p, { ine: p.ine || '' });
    out.set(chave(p), o);
    const k = curta(p); porCurta.set(k, porCurta.has(k) ? null : o);
  }
  for (const p of coletivas) {
    let o = out.get(chave(p)) || porCurta.get(curta(p));
    if (!o) { o = Object.assign({}, zero, { unidade: p.unidade, equipe: p.equipe, ine: p.ine, cbo: p.cbo, cboNome: p.cboNome, nome: p.nome }); out.set(chave(p), o); }
    o.ine = o.ine || p.ine; o.cboNome = o.cboNome || p.cboNome;
    o.coletivasResponsavel += p.coletivasResponsavel; o.coletivasEnvolvido += p.coletivasEnvolvido; o.participacoes += p.participacoes;
  }
  return [...out.values()];
}

// Produção por profissional: envia ao Painel APS. O Painel troca a produção do mês pela recebida.
async function enviarProducao(coleta) {
  const lista = Array.isArray(coleta.producao) ? coleta.producao : [];
  if (!lista.length) return;
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Produção por profissional: Painel APS não configurado para envio.'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/producao', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave },
      body: JSON.stringify({ competencia: coleta.competencia, profissionais: lista }) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    log(`Produção por profissional: ${lista.length} profissionais enviados ao Painel APS.`, 'ok');
  } catch (e) { coleta.avisos.push('Produção por profissional não enviada ao Painel APS: ' + e.message); log('Produção por profissional não enviada ao Painel APS: ' + e.message, 'erro'); }
}

// Vacinas: envia as doses aplicadas do mês (só totais). O Painel troca as doses do mês.
async function enviarVacinas(coleta) {
  const lista = Array.isArray(coleta.vacinas) ? coleta.vacinas : [];
  if (!lista.length) return;
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Vacinas: Painel APS não configurado para envio.'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/vacinas-pec', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave },
      body: JSON.stringify({ competencia: coleta.competencia, doses: lista }) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    log(`Vacinas: ${lista.length} linhas de doses enviadas ao Painel APS.`, 'ok');
  } catch (e) { coleta.avisos.push('Vacinas não enviadas ao Painel APS: ' + e.message); log('Vacinas não enviadas ao Painel APS: ' + e.message, 'erro'); }
}

// Faltas por horário: envia a grade "dia da semana × hora" de cada profissional. O Painel troca a grade do mês.
async function enviarFilasHorario(coleta) {
  const lista = Array.isArray(coleta.filasHorario) ? coleta.filasHorario : [];
  if (!lista.length) return;
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Faltas por horário: Painel APS não configurado para envio.'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/filas/horarios', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave },
      body: JSON.stringify({ competencia: coleta.competencia, profissionais: lista.map(p => ({ unidade: p.unidade, equipe: p.equipe, cbo: p.cbo, categoria: p.categoria, nome: p.nome, grade: p.grade })) }) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const tot = lista.reduce((t, p) => ({ a: t.a + p.atendidos, f: t.f + p.faltas }), { a: 0, f: 0 });
    log(`Faltas por horário: ${lista.length} profissionais enviados ao Painel APS (${tot.f} faltas em ${tot.a + tot.f} consultas com desfecho).`, 'ok');
  } catch (e) { coleta.avisos.push('Faltas por horário não enviadas ao Painel APS: ' + e.message); log('Faltas por horário não enviadas ao Painel APS: ' + e.message, 'erro'); }
}

async function enviarComposicao(coleta) {
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Composição guardada na coleta (Painel APS não configurado para envio).'); return; }
  try {
    const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1/composicao', { method: 'PUT',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave }, body: JSON.stringify(coleta.composicao) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    log('Composição enviada ao Painel APS.', 'ok');
  } catch (e) { coleta.avisos.push('Composição não enviada ao Painel APS: ' + e.message); log('Composição não enviada ao Painel APS: ' + e.message, 'erro'); }
}

// Envio completo da coleta ao Painel APS: abre a coleta, grava as etapas (idempotente) e conclui.
// As linhas enviadas já incluem os indicadores calculados no nível equipe; os cubos vão em lotes.
async function painelFetch(caminho, metodo, corpo) {
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  const r = await fetch(painelUrl.replace(/\/+$/, '') + '/api/v1' + caminho, { method: metodo,
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + painelChave }, body: JSON.stringify(corpo) });
  if (!r.ok) { let m = ''; try { m = (await r.json()).erro || ''; } catch (_) { /* sem corpo */ } throw new Error(`HTTP ${r.status}${m ? ' – ' + m : ''}`); }
  return r.json();
}

async function enviarColeta(coleta) {
  const { painelUrl, painelChave } = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  if (!painelUrl || !painelChave) { log('Indicadores guardados só neste computador (envio ao Painel APS não configurado).'); return; }
  const aviso = m => { coleta.avisos.push(m); log(m, 'erro'); };
  try {
    await painelFetch('/coletas', 'POST', { id: coleta.id, competencia: coleta.competencia, tipo: 'completa', versaoExtensao: coleta.versao,
      iniciadoEm: coleta.iniciadoEm, config: coleta.config });
  } catch (e) { aviso('Coleta não enviada ao Painel APS: ' + e.message); return; }

  const etapas = [];
  const porUnidade = new Map();
  const linhas = linhasCalculadas(coleta, filtrosPadrao())
    .filter(l => !(coleta.retroComData && LINHAS_DE_HOJE.includes(l.codigo)))
    .map(l => Object.assign({}, l, { unidade: l.unidade || 'Município', equipe: l.equipe || 'Município' }));
  for (const l of linhas) { if (!porUnidade.has(l.unidade)) porUnidade.set(l.unidade, []); porUnidade.get(l.unidade).push(l); }
  for (const [unidade, ls] of porUnidade) etapas.push({ chave: 'unidade:' + unidade, bloco: 'unidade', unidade, linhas: ls });
  const lote = (lista, n = 10000) => { const o = []; for (let i = 0; i < lista.length; i += n) o.push(lista.slice(i, i + n)); return o; };
  lote(coleta.cubos.atendimentos || []).forEach((l, i) => etapas.push({ chave: 'cubo-atendimentos:' + (i + 1), bloco: 'cubos', cubos: { atendimentos: l } }));
  lote(coleta.cubos.absenteismo || []).forEach((l, i) => etapas.push({ chave: 'cubo-absenteismo:' + (i + 1), bloco: 'cubos', cubos: { absenteismo: l } }));
  lote(coleta.cubos.escuta || []).forEach((l, i) => etapas.push({ chave: 'cubo-escuta:' + (i + 1), bloco: 'cubos', cubos: { escuta: l } }));
  etapas.push({ chave: 'avisos', bloco: 'avisos', avisos: coleta.avisos.slice(0, 500) });

  let falhas = 0;
  for (const et of etapas) {
    let ok = false, erro = '';
    for (let t = 1; t <= 3 && !ok; t++) {
      try { await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/etapa`, 'PUT', Object.assign({ status: 'ok', coletadoEm: coleta.iniciadoEm, tentativas: t }, et)); ok = true; }
      catch (e) { erro = e.message; await UTIL.dormir(1500 * t); }
    }
    if (!ok) { falhas++; log(`Etapa "${et.chave}" não enviada: ${erro}`, 'erro'); coleta.avisos.push(`Painel APS: etapa "${et.chave}" não enviada (${erro}).`);
      try { await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/etapa`, 'PUT', { chave: et.chave, bloco: et.bloco, unidade: et.unidade, status: 'falhou', erro, coletadoEm: coleta.iniciadoEm }); } catch (_) { /* sem rede */ } }
  }
  try {
    const completa = !falhas && !estado.cancelar && !(estado.unidadesErro || []).length;
    const substituir = coleta.substituir === 'todos' && completa;
    if (coleta.substituir === 'todos' && !completa)
      log('Coleta incompleta: os dados anteriores desta competência foram mantidos e só o que veio agora foi atualizado. Para substituir tudo, colete de novo sem falhas.', 'erro');
    const r = await painelFetch(`/coletas/${encodeURIComponent(coleta.id)}/concluir`, 'POST', { status: falhas || estado.cancelar ? 'parcial' : 'concluida', concluidoEm: new Date().toISOString(), substituir: substituir ? 'todos' : 'selecionados' });
    if (r.substituidas) log(`Dados anteriores de ${coleta.competencia} substituídos no Painel APS (${r.substituidas} etapas antigas deixaram de valer).`, 'ok');
    coleta.enviadoEm = new Date().toISOString();
    log(`Coleta enviada ao Painel APS (${r.etapas.ok} etapas ok${r.etapas.falhas ? ', ' + r.etapas.falhas + ' com falha' : ''}).`, falhas ? 'erro' : 'ok');
  } catch (e) { aviso('Coleta não concluída no Painel APS: ' + e.message); }
}
document.addEventListener('DOMContentLoaded', async () => {
  const u = $('painelUrl'), k = $('painelChave'); if (!u || !k) return;
  const v = await chrome.storage.local.get(['painelUrl', 'painelChave']);
  u.value = v.painelUrl || 'https://painelaps.pages.dev'; k.value = v.painelChave || '';
  const salvar = () => chrome.storage.local.set({ painelUrl: u.value.trim(), painelChave: k.value.trim() });
  u.addEventListener('change', salvar); k.addEventListener('change', salvar);
});

async function lerHistorico() { return (await chrome.storage.local.get('coletas')).coletas || []; }
async function salvarColeta(c) { const h = await lerHistorico(); h.unshift(c); await chrome.storage.local.set({ coletas: h }); }

async function renderizarHistorico() {
  const h = await lerHistorico();
  const ul = $('historico');
  ul.innerHTML = h.length ? '' : '<li><small>Nenhuma coleta ainda.</small></li>';
  for (const c of h) {
    const li = document.createElement('li');
    const quando = new Date(c.iniciadoEm).toLocaleString('pt-BR');
    li.innerHTML = `<span><strong>${c.competencia}</strong> <small>coletado em ${quando}${c.avisos.length ? ` · ${c.avisos.length} aviso(s)` : ''}</small></span>
      <span class="acoes"><button class="sec" data-a="ver">Ver</button><button class="sec" data-a="inc" title="Relatório de inconsistências em PDF">Inconsistências</button><button class="sec" data-a="excluir">Excluir</button></span>`;
    li.querySelector('[data-a="ver"]').onclick = () => { estado.coletaAtual = c; renderizar(); $('secResultado').scrollIntoView(); };
    li.querySelector('[data-a="inc"]').onclick = () => abrirInconsistencias(c);
    const bx = li.querySelector('[data-a="excluir"]');
    bx.onclick = async () => {
      if (bx.dataset.confirmar !== '1') { bx.dataset.confirmar = '1'; bx.textContent = 'Confirmar'; return; }
      await chrome.storage.local.set({ coletas: (await lerHistorico()).filter(x => x.id !== c.id) });
      renderizarHistorico();
    };
    ul.appendChild(li);
  }
}

function baixar(nome, conteudo, tipo) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([conteudo], { type: tipo }));
  a.download = nome; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

function exportarJSON(c) {
  if (!c) return;
  const pacote = Object.assign({}, c, {
    indicadores: ['municipio', 'unidade', 'equipe'].flatMap(n => agregarNivel(linhasCalculadas(c, filtrosPadrao()), n).map(l => Object.assign({ nivel: n }, l)))
  });
  baixar(`indicadores-aps-${c.competencia}.json`, JSON.stringify(pacote, null, 2), 'application/json');
}

function exportarCSV(c) {
  if (!c) return;
  const linhas = ['municipio', 'unidade', 'equipe'].flatMap(n => agregarNivel(linhasCalculadas(c, filtrosPadrao()), n).map(l => Object.assign({ nivel: n }, l)));
  const cab = ['competencia', 'nivel', 'codigo', 'indicador', 'unidade', 'equipe', 'numerador', 'denominador', 'soma_pontos', 'resultado'];
  const esc = v => `"${String(v === null || v === undefined ? '' : v).replace(/"/g, '""')}"`;
  const corpo = linhas.map(l => [c.competencia, l.nivel, l.codigo, (CATALOGO[l.codigo] || {}).nome || '', l.unidade, l.equipe, l.numerador, l.denominador, l.somaPontos,
    l.resultado === null ? '' : String(+l.resultado.toFixed(2)).replace('.', ',')].map(esc).join(';'));
  baixar(`indicadores-aps-${c.competencia}.csv`, '﻿' + [cab.join(';'), ...corpo].join('\n'), 'text/csv');
}


// ---------- Relatório de inconsistências (PDF) ----------
// Guarda, junto da coleta, só contagens por unidade (nenhum nome de profissional), para poder apontar o que ficou faltando.
function registrarCobertura(coleta) {
  const contar = (lista, filtro) => {
    const m = {};
    for (const x of lista) { if (filtro && !filtro(x)) continue; m[x.unidade] = (m[x.unidade] || 0) + 1; }
    return m;
  };
  const filas = !coleta.filas ? [] : Array.isArray(coleta.filas) ? coleta.filas : [...coleta.filas.values()];
  coleta.cobertura = {
    unidadesPlanejadas: unidadesSelecionadas(),
    unidadesComErro: [...new Set(estado.unidadesErro || [])],
    opcoes: { filas: !!$('optFilas').checked, horario: !!$('optFilasHora').checked, composicao: !!$('optComposicao').checked },
    filasPorUnidade: contar(filas),
    agendaPorUnidade: contar(filas, p => p.agendaLidaEm || p.diasVaga != null || p.semVaga),
    horarioPorUnidade: contar(Array.isArray(coleta.filasHorario) ? coleta.filasHorario : []),
    composicaoUnidades: ((coleta.composicao && coleta.composicao.unidades) || []).map(u => u.nome)
  };
}

const SEM_REGRA_100 = new Set(['CVAT-ACO', 'CVAT-CAD', 'B4']);     // CVAT: "piso" (o PEC só dá a data do último atendimento); B4: a nota não exige que a criança seja vinculada à equipe, então passa de 100%
const OPCIONAIS = /^(CR\d|M1$|M2$|B[1-6]$)/;                      // dependem do tipo de equipe da unidade

function montarInconsistencias(c) {
  const cob = c.cobertura || null;
  const norm = x => UTIL.normalizar(x);
  const achados = []; // { nivel: erro|atencao|info, unidade, tema, texto }
  const add = (nivel, unidade, tema, texto) => achados.push({ nivel, unidade: unidade || 'Geral', tema, texto });

  const planejadas = cob ? cob.unidadesPlanejadas : [...new Set(c.linhas.map(l => l.unidade))];
  const nomeDe = u => planejadas.find(p => norm(p) === norm(u)) || u;
  const falhou = new Set((cob ? cob.unidadesComErro : []).map(norm));

  // 1) Unidades com a coleta interrompida
  for (const u of (cob ? cob.unidadesComErro : [])) {
    const motivos = c.avisos.filter(a => norm(a).startsWith(norm(u) + ':')).map(a => a.slice(a.indexOf(':') + 1).trim());
    add('erro', u, 'Coleta da unidade', 'A coleta desta unidade não foi concluída' + (motivos.length ? ': ' + [...new Set(motivos)].join('; ') : '.') + ' Use "Refazer só as que falharam".');
  }

  // 2) Indicadores por unidade
  let linhasUn = [];
  try { linhasUn = agregarNivel(linhasCalculadas(c, filtrosPadrao()), 'unidade').filter(l => l.unidade && l.unidade !== 'Município'); } catch (_) { /* sem cálculo */ }
  const porUn = new Map();
  for (const l of linhasUn) { const k = norm(l.unidade); if (!porUn.has(k)) porUn.set(k, { nome: l.unidade, cods: new Map() }); porUn.get(k).cods.set(l.codigo, l); }
  const comDados = [...porUn.values()];
  const freq = {};
  comDados.forEach(u => u.cods.forEach((_, cod) => { if (cod !== 'COLET') freq[cod] = (freq[cod] || 0) + 1; })); // COLET é auxiliar (totais de produção): não entra nas conferências
  const limite = Math.max(2, Math.ceil(comDados.length * 0.6));
  const esperados = Object.keys(freq).filter(cod => freq[cod] >= limite && !OPCIONAIS.test(cod));
  const opcionais = Object.keys(freq).filter(cod => OPCIONAIS.test(cod));

  for (const u of planejadas) {
    if (falhou.has(norm(u))) continue;
    const d = porUn.get(norm(u));
    if (!d) { add('erro', u, 'Indicadores', 'Nenhum indicador por unidade foi coletado.'); continue; }
    const faltam = esperados.filter(cod => !d.cods.has(cod)).sort();
    if (faltam.length) add('atencao', u, 'Indicadores ausentes', `Não coletados (presentes na maioria das unidades): ${faltam.join(', ')}.`);
    const faltaOpc = opcionais.filter(cod => !d.cods.has(cod)).sort();
    if (faltaOpc.length) add('info', u, 'Indicadores opcionais', `Sem dados de: ${faltaOpc.join(', ')}. Pode ser normal se a unidade não tem esse tipo de equipe (odontologia, eMulti, eCR).`);
  }

  // 3) Valores suspeitos
  const NOTAS = { B2: 'O indicador conta registros sem vincular à primeira consulta; sem faixa oficial', B4: 'O denominador vem de VINC6A12 (crianças de 6 a 12 anos vinculadas), lido na coleta por unidade' };
  for (const d of comDados) {
    for (const l of d.cods.values()) {
      if (l.resultadoDireto !== undefined || l.somaPontos || l.codigo === 'COLET') continue;
      const num = l.numerador || 0, den = l.denominador || 0;
      if (den === 0 && num > 0) add('atencao', d.nome, 'Valores suspeitos', `${l.codigo}: numerador ${num} com denominador 0 (resultado indisponível).${NOTAS[l.codigo] ? ' ' + NOTAS[l.codigo] + '.' : ''}`);
      else if (den > 0 && num > den) add(SEM_REGRA_100.has(l.codigo) ? 'info' : 'atencao', d.nome, 'Valores suspeitos', `${l.codigo}: numerador ${num} maior que o denominador ${den} (${(100 * num / den).toFixed(1).replace('.', ',')}%).${SEM_REGRA_100.has(l.codigo) ? (l.codigo === 'B4' ? ' Esperado: pela nota, a criança do numerador não precisa estar vinculada à equipe.' : ' Esperado: é um índice por piso.') : NOTAS[l.codigo] ? ' ' + NOTAS[l.codigo] + '.' : ''}`);
    }
  }

  // 4) Filas, horários e composição
  if (cob) {
    for (const u of planejadas) {
      if (falhou.has(norm(u))) continue;
      const na = (m) => Object.entries(m || {}).filter(([k]) => norm(k) === norm(u)).reduce((t, [, n]) => t + n, 0);
      if (cob.opcoes.filas && !na(cob.filasPorUnidade)) add('atencao', u, 'Filas e faltas', 'Nenhum médico ou enfermeiro com produção ou agenda lido.');
      if (cob.opcoes.filas && na(cob.filasPorUnidade) && !na(cob.agendaPorUnidade)) add('atencao', u, 'Filas e faltas', 'Profissionais lidos, mas nenhuma agenda (dias até a próxima vaga).');
      if (cob.opcoes.horario && !na(cob.horarioPorUnidade)) add('atencao', u, 'Faltas por horário', 'Nenhuma grade de horários lida.');
      if (cob.opcoes.composicao && !cob.composicaoUnidades.some(n => norm(n) === norm(u))) add('atencao', u, 'Composição', 'Unidade fora do quadro de composição desta coleta.');
    }
  }

  // 5) Demais avisos da coleta (os que já viraram achado por unidade não se repetem)
  const usados = new Set();
  for (const a of c.avisos) {
    const un = planejadas.find(p => norm(a).startsWith(norm(p) + ':'));
    if (un && falhou.has(norm(un))) continue;
    const comp = /^Composição/.test(a);
    const m = /^([^:]+):\s*(.*)$/.exec(a);
    const unidade = un || null;
    const texto = un ? a.slice(a.indexOf(':') + 1).trim() : a;
    const chave = (unidade || '') + '|' + texto;
    if (usados.has(chave)) continue; usados.add(chave);
    add('atencao', unidade, comp ? 'Composição' : 'Avisos da coleta', texto);
    void m;
  }
  const ordem = { erro: 0, atencao: 1, info: 2 };
  achados.sort((a, b) => ordem[a.nivel] - ordem[b.nivel] || a.unidade.localeCompare(b.unidade, 'pt') || a.tema.localeCompare(b.tema, 'pt'));
  return {
    competencia: c.competencia, versao: c.versao, iniciadoEm: c.iniciadoEm, concluidoEm: c.concluidoEm,
    geradoEm: new Date().toISOString(), semCobertura: !cob,
    unidadesPlanejadas: planejadas.length, unidadesComErro: cob ? cob.unidadesComErro.length : null,
    totais: { erro: achados.filter(a => a.nivel === 'erro').length, atencao: achados.filter(a => a.nivel === 'atencao').length, info: achados.filter(a => a.nivel === 'info').length },
    achados
  };
}

async function abrirInconsistencias(c) {
  if (!c) { log('Faça uma coleta ou abra uma do histórico para gerar o relatório.', 'erro'); return; }
  const rel = montarInconsistencias(c);
  await chrome.storage.local.set({ relInconsistencias: rel });
  chrome.tabs.create({ url: chrome.runtime.getURL('panel/inconsistencias.html') });
}
